-------------------------------------------------------------------------------
--  War UI - Profession Map / Core.lua
--  Puts the profession trainers of the capital cities on the world map, as
--  icons, text or both. Trainer positions come from Data.lua (QuestieDB,
--  Forever flavor) and can be corrected/extended by visiting a trainer.
--
--  Map integration: a MapCanvas data provider on WorldMapFrame with our own
--  pin template (Pins.xml). No Blizzard frames are modified.
-------------------------------------------------------------------------------
local ADDON, ns = ...

local TEMPLATE = "WarUIProfMapPinTemplate"
local TAG = "|cffd9a441Profession Map:|r "

-------------------------------------------------------------------------------
--  Professions
-------------------------------------------------------------------------------
ns.PROFESSIONS = {
    alchemy        = { name = "Alchemy",        icon = "Interface\\Icons\\Trade_Alchemy",              hex = "3FD0C8", match = { "alchem" } },
    blacksmithing  = { name = "Blacksmithing",  icon = "Interface\\Icons\\Trade_BlackSmithing",        hex = "E0E0E0", match = { "blacksmith" } },
    enchanting     = { name = "Enchanting",     icon = "Interface\\Icons\\Trade_Engraving",            hex = "C77DFF", match = { "enchant" } },
    engineering    = { name = "Engineering",    icon = "Interface\\Icons\\Trade_Engineering",          hex = "FFB347", match = { "engineer" } },
    herbalism      = { name = "Herbalism",      icon = "Interface\\Icons\\Spell_Nature_NatureTouchGrow", hex = "8FE05A", match = { "herbalis" } },
    leatherworking = { name = "Leatherworking", icon = "Interface\\Icons\\INV_Misc_ArmorKit_17",       hex = "D9A066", match = { "leatherwork" } },
    mining         = { name = "Mining",         icon = "Interface\\Icons\\Trade_Mining",               hex = "8FB0D8", match = { "mining", "miner" } },
    skinning       = { name = "Skinning",       icon = "Interface\\Icons\\INV_Misc_Pelt_Wolf_01",      hex = "F0D2A8", match = { "skinning", "skinner" } },
    tailoring      = { name = "Tailoring",      icon = "Interface\\Icons\\Trade_Tailoring",            hex = "FF8FC8", match = { "tailor" } },
    cooking        = { name = "Cooking",        icon = "Interface\\Icons\\INV_Misc_Food_15",           hex = "FF7A4D", match = { "cooking", "cook" } },
    firstaid       = { name = "First Aid",      icon = "Interface\\Icons\\Spell_Holy_SealOfSacrifice", hex = "FF5A5A", match = { "first aid", "physician", "surgeon" } },
    fishing        = { name = "Fishing",        icon = "Interface\\Icons\\Trade_Fishing",              hex = "4DA6FF", match = { "fishing", "fisherman" } },
}
ns.PROF_ORDER = { "alchemy", "blacksmithing", "enchanting", "engineering", "herbalism", "leatherworking",
                  "mining", "skinning", "tailoring", "cooking", "firstaid", "fishing" }

-- Class trainers (+ hunter pet trainer). Registered in ns.PROFESSIONS under
-- "c_<TOKEN>" so pins/tooltips/waypoints treat them like any other kind.
ns.CLASS_ORDER = { "WARRIOR", "PALADIN", "HUNTER", "ROGUE", "PRIEST", "SHAMAN", "MAGE", "WARLOCK", "DRUID" }
local CLASS_NAMES = { WARRIOR = "Warrior", PALADIN = "Paladin", HUNTER = "Hunter", ROGUE = "Rogue", PRIEST = "Priest",
                      SHAMAN = "Shaman", MAGE = "Mage", WARLOCK = "Warlock", DRUID = "Druid" }
local CLASS_HEX = { WARRIOR = "C69B6D", PALADIN = "F48CBA", HUNTER = "AAD372", ROGUE = "FFF468", PRIEST = "FFFFFF",
                    SHAMAN = "0070DD", MAGE = "3FC7EB", WARLOCK = "8788EE", DRUID = "FF7C0A" }
ns.CLASS_NAMES = CLASS_NAMES
for _, tok in ipairs(ns.CLASS_ORDER) do
    local c = RAID_CLASS_COLORS and RAID_CLASS_COLORS[tok]
    local hex = CLASS_HEX[tok]
    if c and c.r then hex = ("%02X%02X%02X"):format(c.r * 255 + 0.5, c.g * 255 + 0.5, c.b * 255 + 0.5) end
    local tc = CLASS_ICON_TCOORDS and CLASS_ICON_TCOORDS[tok]
    ns.PROFESSIONS["c_" .. tok] = {
        name = CLASS_NAMES[tok] .. " Trainer", short = CLASS_NAMES[tok], isClass = true, token = tok, hex = hex,
        icon = tc and "Interface\\TargetingFrame\\UI-Classes-Circles" or ("Interface\\Icons\\ClassIcon_" .. CLASS_NAMES[tok]),
        coords = tc and { tc[1], tc[2], tc[3], tc[4] } or nil,
    }
end
ns.PROFESSIONS.c_PET = { name = "Pet Trainer", short = "Pet", isClass = true, token = "PET", hex = "AAD372",
                         icon = "Interface\\Icons\\Ability_Hunter_BeastTraining" }

function ns.ClassFromText(text)
    if type(text) ~= "string" then return nil end
    local t = text:lower()
    if t:find("pet trainer", 1, true) then return "c_PET" end
    for _, tok in ipairs(ns.CLASS_ORDER) do
        if t:find(CLASS_NAMES[tok]:lower() .. " trainer", 1, true) then return "c_" .. tok end
    end
end

-- City services (DataServices.lua). Registered as "s_<kind>". Icons: first
-- texture that loads (minimap tracking art on newer clients, vanilla icons otherwise).
ns.SERVICE_ORDER = { "auction", "bank", "mailbox", "repair", "reagents", "innkeeper", "flightmaster",
                     "stablemaster", "battlemaster", "weaponmaster", "tradegoods", "generalgoods" }
local SERVICES = {
    auction      = { "Auction House",  "FFD24D", { "Interface\\Minimap\\Tracking\\Auctioneer",   "Interface\\Icons\\INV_Misc_Coin_01" } },
    bank         = { "Bank",           "FFE699", { "Interface\\Minimap\\Tracking\\Banker",       "Interface\\Icons\\INV_Misc_Bag_07" } },
    mailbox      = { "Mailbox",        "F2F2F2", { "Interface\\Minimap\\Tracking\\Mailbox",      "Interface\\Icons\\INV_Misc_Note_01" }, 3 },
    repair       = { "Repair",         "B3B3B3", { "Interface\\Minimap\\Tracking\\Repair",       "Interface\\Icons\\INV_Misc_Wrench_01" }, 10 },
    reagents     = { "Reagents",       "D98CFF", { "Interface\\Minimap\\Tracking\\Reagents",     "Interface\\Icons\\INV_Misc_Dust_01" } },
    innkeeper    = { "Innkeeper",      "FFB366", { "Interface\\Minimap\\Tracking\\Innkeeper",    "Interface\\Icons\\INV_Misc_Rune_01" } },
    flightmaster = { "Flight Master",  "80D4FF", { "Interface\\Minimap\\Tracking\\FlightMaster", "Interface\\Icons\\Ability_Hunter_EagleEye" } },
    stablemaster = { "Stable Master",  "C8A27A", { "Interface\\Minimap\\Tracking\\StableMaster", "Interface\\Icons\\Ability_Hunter_BeastTraining" } },
    battlemaster = { "Battlemasters",  "FF6666", { "Interface\\Minimap\\Tracking\\BattleMaster", "Interface\\Icons\\INV_BannerPVP_02", "Interface\\Icons\\INV_Sword_27" } },
    weaponmaster = { "Weapon Master",  "E6C080", { "Interface\\Icons\\INV_Sword_04" } },
    tradegoods   = { "Trade Goods",    "A6D9A6", { "Interface\\Icons\\INV_Fabric_Linen_01" } },
    generalgoods = { "General Goods",  "CCCCCC", { "Interface\\Icons\\INV_Misc_Bag_08" } },
}
for _, k in ipairs(ns.SERVICE_ORDER) do
    local v = SERVICES[k]
    ns.PROFESSIONS["s_" .. k] = { name = v[1], hex = v[2], icons = v[3], icon = v[3][#v[3]],
                                  isService = true, kind = k, mergeDist = v[4] or 8 }
end

-- Pick the first icon path the client can load (done once, lazily).
local probe
function ns.ResolveIcon(info)
    if info._iconDone or not info.icons then return info.icon end
    info._iconDone = true
    probe = probe or UIParent:CreateTexture(nil, "BACKGROUND")
    for _, path in ipairs(info.icons) do
        local ok, loaded = pcall(probe.SetTexture, probe, path)
        if ok and loaded then info.icon = path; break end
    end
    probe:SetTexture(nil)
    return info.icon
end

-- uiMapID -> city (QuestieDB Forever: areaIdToUiMapId)
ns.CITIES = {
    [1453] = { name = "Stormwind",     faction = "Alliance" },
    [1455] = { name = "Ironforge",     faction = "Alliance" },
    [1457] = { name = "Darnassus",     faction = "Alliance" },
    [1454] = { name = "Orgrimmar",     faction = "Horde" },
    [1456] = { name = "Thunder Bluff", faction = "Horde" },
    [1458] = { name = "Undercity",     faction = "Horde" },
}

-------------------------------------------------------------------------------
--  Saved settings
-------------------------------------------------------------------------------
ns.DEFAULTS = {
    enabled      = true,
    style        = "both",       -- "icon" | "text" | "both"
    iconSize     = 22,
    textSize     = 11,
    textColor    = "profession", -- "profession" | "white" | "gold"
    roundIcons   = true,
    merge        = true,         -- one pin per profession when its trainers stand together
    spread       = true,         -- push overlapping pins apart
    factionOnly  = false,        -- only cities of my faction
    onlyMine     = true,         -- only professions I have learned (incl. cooking/first aid/fishing)
    highlightMine = true,        -- my professions get a gold ring
    showClass    = true,         -- class trainers on the map
    classMode    = "mine",       -- "mine" = only my class | "all" = every class
    showPet      = true,         -- pet trainer (hunters, or everyone in "all" mode)
    hideClass    = {},           -- [TOKEN] = true (only used in "all" mode)
    showServices = true,         -- auction house, bank, mailbox, repair, ...
    svc          = { auction = true, bank = true, mailbox = true, repair = true, reagents = true,
                     innkeeper = true, flightmaster = true, stablemaster = false, battlemaster = false,
                     weaponmaster = false, tradegoods = false, generalgoods = false },
    learn        = true,         -- remember trainers I talk to (fixes/extends the data)
    hide         = {},           -- [profKey] = true
    learned      = {},           -- [uiMapID] = { [npcID] = { prof, name, title, x, y } }
}

local function CopyDefaults(dst, src)
    for k, v in pairs(src) do
        if dst[k] == nil then
            if type(v) == "table" then dst[k] = {}; CopyDefaults(dst[k], v) else dst[k] = v end
        end
    end
end

function ns.DB()
    WarUIProfessionMapDB = WarUIProfessionMapDB or {}
    if not ns._defaultsDone then
        CopyDefaults(WarUIProfessionMapDB, ns.DEFAULTS)
        local db = WarUIProfessionMapDB
        if (db.dbVersion or 1) < 2 then      -- v1.2: "only my professions" became the default
            db.onlyMine = true
            db.dbVersion = 2
        end
        ns._defaultsDone = true
    end
    return WarUIProfessionMapDB
end

function ns.ResetDB(keepLearned)
    local learned = keepLearned and WarUIProfessionMapDB and WarUIProfessionMapDB.learned
    WarUIProfessionMapDB = { learned = learned }
    ns._defaultsDone = false
    ns.DB()
end

local function HexToRGB(hex)
    hex = tostring(hex or "FFFFFF")
    return tonumber(hex:sub(1, 2), 16) / 255, tonumber(hex:sub(3, 4), 16) / 255, tonumber(hex:sub(5, 6), 16) / 255
end
ns.HexToRGB = HexToRGB

function ns.ProfFromText(text)
    if type(text) ~= "string" then return nil end
    text = text:lower()
    for _, key in ipairs(ns.PROF_ORDER) do
        for _, m in ipairs(ns.PROFESSIONS[key].match) do
            if text:find(m, 1, true) then return key end
        end
    end
end

-------------------------------------------------------------------------------
--  Which professions does this character have?
-------------------------------------------------------------------------------
local myProfs, myProfsTime = {}, 0
local seenTradeSkills = {}      -- professions whose window was opened this session

-- Secondary skills by spell (all ranks), in case the skill-line APIs miss one.
local PROF_SPELLS = {
    cooking  = { 2550, 3102, 3413, 18260 },
    firstaid = { 3273, 3274, 7924, 10846 },
    fishing  = { 7620, 7731, 7732, 18248 },
}

-- Returns key -> source string ("skill line", "profession", "spell", "window").
function ns.ScanProfessions()
    local found = {}
    local function add(key, src) if key and not found[key] then found[key] = src end end

    if GetNumSkillLines and GetSkillLineInfo then         -- classic API
        local ok, n = pcall(GetNumSkillLines)
        for i = 1, (ok and n or 0) do
            local okI, name, isHeader = pcall(GetSkillLineInfo, i)
            if okI and name and not isHeader then add(ns.ProfFromText(name), "skill line") end
        end
    end
    if GetProfessions and GetProfessionInfo then         -- modern API: prof1, prof2, arch, fish, cook (can be nil)
        local res = { pcall(GetProfessions) }
        if res[1] then
            for i = 2, 7 do
                local idx = res[i]
                if idx then
                    local okI, name = pcall(GetProfessionInfo, idx)
                    if okI then add(ns.ProfFromText(name), "profession") end
                end
            end
        end
    end
    local known = IsPlayerSpell or IsSpellKnown
    if known then
        for key, ids in pairs(PROF_SPELLS) do
            for _, id in ipairs(ids) do
                local ok, has = pcall(known, id)
                if ok and has then add(key, "spell"); break end
            end
        end
    end
    for key in pairs(seenTradeSkills) do add(key, "window") end
    return found
end

function ns.MyProfessions()
    if GetTime() - myProfsTime < 5 then return myProfs end
    myProfsTime = GetTime()
    wipe(myProfs)
    for key in pairs(ns.ScanProfessions()) do myProfs[key] = true end
    return myProfs
end

-- The open profession window (TRADE_SKILL_SHOW / CRAFT_SHOW) counts as proof.
local function NoteOpenTradeSkill()
    local name
    if C_TradeSkillUI and C_TradeSkillUI.GetBaseProfessionInfo then
        local ok, info = pcall(C_TradeSkillUI.GetBaseProfessionInfo)
        name = ok and info and info.professionName
    end
    if (not name or name == "") and GetTradeSkillLine then
        local ok, n = pcall(GetTradeSkillLine)
        if ok then name = n end
    end
    if (not name or name == "" or name == "UNKNOWN") and GetCraftDisplaySkillLine then
        local ok, n = pcall(GetCraftDisplaySkillLine)
        if ok then name = n end
    end
    local key = ns.ProfFromText(name)
    if key and not seenTradeSkills[key] then
        seenTradeSkills[key] = true
        myProfsTime = 0
        ns.Apply()
    end
end

-------------------------------------------------------------------------------
--  Map id helpers
-------------------------------------------------------------------------------
local nameToCity
function ns.ResolveCity(mapID)
    if not mapID then return nil end
    if ns.CITIES[mapID] then return mapID end
    -- Fallback: a client that uses other uiMapIDs - match on the map name.
    if not nameToCity then
        nameToCity = {}
        for id, c in pairs(ns.CITIES) do nameToCity[c.name:lower()] = id end
        nameToCity["stormwind city"] = 1453
    end
    local info = C_Map and C_Map.GetMapInfo and C_Map.GetMapInfo(mapID)
    local name = info and info.name and info.name:lower()
    return name and nameToCity[name] or nil
end

-------------------------------------------------------------------------------
--  Build the pin list for one map
-------------------------------------------------------------------------------
local RANKS = { "Grand Master", "Artisan", "Expert", "Journeyman", "Apprentice" }
local function RankOf(title)
    title = tostring(title or "")
    for i, r in ipairs(RANKS) do if title:find(r, 1, true) then return i end end
    return 99
end

-- Pixel-ish distance: city maps are ~3:2, so 1% of x is wider than 1% of y.
local function Dist(ax, ay, bx, by)
    local dx, dy = (ax - bx) * 1.5, ay - by
    return math.sqrt(dx * dx + dy * dy)
end

function ns.GetGroups(mapID)
    local d = ns.DB()
    local dataMap = ns.ResolveCity(mapID) or mapID
    local city = ns.CITIES[dataMap]
    if city and d.factionOnly then
        local fac = UnitFactionGroup("player")
        if fac and fac ~= city.faction then return {} end
    end

    -- Trainers: shipped data, overridden/extended by what we learned.
    local list, byId = {}, {}
    for _, t in ipairs(ns.TRAINERS[dataMap] or {}) do
        local e = { prof = t[1], id = t[2], name = t[3], title = t[4], x = t[5], y = t[6] }
        list[#list + 1] = e; byId[e.id] = e
    end
    for _, t in ipairs(ns.CLASS_TRAINERS and ns.CLASS_TRAINERS[dataMap] or {}) do
        local e = { prof = "c_" .. t[1], id = t[2], name = t[3], title = t[4], x = t[5], y = t[6] }
        list[#list + 1] = e; byId[e.id] = e
    end
    if d.showServices then
        for _, t in ipairs(ns.SERVICES and ns.SERVICES[dataMap] or {}) do
            if d.svc[t[1]] then
                list[#list + 1] = { prof = "s_" .. t[1], id = -t[2], name = t[3], title = t[4], x = t[5], y = t[6] }
            end
        end
    end
    local learned = d.learned[mapID] or (dataMap ~= mapID and d.learned[dataMap]) or nil
    for id, t in pairs(learned or {}) do
        local e = byId[id]
        if e then e.x, e.y, e.learned = t.x, t.y, true
        else list[#list + 1] = { prof = t.prof, id = id, name = t.name, title = t.title, x = t.x, y = t.y, learned = true } end
    end

    local okMine, mine = pcall(ns.MyProfessions)
    if not okMine or type(mine) ~= "table" then mine = {} end
    local myClass = select(2, UnitClass("player"))
    local function Wanted(key)
        local info = ns.PROFESSIONS[key]
        if not info then return false end
        if info.isService then return true end   -- already filtered above
        if not info.isClass then
            return not d.hide[key] and (not d.onlyMine or mine[key])
        end
        if not d.showClass then return false end
        if info.token == "PET" then
            return d.showPet and (d.classMode == "all" or myClass == "HUNTER")
        end
        if d.classMode == "all" then return not d.hideClass[info.token] end
        return info.token == myClass
    end
    local groups = {}
    for _, e in ipairs(list) do
        if Wanted(e.prof) then
            local g
            if d.merge then
                for _, og in ipairs(groups) do
                    if og.prof == e.prof and Dist(og.x, og.y, e.x, e.y) < (ns.PROFESSIONS[e.prof].mergeDist or (ns.PROFESSIONS[e.prof].isClass and 10 or 6)) then g = og; break end
                end
            end
            if g then
                g.trainers[#g.trainers + 1] = e
                local n = #g.trainers
                g.x = g.x + (e.x - g.x) / n
                g.y = g.y + (e.y - g.y) / n
            else
                groups[#groups + 1] = { prof = e.prof, x = e.x, y = e.y, trainers = { e }, mapID = mapID }
            end
        end
    end
    for _, g in ipairs(groups) do
        table.sort(g.trainers, function(a, b) return RankOf(a.title) < RankOf(b.title) end)
        g.ax, g.ay = g.x, g.y            -- true position (for waypoints)
        local info = ns.PROFESSIONS[g.prof]
        g.mine = (not info.isClass and not info.isService and mine[g.prof]) or false
    end

    -- Spread pins that would sit on top of each other.
    if d.spread and #groups > 1 then
        local need = (d.style == "icon") and 3.5 or (d.style == "text" and 4.0 or 4.5)
        need = need * ((d.iconSize or 22) / 22)
        for _ = 1, 12 do
            local moved = false
            for i = 1, #groups - 1 do
                for j = i + 1, #groups do
                    local a, b = groups[i], groups[j]
                    local dd = Dist(a.x, a.y, b.x, b.y)
                    if dd < need then
                        local dx, dy = (b.x - a.x) * 1.5, b.y - a.y
                        if dd < 0.01 then dx, dy, dd = 0, 1, 1 end
                        local push = (need - dd) / 2
                        local ux, uy = dx / dd, dy / dd
                        a.x, a.y = a.x - ux * push / 1.5, a.y - uy * push
                        b.x, b.y = b.x + ux * push / 1.5, b.y + uy * push
                        moved = true
                    end
                end
            end
            if not moved then break end
        end
    end
    return groups
end

-------------------------------------------------------------------------------
--  Waypoint on click
-------------------------------------------------------------------------------
function ns.SetWaypoint(g)
    local t = g.trainers[1]
    local p = ns.PROFESSIONS[g.prof]
    local x, y = g.ax / 100, g.ay / 100
    if TomTom and TomTom.AddWaypoint then
        pcall(TomTom.AddWaypoint, TomTom, g.mapID, x, y, { title = t.name .. " (" .. p.name .. ")" })
        print(TAG .. "TomTom waypoint: " .. t.name)
        return
    end
    if C_Map and C_Map.SetUserWaypoint and UiMapPoint and UiMapPoint.CreateFromCoordinates then
        local ok = pcall(function()
            if C_Map.CanSetUserWaypointOnMap and not C_Map.CanSetUserWaypointOnMap(g.mapID) then error("no") end
            C_Map.SetUserWaypoint(UiMapPoint.CreateFromCoordinates(g.mapID, x, y))
            if C_SuperTrack and C_SuperTrack.SetSuperTrackedUserWaypoint then
                C_SuperTrack.SetSuperTrackedUserWaypoint(true)
            end
        end)
        if ok then print(TAG .. "Map pin set on " .. t.name .. "."); return end
    end
    print(TAG .. ("%s (%s) - %.1f, %.1f"):format(t.name, p.name, g.ax, g.ay))
end

-------------------------------------------------------------------------------
--  Pin
-------------------------------------------------------------------------------
local ROUND_MASK = "Interface\\CharacterFrame\\TempPortraitAlphaMask"

local function FontPath()
    if EllesmereUI and EllesmereUI.GetFontPath then
        local ok, p = pcall(EllesmereUI.GetFontPath)
        if ok and p then return p end
    end
    return STANDARD_TEXT_FONT
end

WarUIProfMapPinMixin = CreateFromMixins(MapCanvasPinMixin)

function WarUIProfMapPinMixin:Build()
    if self._built then return end
    self._built = true

    self.ring = self:CreateTexture(nil, "BACKGROUND")
    self.ring:SetPoint("CENTER")
    self.ring:SetTexture("Interface\\Buttons\\WHITE8X8")

    self.icon = self:CreateTexture(nil, "ARTWORK")
    self.icon:SetPoint("CENTER")

    if self.CreateMaskTexture and self.icon.AddMaskTexture then
        self.iconMask = self:CreateMaskTexture()
        self.iconMask:SetTexture(ROUND_MASK, "CLAMPTOBLACKADDITIVE", "CLAMPTOBLACKADDITIVE")
        self.iconMask:SetAllPoints(self.icon)
        self.ringMask = self:CreateMaskTexture()
        self.ringMask:SetTexture(ROUND_MASK, "CLAMPTOBLACKADDITIVE", "CLAMPTOBLACKADDITIVE")
        self.ringMask:SetAllPoints(self.ring)
    end

    self.label = self:CreateFontString(nil, "OVERLAY")
    self.label:SetFont(STANDARD_TEXT_FONT, 11, "OUTLINE")
    self.label:SetShadowOffset(1, -1)
    self.label:SetShadowColor(0, 0, 0, 0.9)

    self:SetScript("OnEnter", self.OnMouseEnter)
    self:SetScript("OnLeave", self.OnMouseLeave)
    self:SetScript("OnMouseUp", self.OnClick)
end

function WarUIProfMapPinMixin:OnAcquired(group)
    self:Build()
    pcall(self.UseFrameLevelType, self, "PIN_FRAME_LEVEL_AREA_POI")
    pcall(self.SetScalingLimits, self, 1, 1.0, 1.25)
    self.group = group
    self:ApplyLook()
    self:SetPosition(group.x / 100, group.y / 100)
    self:Show()
end

function WarUIProfMapPinMixin:OnReleased()
    self.group = nil
    if GameTooltip:GetOwner() == self then GameTooltip:Hide() end
end

function WarUIProfMapPinMixin:ApplyLook()
    local d, g = ns.DB(), self.group
    local p = ns.PROFESSIONS[g.prof]
    local size = d.iconSize or 22
    local showIcon = d.style ~= "text"
    local showText = d.style ~= "icon"

    -- icon + ring
    self.icon:SetTexture(ns.ResolveIcon(p))
    self.icon:SetSize(size, size)
    self.ring:SetSize(size + 4, size + 4)
    local round = d.roundIcons and self.iconMask and true or false
    if self._round ~= round then
        if round then
            self.icon:AddMaskTexture(self.iconMask)
            self.ring:AddMaskTexture(self.ringMask)
        elseif self._round then
            self.icon:RemoveMaskTexture(self.iconMask)
            self.ring:RemoveMaskTexture(self.ringMask)
        end
        self._round = round
    end
    if p.coords then
        self.icon:SetTexCoord(p.coords[1], p.coords[2], p.coords[3], p.coords[4])
    else
        self.icon:SetTexCoord(0.07, 0.93, 0.07, 0.93)
    end
    if g.mine and d.highlightMine then
        self.ring:SetVertexColor(1, 0.82, 0.2, 1)
    else
        self.ring:SetVertexColor(0, 0, 0, 0.9)
    end
    self.icon:SetShown(showIcon)
    self.ring:SetShown(showIcon)

    -- text
    local r, gg, b = 1, 1, 1
    if d.textColor == "profession" then r, gg, b = HexToRGB(p.hex)
    elseif d.textColor == "gold" then r, gg, b = 1, 0.82, 0 end
    local tsize = d.textSize or 11
    self.label:SetFont(FontPath(), tsize, "OUTLINE")
    if not self.label:GetFont() then self.label:SetFont(STANDARD_TEXT_FONT, tsize, "OUTLINE") end
    self.label:SetTextColor(r, gg, b, 1)
    self.label:SetText(p.name)
    self.label:ClearAllPoints()
    if showIcon then
        self.label:SetPoint("TOP", self, "BOTTOM", 0, -1)
    else
        self.label:SetPoint("CENTER", self, "CENTER", 0, 0)
    end
    self.label:SetShown(showText)

    if showIcon then
        self:SetSize(size + 4, size + 4)
    else
        self:SetSize(math.max(20, (self.label:GetStringWidth() or 40) + 4), tsize + 6)
    end
end

function WarUIProfMapPinMixin:OnMouseEnter()
    local g = self.group
    if not g then return end
    local p = ns.PROFESSIONS[g.prof]
    GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
    local r, gg, b = HexToRGB(p.hex)
    GameTooltip:AddLine(p.name .. (g.mine and "  |cffffd100(yours)|r" or ""), r, gg, b)
    for i, t in ipairs(g.trainers) do
        if i > 10 then
            GameTooltip:AddLine(("... and %d more"):format(#g.trainers - 10), 0.6, 0.6, 0.6)
            break
        end
        GameTooltip:AddDoubleLine(t.name, t.title or "", 1, 1, 1, 0.7, 0.7, 0.7)
    end
    GameTooltip:AddLine(("%.1f, %.1f"):format(g.ax, g.ay), 0.5, 0.5, 0.5)
    GameTooltip:AddLine("Click: set a waypoint", 0.4, 0.8, 1)
    GameTooltip:Show()
    if self.icon:IsShown() then self.icon:SetSize((ns.DB().iconSize or 22) * 1.15, (ns.DB().iconSize or 22) * 1.15) end
end

function WarUIProfMapPinMixin:OnMouseLeave()
    GameTooltip:Hide()
    local s = ns.DB().iconSize or 22
    self.icon:SetSize(s, s)
end

function WarUIProfMapPinMixin:OnClick(button)
    if button == "LeftButton" and self.group then ns.SetWaypoint(self.group) end
end

-------------------------------------------------------------------------------
--  Data provider
-------------------------------------------------------------------------------
local Provider = CreateFromMixins(MapCanvasDataProviderMixin)
ns.Provider = Provider
ns.pinCount = 0

function Provider:RemoveAllData()
    local map = self:GetMap()
    if map then map:RemoveAllPinsByTemplate(TEMPLATE) end
end

function Provider:RefreshAllData()
    self:RemoveAllData()
    ns.pinCount = 0
    local map = self:GetMap()
    if not map or not ns.DB().enabled then return end
    local mapID = map:GetMapID()
    for _, g in ipairs(ns.GetGroups(mapID)) do
        map:AcquirePin(TEMPLATE, g)
        ns.pinCount = ns.pinCount + 1
    end
end

function ns.Apply()
    if ns.providerAdded and WorldMapFrame and WorldMapFrame:IsShown() then
        Provider:RefreshAllData()
    end
end

local function AttachToMap()
    if ns.providerAdded or not (WorldMapFrame and WorldMapFrame.AddDataProvider) then return end
    WorldMapFrame:AddDataProvider(Provider)
    ns.providerAdded = true
end

-------------------------------------------------------------------------------
--  Learning: remember where the trainers you talk to stand
-------------------------------------------------------------------------------
local function NpcTitle()
    if C_TooltipInfo and C_TooltipInfo.GetUnit then
        local ok, data = pcall(C_TooltipInfo.GetUnit, "npc")
        if ok and data and data.lines then
            for i = 2, math.min(#data.lines, 3) do
                local txt = data.lines[i] and data.lines[i].leftText
                if txt and (ns.ProfFromText(txt) or ns.ClassFromText(txt)) then return txt end
            end
        end
    end
end

local function KnownEntry(mapID, npcID)
    for _, t in ipairs(ns.TRAINERS[mapID] or {}) do
        if t[2] == npcID then return t end
    end
    for _, t in ipairs(ns.CLASS_TRAINERS and ns.CLASS_TRAINERS[mapID] or {}) do
        if t[2] == npcID then return { "c_" .. t[1], t[2], t[3], t[4], t[5], t[6] } end
    end
end

function ns.LearnCurrentTrainer(verbose)
    local d = ns.DB()
    if not UnitExists("npc") then return end
    local guid = UnitGUID("npc")
    local npcID = guid and tonumber((select(6, strsplit("-", guid))))
    if not npcID then return end
    local mapID = C_Map.GetBestMapForUnit("player")
    if not mapID then return end
    local pos = C_Map.GetPlayerMapPosition(mapID, "player")
    if not pos then return end
    local x, y = pos:GetXY()
    if not x or x == 0 then return end
    x, y = math.floor(x * 1000 + 0.5) / 10, math.floor(y * 1000 + 0.5) / 10

    local cityID = ns.ResolveCity(mapID) or mapID
    local known = KnownEntry(cityID, npcID)
    local prof, title
    if known then
        prof, title = known[1], known[4]
        -- Shipped data already close enough: nothing to store.
        if Dist(known[5], known[6], x, y) < 4 and not (d.learned[mapID] and d.learned[mapID][npcID]) then return end
    else
        title = NpcTitle()
        prof = ns.ProfFromText(title) or ns.ClassFromText(title)
        if not prof then return end      -- riding trainer, weapon master, ...
    end
    d.learned[mapID] = d.learned[mapID] or {}
    local old = d.learned[mapID][npcID]
    d.learned[mapID][npcID] = { prof = prof, name = UnitName("npc"), title = title, x = x, y = y }
    if verbose or not old then
        print(TAG .. ("Saved %s (%s) at %.1f, %.1f."):format(UnitName("npc") or "?", ns.PROFESSIONS[prof].name, x, y))
    end
    ns.Apply()
end

function ns.LearnedCount()
    local n = 0
    for _, m in pairs(ns.DB().learned) do for _ in pairs(m) do n = n + 1 end end
    return n
end

-------------------------------------------------------------------------------
--  Events
-------------------------------------------------------------------------------
local ev = CreateFrame("Frame")
-- Events differ between clients (e.g. LEARNED_SPELL_IN_TAB is gone on the 12.x
-- engine) and an unknown event errors, so every registration is protected.
for _, e in ipairs({ "PLAYER_LOGIN", "ADDON_LOADED", "TRAINER_SHOW", "SKILL_LINES_CHANGED",
                     "LEARNED_SPELL_IN_TAB", "LEARNED_SPELL_IN_SKILL_LINE", "SKILL_LINE_SPECS_RANKS_CHANGED",
                     "TRADE_SKILL_SHOW", "CRAFT_SHOW" }) do
    pcall(ev.RegisterEvent, ev, e)
end
ev:SetScript("OnEvent", function(_, event, arg1)
    if event == "PLAYER_LOGIN" then
        ns.DB()
        AttachToMap()
    elseif event == "ADDON_LOADED" then
        if arg1 == "Blizzard_WorldMap" then AttachToMap() end
    elseif event == "TRAINER_SHOW" then
        if ns.DB().learn then pcall(ns.LearnCurrentTrainer) end
    elseif event == "TRADE_SKILL_SHOW" or event == "CRAFT_SHOW" then
        C_Timer.After(0.2, NoteOpenTradeSkill)
    elseif event == "SKILL_LINES_CHANGED" or event == "LEARNED_SPELL_IN_TAB"
        or event == "LEARNED_SPELL_IN_SKILL_LINE" or event == "SKILL_LINE_SPECS_RANKS_CHANGED" then
        myProfsTime = 0
        ns.Apply()
    end
end)

-------------------------------------------------------------------------------
--  Slash
-------------------------------------------------------------------------------
SLASH_WARUIPROFMAP1 = "/profmap"
SLASH_WARUIPROFMAP2 = "/professionmap"
SlashCmdList.WARUIPROFMAP = function(msg)
    msg = strtrim((msg or ""):lower())
    local d = ns.DB()
    if msg == "toggle" or msg == "on" or msg == "off" then
        if msg == "toggle" then d.enabled = not d.enabled else d.enabled = (msg == "on") end
        print(TAG .. (d.enabled and "on" or "off"))
        ns.Apply()
    elseif msg == "icon" or msg == "text" or msg == "both" then
        d.style = msg
        print(TAG .. "style: " .. msg)
        ns.Apply()
    elseif msg == "learn" then
        if not UnitExists("npc") then print(TAG .. "Talk to a trainer first, then type /profmap learn.") end
        ns.LearnCurrentTrainer(true)
    elseif msg == "skills" or msg == "profs" then
        local found = ns.ScanProfessions()
        local n = 0
        for _, key in ipairs(ns.PROF_ORDER) do
            if found[key] then
                n = n + 1
                print(TAG .. ns.PROFESSIONS[key].name .. "  |cff888888(" .. found[key] .. ")|r")
            end
        end
        if n == 0 then print(TAG .. "no professions found") end
        if GetNumSkillLines and GetSkillLineInfo then
            local lines = {}
            for i = 1, GetNumSkillLines() do
                local name, isHeader = GetSkillLineInfo(i)
                if name and not isHeader then lines[#lines + 1] = name end
            end
            print(TAG .. "skill lines: " .. table.concat(lines, ", "))
        end
    elseif msg == "debug" then
        local mapID = WorldMapFrame and WorldMapFrame.GetMapID and WorldMapFrame:GetMapID()
        local here = C_Map.GetBestMapForUnit("player")
        local info = here and C_Map.GetMapInfo(here)
        print(TAG .. ("world map %s, you are on %s (%s), city match %s"):format(
            tostring(mapID), tostring(here), info and info.name or "?", tostring(ns.ResolveCity(here))))
        print(TAG .. ("provider %s, pins shown %d, learned trainers %d"):format(
            tostring(ns.providerAdded), ns.pinCount or 0, ns.LearnedCount()))
    elseif msg == "" or msg == "config" or msg == "options" then
        if ns.OpenSettings then ns.OpenSettings() end
    else
        print(TAG .. "/profmap [toggle | on | off | icon | text | both | learn | skills | debug]")
    end
end
