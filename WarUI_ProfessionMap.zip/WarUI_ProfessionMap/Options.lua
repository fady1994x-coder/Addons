-------------------------------------------------------------------------------
--  War UI - Profession Map / Options.lua
--  Settings under War UI > Profession Map in the EllesmereUI panel.
-------------------------------------------------------------------------------
local ADDON, ns = ...

local PLUGIN_ID  = "WarUI"
local MODULE_KEY = "ProfessionMap"

local function DB() return ns.DB() end

local function Refresh()
    C_Timer.After(0, function()
        local key = EllesmereUI.GetPluginModuleKey(PLUGIN_ID, MODULE_KEY)
        if not key then return end
        EllesmereUI:InvalidateModulePageCache(key)
        if EllesmereUI:GetActiveModule() == key then
            EllesmereUI:RefreshPage(true)
        end
    end)
end

function ns.OpenSettings(page)
    if InCombatLockdown() then return end
    if WarUI and WarUI.Open then WarUI.Open(MODULE_KEY, page) end
end

local function Pad() return EllesmereUI.CONTENT_PAD or 20 end

local function Paragraph(parent, text, y, alpha)
    local w = parent:GetWidth() - Pad() * 2
    local fs = EllesmereUI.MakeFont(parent, 12, nil, 1, 1, 1, alpha or 0.7)
    fs:SetJustifyH("LEFT")
    fs:SetText(text)
    fs:SetWidth(w - 20)
    fs:SetSpacing(4)
    fs:SetPoint("TOPLEFT", parent, "TOPLEFT", Pad() + 10, y - 6)
    return y - (fs:GetStringHeight() or 40) - 16
end

-- Preview row: a few professions drawn the way the map pins look.
local function Preview(parent, y)
    local d = DB()
    local box = CreateFrame("Frame", nil, parent)
    local w = math.min(460, parent:GetWidth() - Pad() * 2 - 20)
    box:SetSize(w, 64)
    box:SetPoint("TOPLEFT", parent, "TOPLEFT", Pad() + 10, y - 6)
    local bg = box:CreateTexture(nil, "BACKGROUND")
    bg:SetAllPoints()
    bg:SetColorTexture(0.32, 0.27, 0.2, 0.9)     -- parchment-ish, like the map
    local mine = ns.MyProfessions()
    local keys = { "tailoring", "leatherworking", "skinning", "blacksmithing", "enchanting" }
    local size = d.iconSize or 22
    for i, k in ipairs(keys) do
        local p = ns.PROFESSIONS[k]
        local cx = (i - 0.5) * (w / #keys)
        local cy = (d.style == "text") and -32 or -22
        if d.style ~= "text" then
            local ring = box:CreateTexture(nil, "ARTWORK", nil, 1)
            ring:SetTexture("Interface\\Buttons\\WHITE8X8")
            ring:SetSize(size + 4, size + 4)
            ring:SetPoint("CENTER", box, "TOPLEFT", cx, cy)
            if mine[k] and d.highlightMine then ring:SetVertexColor(1, 0.82, 0.2, 1) else ring:SetVertexColor(0, 0, 0, 0.9) end
            local icon = box:CreateTexture(nil, "ARTWORK", nil, 2)
            icon:SetTexture(p.icon)
            icon:SetTexCoord(0.07, 0.93, 0.07, 0.93)
            icon:SetSize(size, size)
            icon:SetPoint("CENTER", ring, "CENTER")
            if d.roundIcons and box.CreateMaskTexture then
                for _, t in ipairs({ icon, ring }) do
                    local m = box:CreateMaskTexture()
                    m:SetTexture("Interface\\CharacterFrame\\TempPortraitAlphaMask", "CLAMPTOBLACKADDITIVE", "CLAMPTOBLACKADDITIVE")
                    m:SetAllPoints(t)
                    t:AddMaskTexture(m)
                end
            end
        end
        if d.style ~= "icon" then
            local fs = box:CreateFontString(nil, "OVERLAY")
            fs:SetFont(STANDARD_TEXT_FONT, d.textSize or 11, "OUTLINE")
            local r, g, b = 1, 1, 1
            if d.textColor == "profession" then r, g, b = ns.HexToRGB(p.hex)
            elseif d.textColor == "gold" then r, g, b = 1, 0.82, 0 end
            fs:SetTextColor(r, g, b)
            fs:SetText(p.name)
            if d.style == "text" then
                fs:SetPoint("CENTER", box, "TOPLEFT", cx, cy)
            else
                fs:SetPoint("TOP", box, "TOPLEFT", cx, cy - size / 2 - 3)
            end
        end
    end
    return y - 80
end

local function Set(key) return function(v) DB()[key] = v; ns.Apply(); Refresh() end end
local function SetQuiet(key) return function(v) DB()[key] = v; ns.Apply() end end
local function Get(key) return function() return DB()[key] end end

local STYLE_VALUES = { _noLoc = true, both = "Icon + Text", icon = "Icon only", text = "Text only" }
local STYLE_ORDER  = { "both", "icon", "text" }
local COLOR_VALUES = { _noLoc = true, profession = "Profession colors", white = "White", gold = "Gold" }
local COLOR_ORDER  = { "profession", "white", "gold" }

local function BuildGeneral(parent, yOffset)
    local W = EllesmereUI.Widgets
    local y = yOffset
    local _, h

    _, h = W:SectionHeader(parent, "PROFESSION MAP", y); y = y - h
    if not EllesmereUI.IsSearchPrebuild() then
        y = Paragraph(parent, "Open the world map in a capital city (Ironforge, Stormwind, Darnassus, Orgrimmar, " ..
            "Thunder Bluff, Undercity) to see where every profession trainer stands. Hover a pin for the trainer " ..
            "names, click it to set a waypoint.", y)
    end
    _, h = W:Toggle(parent, "Show Trainers on the Map", y, Get("enabled"), Set("enabled"),
        "Also: /profmap toggle"); y = y - h
    _, h = W:Dropdown(parent, "Style", y, STYLE_VALUES, Get("style"), Set("style"), STYLE_ORDER,
        "Icon + Text: profession icon with its name below.\nIcon only / Text only: just one of them."); y = y - h

    _, h = W:SectionHeader(parent, "LOOK", y); y = y - h
    if not EllesmereUI.IsSearchPrebuild() then y = Preview(parent, y) end
    _, h = W:Slider(parent, "Icon Size", y, 12, 40, 1, Get("iconSize"), Set("iconSize")); y = y - h
    _, h = W:Slider(parent, "Text Size", y, 8, 18, 1, Get("textSize"), Set("textSize")); y = y - h
    _, h = W:Dropdown(parent, "Text Color", y, COLOR_VALUES, Get("textColor"), Set("textColor"), COLOR_ORDER); y = y - h
    _, h = W:Toggle(parent, "Round Icons", y, Get("roundIcons"), Set("roundIcons")); y = y - h
    _, h = W:Toggle(parent, "Gold Ring on My Professions", y, Get("highlightMine"), Set("highlightMine"),
        "Professions this character has learned get a gold ring instead of a black one."); y = y - h
    _, h = W:Toggle(parent, "One Pin per Profession", y, Get("merge"), Set("merge"),
        "Trainers of the same profession that stand together (Journeyman + Expert + Artisan) share one pin. " ..
        "The tooltip lists all of them."); y = y - h
    _, h = W:Toggle(parent, "Spread Overlapping Pins", y, Get("spread"), Set("spread"),
        "Pins that would cover each other (e.g. Leatherworking and Skinning in Ironforge) are nudged apart. " ..
        "The waypoint still goes to the exact spot."); y = y - h

    _, h = W:SectionHeader(parent, "FILTER", y); y = y - h
    _, h = W:Toggle(parent, "Only My Faction's Cities", y, Get("factionOnly"), Set("factionOnly")); y = y - h

    _, h = W:SectionHeader(parent, "TRAINERS YOU VISIT", y); y = y - h
    _, h = W:Toggle(parent, "Remember Trainers I Talk To", y, Get("learn"), Set("learn"),
        "When you open a profession trainer, its real position is saved. That fixes pins that are off on " ..
        "Forever and adds trainers that are missing (also outside the capitals)."); y = y - h
    if not EllesmereUI.IsSearchPrebuild() then
        y = Paragraph(parent, ("Saved trainers: %d"):format(ns.LearnedCount()), y, 0.6)
    end
    _, h = W:WideButton(parent, "Forget Saved Trainers", y, function()
        wipe(DB().learned); ns.Apply(); Refresh()
    end, 300); y = y - h

    return math.abs(y)
end

local function BuildProfessions(parent, yOffset)
    local W = EllesmereUI.Widgets
    local y = yOffset
    local _, h
    _, h = W:SectionHeader(parent, "PROFESSION TRAINERS", y); y = y - h
    if not EllesmereUI.IsSearchPrebuild() then
        local names = {}
        local mine = ns.MyProfessions()
        for _, key in ipairs(ns.PROF_ORDER) do
            if mine[key] then names[#names + 1] = ns.PROFESSIONS[key].name end
        end
        y = Paragraph(parent, "Your professions: " .. (#names > 0 and table.concat(names, ", ") or "none learned yet") ..
            ".\nBy default only these are shown on the map. Turn on Show All Professions to see every trainer.", y)
    end
    _, h = W:Toggle(parent, "Show All Professions", y,
        function() return not DB().onlyMine end,
        function(v) DB().onlyMine = not v; ns.Apply(); Refresh() end,
        "Off: only the professions this character has learned (incl. Cooking, First Aid and Fishing).\n" ..
        "On: every profession trainer (pick which ones below)."); y = y - h

    _, h = W:SectionHeader(parent, "SHOW THESE PROFESSIONS", y); y = y - h
    for _, key in ipairs(ns.PROF_ORDER) do
        local p = ns.PROFESSIONS[key]
        _, h = W:Toggle(parent, p.name, y,
            function() return not DB().hide[key] end,
            function(v) DB().hide[key] = (not v) or nil; ns.Apply() end); y = y - h
    end
    _, h = W:WideButton(parent, "Show All", y, function() wipe(DB().hide); ns.Apply(); Refresh() end, 200); y = y - h
    return math.abs(y)
end

local CLASSMODE_VALUES = { _noLoc = true, mine = "My class only", all = "All classes" }
local CLASSMODE_ORDER  = { "mine", "all" }

local function BuildClasses(parent, yOffset)
    local W = EllesmereUI.Widgets
    local y = yOffset
    local _, h
    _, h = W:SectionHeader(parent, "CLASS TRAINERS", y); y = y - h
    if not EllesmereUI.IsSearchPrebuild() then
        local _, tok = UnitClass("player")
        local name = tok and ns.CLASS_NAMES[tok] or "?"
        y = Paragraph(parent, "Shows where your class trainer stands in the capital cities, with the same look as the " ..
            "profession pins. Logged in as: " .. name .. ".", y)
    end
    _, h = W:Toggle(parent, "Show Class Trainers on the Map", y, Get("showClass"), Set("showClass")); y = y - h
    _, h = W:Dropdown(parent, "Which Classes", y, CLASSMODE_VALUES, Get("classMode"), Set("classMode"), CLASSMODE_ORDER,
        "My class only: a Hunter sees Hunter trainers, a Warrior sees Warrior trainers.\n" ..
        "All classes: every class trainer (pick which ones below)."); y = y - h
    _, h = W:Toggle(parent, "Show Pet Trainer", y, Get("showPet"), Set("showPet"),
        "Pet trainer for hunters. In \"All classes\" mode it is shown for every class."); y = y - h

    if DB().classMode == "all" then
        _, h = W:SectionHeader(parent, "SHOW THESE CLASSES", y); y = y - h
        for _, tok in ipairs(ns.CLASS_ORDER) do
            _, h = W:Toggle(parent, ns.CLASS_NAMES[tok], y,
                function() return not DB().hideClass[tok] end,
                function(v) DB().hideClass[tok] = (not v) or nil; ns.Apply() end); y = y - h
        end
        _, h = W:WideButton(parent, "Show All Classes", y, function() wipe(DB().hideClass); ns.Apply(); Refresh() end, 200); y = y - h
    end
    return math.abs(y)
end

local function BuildServices(parent, yOffset)
    local W = EllesmereUI.Widgets
    local y = yOffset
    local _, h
    _, h = W:SectionHeader(parent, "CITY SERVICES", y); y = y - h
    if not EllesmereUI.IsSearchPrebuild() then
        y = Paragraph(parent, "Auction house, bank, mailboxes, repair and more on the city map, " ..
            "with the same look as the trainer pins.", y)
    end
    _, h = W:Toggle(parent, "Show City Services on the Map", y, Get("showServices"), Set("showServices")); y = y - h

    _, h = W:SectionHeader(parent, "SHOW THESE", y); y = y - h
    local tips = {
        repair       = "Armor and weapon merchants that can repair. Merchants close to each other share one pin.",
        reagents     = "Reagent vendors (class reagents like Arcane Powder, Ankhs, Symbols of Kings).",
        battlemaster = "Warsong Gulch, Arathi Basin and Alterac Valley battlemasters.",
        tradegoods   = "Trade goods merchants (thread, vials, flux, ...).",
    }
    for _, k in ipairs(ns.SERVICE_ORDER) do
        local info = ns.PROFESSIONS["s_" .. k]
        _, h = W:Toggle(parent, info.name, y,
            function() return DB().svc[k] and true or false end,
            function(v) DB().svc[k] = v; ns.Apply() end, tips[k]); y = y - h
    end
    return math.abs(y)
end

WarUI.AddModule({
    key         = MODULE_KEY,
    title       = "Profession Map",
    description = "Shows profession and class trainers, the auction house, bank, mailboxes and more on the world map in the capital cities.",
    pages       = { "General", "Professions", "Classes", "Services" },
    buildPage   = function(page, parent, yOffset)
        if page == "Professions" then return BuildProfessions(parent, yOffset) end
        if page == "Classes" then return BuildClasses(parent, yOffset) end
        if page == "Services" then return BuildServices(parent, yOffset) end
        return BuildGeneral(parent, yOffset)
    end,
    onModuleLeave = function()
        local key = EllesmereUI.GetPluginModuleKey(PLUGIN_ID, MODULE_KEY)
        if key then EllesmereUI:InvalidateModulePageCache(key) end
    end,
    onReset = function()
        ns.ResetDB(true)
        ns.Apply()
        Refresh()
    end,
})
