-- ProseccoUI / Integrations / Questie.lua
-- Everything ProseccoUI touches in Questie goes through this file (design
-- §8). Only Questie.db.profile.trackerEnabled, which CLAUDE.md lists as
-- Known; nothing else in Questie is read or written.
--
-- Questie's own tracker builds itself at login only while trackerEnabled is
-- on (Known: Questie 42ee926 QuestieTracker.lua:248-253 Initialize returns
-- early), so a change shows after a /reload. QuestieTracker:Disable is not
-- called: it reloads the UI and clears Questie's lists itself.

local _, ns = ...

local Q = {}
ns.Questie = Q

-- Questie's active profile table (AceDB), nil when Questie is not loaded.
local function Profile()
    local q = _G.Questie
    local db = type(q) == "table" and q.db
    local p = type(db) == "table" and db.profile
    return type(p) == "table" and p or nil
end

function Q.IsLoaded()
    return Profile() ~= nil
end

-- The owned-setting interface Core's TakeOwned/GiveBackOwned use, as in
-- Integrations/Ellesmere.lua (target "questie"). Questie keeps the value in
-- its active profile, so no profile name is stored: a value given back goes
-- into the profile that is active then.
function Q.OwnedProfile() return nil end

-- Returns available, value (nil = not set, Questie's default applies).
function Q.ReadOwned(_, _, key)
    local p = Profile()
    if not p then return false end
    return true, p[key]
end

-- Returns false when Questie is not loaded.
function Q.WriteOwned(_, _, key, value)
    local p = Profile()
    if not p then return false end
    p[key] = value
    return true
end
