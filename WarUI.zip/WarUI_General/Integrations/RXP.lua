-- ProseccoUI / Integrations / RXP.lua
-- Everything ProseccoUI touches in RestedXP Guides goes through this file
-- (design §8 "RXP: tema först, hook sist"). Checked against RXPGuides
-- b30872e (2026-10-06).
--
-- The theme API is the main road: addon:RegisterTheme(theme) adds a theme
-- to RXP's "Choose Theme" list and fills in what it leaves out from RXP Blue
-- (Known: Themes.lua RegisterTheme). _G.RXPGuides_Themes cannot be used:
-- RXP imports it in its OnInitialize, which runs on RXP's own ADDON_LOADED,
-- before our files load (Known: RXPGuides.lua OnInitialize, Locale.lua
-- NewAddon; our toc lists RXPGuides in OptionalDeps).
--
-- Besides the theme: the window parts named on RXPFrame and the step boxes
-- in its CurrentStepFrame.framePool, for the font, background and border
-- pass. Post-hooks only; RXP's spacing and margins inside the guide window are
-- never written. The two anchors we do move (the scroll frame's top, the
-- small windows' titles) are Alexander's decision (design §11 "Beslut
-- 2026-10-07"). Every write (font, text colour, frame level, backdrop colour,
-- header icons, version line, those anchors) is commented where it is made.
-- Everything here except RegisterTheme and RXPFrame is RXP-internal and
-- Assumed: each read checks that the field is there.

local ADDON, ns = ...

local R = {}
ns.RXP = R

-- RXP's AceAddon object, nil when RXP is not loaded (it is an OptionalDep).
-- LibStub comes with EllesmereUI and RXP; GetAddon's second argument makes a
-- missing addon return nil instead of raising.
local function Addon()
    local ace = LibStub("AceAddon-3.0", true)
    local rxp = ace and ace:GetAddon("RXPGuides", true)
    if rxp and type(rxp.RegisterTheme) == "function" then return rxp end
end

function R.IsLoaded()
    return Addon() ~= nil
end

-- Where a theme's texturePath points for our files.
R.TEXTURE_PATH = "Interface/AddOns/" .. ADDON .. "/Media/RXP/"

-- The theme picked in RXP's options (Look and Feel > Choose Theme). Not the
-- one in use: at login RXP falls back to RXP Blue for a theme it does not
-- know yet, and keeps the pick (Known: Themes.lua LoadActiveTheme).
function R.Selected()
    local rxp = Addon()
    local p = rxp and rxp.settings and rxp.settings.profile
    return p and p.activeTheme
end

-- The theme RXP is drawing with now.
function R.ActiveName()
    local rxp = Addon()
    return rxp and rxp.activeTheme and rxp.activeTheme.name
end

-- Registers (or replaces) a theme. When it is the picked one RXP redraws
-- with it: RenderFrame loads the theme, restyles every window part, the
-- arrow's texture among them, and reloads the guide on the current step
-- (Known: GuideWindow.lua:88-106, map.lua:43-49, 60). Not addon:ReloadTheme,
-- which does nothing while RXP's own "Preview Changes" is off.
-- RegisterTheme fills the table in place, so pass a new one each time; a new
-- table is also what makes RXP restyle its step boxes (it compares by identity).
-- Not in combat: RenderFrame restyles Active Targets with SetScale
-- (Known: Targeting.lua:801), a window with secure buttons that RXP itself
-- leaves alone in combat (Known: Targeting.lua:1128, ActiveItemFrame.lua:282).
-- The caller waits for the end of combat (Modules/RXPTheme.lua Apply).
function R.RegisterTheme(theme)
    local rxp = Addon()
    if not rxp then return false end
    rxp:RegisterTheme(theme)
    if R.Selected() == theme.name and type(rxp.RenderFrame) == "function" then
        rxp.RenderFrame("themeReload")
        R.StyleArrowText()
    end
    return true
end

-- The arrow's distance text gets the theme's font and text colour only in
-- RXP's SetupArrow (Known: map.lua:94-99), which RXP runs at its login,
-- before our theme exists, and which also sets the size to 9. The same two
-- writes here, at the size the text has (RXP's Arrow Text Size), instead of
-- calling SetupArrow and putting RXP's sizes back after it.
-- arrowFrame.text and activeTheme are RXP-internal: Assumed, skipped when missing.
function R.StyleArrowText()
    local rxp = Addon()
    local fs = rxp and rxp.arrowFrame and rxp.arrowFrame.text
    local theme = rxp and rxp.activeTheme
    if not (fs and theme and rxp.font) then return end
    local _, size = fs:GetFont()
    if size then fs:SetFont(rxp.font, size, "OUTLINE") end
    if type(theme.textColor) == "table" then fs:SetTextColor(unpack(theme.textColor)) end
end

-- ---------------------------------------------------------------------------
-- The classic guide window (RXP's "V1"; the V2 window is a beta option,
-- off by default, Known: UI/V2/Core.lua). With V2 on RXP hides these frames,
-- and our frames, their children, with them. Whether the V2 window picks up
-- our theme without a /reload is Unverified (RegisterTheme converts it).
-- ---------------------------------------------------------------------------

local function Window() return _G.RXPFrame end

-- Calls fn after RXP has drawn: a step-box layout pass (UpdateText, always
-- called through the table, Known: GuideWindow.lua:1208), a window restyle
-- (UpdateVisuals, from RenderFrame), a font-size change (UpdateGuideFontSize,
-- which resets the header and footer font) and the end of a drag or resize
-- (StopMovingOrSizing, from RXPFrame.OnMouseUp). Hooks cannot be removed, so
-- this runs once; fn gates itself.
local hooked = false
function R.OnRedraw(fn)
    local rxp, F = Addon(), Window()
    if hooked or not (rxp and F) then return end
    hooked = true
    local handler = ns.ErrorHandler("rxp:redraw")
    local function run() xpcall(fn, handler) end
    local CSF = F.CurrentStepFrame
    if CSF and type(CSF.UpdateText) == "function" then hooksecurefunc(CSF, "UpdateText", run) end
    if type(F.UpdateVisuals) == "function" then hooksecurefunc(F, "UpdateVisuals", run) end
    if type(rxp.UpdateGuideFontSize) == "function" then hooksecurefunc(rxp, "UpdateGuideFontSize", run) end
    hooksecurefunc(F, "StopMovingOrSizing", run)
end

-- Runs RXP's own step-box layout once more, after the font pass changed a
-- face or outline: RXP sizes each line from its text height (Known:
-- GuideWindow.lua:1298 GetStringHeight), so a font set after the pass would
-- leave the lines sized for the old font. Our next pass finds every font
-- already set and changes nothing, so this does not repeat. `busy` stops the
-- loop if a font does not take (a font file that cannot be loaded): the pass
-- inside would see a change again and ask for another layout.
local busy = false
function R.Relayout()
    local F = Window()
    local CSF = F and F.CurrentStepFrame
    if busy or not (CSF and type(CSF.UpdateText) == "function") then return end
    busy = true
    xpcall(CSF.UpdateText, ns.ErrorHandler("rxp:relayout"))      -- RXP's code, not ours
    busy = false
end

-- The parts that get our background and border, each with its kind:
-- "header", "list" (the step list), "footer", "step" (a step box) and
-- "badge" (a step box's title badge; owner[i] is its step box). Refilled in
-- place on each call (the passes run on every step change).
local boxes, kind, owner = {}, {}, {}
local function addBox(f, k, own)
    if f then
        local i = #boxes + 1
        boxes[i], kind[i], owner[i] = f, k, own or false
    end
end
function R.Boxes()
    wipe(boxes); wipe(kind); wipe(owner)
    local F = Window()
    if not F then return boxes, kind, owner end
    local add = addBox
    add(F.GuideName, "header")
    add(F.BottomFrame, "list")
    add(F.Footer, "footer")
    local pool = F.CurrentStepFrame and F.CurrentStepFrame.framePool
    if type(pool) == "table" then
        for _, step in ipairs(pool) do
            add(step, "step")
            add(step.number, "badge", step)     -- the title badge on the box's top edge
        end
    end
    return boxes, kind, owner
end

-- The frame level of the step list (Known: GuideWindow.lua:31, a child of
-- RXPFrame). The levels of the header and footer are counted from it.
function R.BaseLevel()
    local F = Window()
    return F and F.BottomFrame and F.BottomFrame:GetFrameLevel() or 0
end

-- Puts one of RXP's window frames at a frame level, so that our background
-- and border (children of that frame, drawn below it) fit between it and
-- what lies under it. RXP sets these levels once, when it creates the
-- frames, and never reads them (Known: GuideWindow.lua:1027, 1403, 1423,
-- 1430, 1455). Written only when it differs. Used on the header, the footer
-- and its two buttons, and the step boxes' title badges.
function R.SetLevel(f, level)
    if f and f:GetFrameLevel() ~= level then f:SetFrameLevel(level) end
end

-- The footer's resize grip and cog (Known: GuideWindow.lua:1429, 1454),
-- which have to stay above the footer.
function R.FooterButtons()
    local F = Window()
    local footer = F and F.Footer
    if footer then return footer.icon, footer.cog end
end

-- Makes RXP's own background on a part transparent; ours is drawn under it.
-- RXP paints every part with the theme's one background colour, which its
-- other windows (item frame, targeting, leveling tracker) use too (Known:
-- GuideWindow.lua:60, 71, 74, 1044, 1047, ActiveItemFrame.lua:218), so the
-- theme cannot do it. RXP sets the colour again when it restyles
-- (UpdateVisuals, a new theme on a step box) and our pass runs after that.
-- Written only when it differs.
function R.ClearBackground(f)
    if not (f.GetBackdropColor and f.SetBackdropColor) then return end
    local _, _, _, a = f:GetBackdropColor()
    if a and a ~= 0 then f:SetBackdropColor(0, 0, 0, 0) end
end

-- RXP's own logo and class icon in the header, from RXP's folder. Pointed
-- at, not copied (RXP's art is CC BY-NC-SA). RXP sets these from the
-- theme's texturePath when it restyles (Known: GuideWindow.lua:78-79,
-- 176-178), so this runs after it, on every pass.
local RXP_TEXTURES = "Interface/AddOns/RXPGuides/Textures/"
local _, playerClass = UnitClass("player")
function R.UseRXPIcons()
    local F = Window()
    local g = F and F.GuideName
    if not g then return end
    if g.icon then g.icon:SetTexture(RXP_TEXTURES .. "rxp_logo-64") end
    if g.classIcon and playerClass then g.classIcon:SetTexture(RXP_TEXTURES .. playerClass) end
end

-- The header's logo and class icon (textures on the header, Known:
-- GuideWindow.lua:1444-1452) and its guide-name line. RXP sets their
-- picture, text and font but never their alpha (Known: grep of RXP's code
-- 2026-10-07: no SetAlpha, Show or Hide on them in the V1 window), so alpha 0
-- hides them and stays. Written only when it differs.
local function SetAlpha(r, a)
    if r and r:GetAlpha() ~= a then r:SetAlpha(a) end
end

function R.SetHeaderIcons(shown)
    local F = Window()
    local g = F and F.GuideName
    if not g then return end
    SetAlpha(g.icon, shown and 1 or 0)
    SetAlpha(g.classIcon, shown and 1 or 0)
end

function R.HeaderText()
    local F = Window()
    local g = F and F.GuideName
    return g and g.text, g
end

function R.SetHeaderTextShown(shown)
    SetAlpha((R.HeaderText()), shown and 1 or 0)
end

-- Calls fn after RXP sets the guide name (Known: GuideWindow.lua:158, 1940,
-- 1942, SetText on the header's string). A post-hook on that one string's
-- method, once; fn gates itself.
local headerHooked = false
function R.OnHeaderText(fn)
    local fs = R.HeaderText()
    if headerHooked or not fs then return end
    headerHooked = true
    local handler = ns.ErrorHandler("rxp:header")
    hooksecurefunc(fs, "SetText", function() xpcall(fn, handler) end)
end

-- What we show of the footer. RXP never shows, hides or fades the footer
-- itself, never hides the cog after creating it, and fades the version line
-- and the buttons only with SetAlpha while a timer bar runs (Known:
-- GuideWindow.lua:1462, Timers.lua:22-24, 118-120, 135, 175). So:
--   - the footer by its alpha: our background and border and the resize grip
--     are its children and follow, and it still gets the mouse at alpha 0;
--   - the cog (a child of RXPFrame, Known: GuideWindow.lua:1454) and the
--     version line (a string on the header, Known: GuideWindow.lua:1415) by
--     Show and Hide, which RXP's alpha writes do not undo.
-- RXP's timer bars are in a frame of their own and are not touched.
-- Written only when it differs.
function R.SetFooter(shown, textShown)
    local F = Window()
    local footer = F and F.Footer
    if not footer then return end
    local a = shown and 1 or 0
    if footer:GetAlpha() ~= a then footer:SetAlpha(a) end
    if footer.cog and footer.cog:IsShown() ~= shown then footer.cog:SetShown(shown) end
    local fs = footer.text
    if fs and fs:IsShown() ~= textShown then fs:SetShown(textShown) end
end

-- True while the mouse is over the footer (its buttons lie inside it).
-- The frame method, not the global MouseIsOver, which Forever does not have.
-- FIELD RESULT 2026-10-06 (build 70235): /dump MouseIsOver gave nil.
-- ProseccoTools reads IsMouseOver on RXP's frames the same way
-- (Modules/RXPGuides.lua:399-400).
function R.FooterHovered()
    local F = Window()
    return F and F.Footer and F.Footer:IsMouseOver() or false
end

-- Calls fn when the mouse enters or leaves the footer or one of its buttons.
-- The footer gets the mouse: RXP gives it OnMouseDown for dragging (Known:
-- GuideWindow.lua:1482), which turns the mouse on (Inferred). Post-hooks,
-- once; fn gates itself. Leaving the footer for a button inside it calls fn
-- too, and fn sees the mouse still over the footer.
local hoverHooked = false
function R.OnFooterHover(fn)
    local F = Window()
    local footer = F and F.Footer
    if hoverHooked or not footer then return end
    hoverHooked = true
    local handler = ns.ErrorHandler("rxp:footer")
    local function run() xpcall(fn, handler) end
    for _, f in ipairs({ footer, footer.icon, footer.cog }) do
        if f then
            f:HookScript("OnEnter", run)
            f:HookScript("OnLeave", run)
        end
    end
end

-- RXP's two small windows outside the guide window: Active Targets
-- (RXPTargetFrame) and Active Items (RXPItemFrame), each a frame with a
-- title badge (.title, three levels above it). RXP paints both with the
-- theme background in their UpdateVisuals, and the targets frame again in
-- addon.targeting:RenderTargetFrameBackground (Known: Targeting.lua:799-904,
-- ActiveItemFrame.lua:206-318). Both are created when first needed, so they
-- are looked up on every call. Their V2 versions (a beta option) are left alone.
local windows, titles = {}, {}
local function addWindow(f)
    if f and not f.v2 then
        windows[#windows + 1] = f
        titles[#windows] = f.title or false
    end
end
function R.Windows()
    wipe(windows); wipe(titles)
    addWindow(_G.RXPTargetFrame)
    addWindow(_G.RXPItemFrame)
    return windows, titles
end

-- Calls fn after RXP restyles one of those windows. The windows come into
-- being later than our login, so this is called on every pass and hooks
-- each window once when it first exists. Post-hooks only; fn gates itself.
local windowHooked = setmetatable({}, { __mode = "k" })
local targetingHooked = false
function R.OnWindowRedraw(fn)
    local handler = ns.ErrorHandler("rxp:windows")
    local function run() xpcall(fn, handler) end
    for _, f in ipairs((R.Windows())) do
        if not windowHooked[f] and type(f.UpdateVisuals) == "function" then
            windowHooked[f] = true
            hooksecurefunc(f, "UpdateVisuals", run)
        end
    end
    local rxp = Addon()
    local t = rxp and rxp.targeting
    if not targetingHooked and t and type(t.RenderTargetFrameBackground) == "function" then
        targetingHooked = true
        hooksecurefunc(t, "RenderTargetFrameBackground", run)
    end
end

-- Places a window's title box: RXP's place moved dx, dy (UI units), or
-- centred over the window at RXP's height moved dy. RXP anchors it once, when it creates
-- the window (TOPLEFT, 5 px in, 8 or 10 px up; Known: ActiveItemFrame.lua:302,
-- Targeting.lua:875) and never again, so RXP's offsets are read the first
-- time and kept. The title box is a plain frame, not secure. Alexander chose
-- moving it over decision 8 (2026-10-07). Written only when it differs.
-- Returns the title's top above the window's top (UI units), or nil when the
-- title is not where RXP put it.
local titleHome = setmetatable({}, { __mode = "k" })   -- title -> { x, y } RXP gave it
function R.PlaceTitle(title, window, centred, dx, dy)
    local point, rel, relPoint, x, y = title:GetPoint(1)
    if not point or rel ~= window then return end
    local home = titleHome[title]
    if not home then
        if point ~= "TOPLEFT" then return end           -- not RXP's anchor; leave it
        home = { x, y }
        titleHome[title] = home
    end
    local wantPoint, wantX, wantY = "TOPLEFT", home[1] + dx, home[2] + dy
    if centred then wantPoint, wantX = "TOP", 0 end
    if point == wantPoint and relPoint == wantPoint
        and math.abs(x - wantX) < 0.01 and math.abs(y - wantY) < 0.01 then return wantY end
    title:ClearAllPoints()
    title:SetPoint(wantPoint, window, wantPoint, wantX, wantY)
    return wantY
end

-- The guide window's scroll frame: the step list's rows and its scroll bar.
function R.ScrollFrame()
    local F = Window()
    return F and F.ScrollFrame
end

-- Moves the scroll frame's top edge down by dy (UI units) from where RXP
-- put it, or back with 0, so the list's rows and the scroll bar (anchored to
-- it) start below our header box when Header Extend reaches over the list
-- (Alexander 2026-10-07: "ner 2 px"; an exception to decision 8, design
-- §11 "Beslut 2026-10-07"). RXP anchors it once, when the file
-- loads (TOPLEFT 5, -5 and BOTTOMRIGHT -20, 7 on BottomFrame; Known:
-- GuideWindow.lua:1494-1495) and never again. Only the top point is
-- replaced. Written only when it differs.
local scrollHome
function R.ShiftScrollFrame(dy)
    local sf = R.ScrollFrame()
    if not sf then return end
    local F = Window()
    local list = F.BottomFrame
    local point, rel, relPoint, x, y = sf:GetPoint(1)
    if not point then return end
    if not scrollHome then
        if point ~= "TOPLEFT" or rel ~= list then return end   -- not RXP's anchor; leave it
        scrollHome = { x, y }
    end
    local wantY = scrollHome[2] - dy
    if point == "TOPLEFT" and rel == list and relPoint == "TOPLEFT" and math.abs(x - scrollHome[1]) < 0.01
        and math.abs(y - wantY) < 0.01 then return end
    sf:SetPoint("TOPLEFT", list, "TOPLEFT", scrollHome[1], wantY)
end

-- RXP's waypoint arrow: one texture that arrowFrame:UpdateVisuals sets from
-- the theme's texturePath (called by SetupArrow) and DrawArrow turns with
-- SetRotation. RXP never sets its vertex colour (Known: map.lua:27-36, 80-85,
-- 120-124).
local function ArrowFrame()
    local rxp = Addon()
    local af = rxp and rxp.arrowFrame
    if af and af.texture and type(af.UpdateVisuals) == "function" then return af end
end

function R.ArrowTexture()
    local af = ArrowFrame()
    return af and af.texture
end

-- Calls fn after RXP sets the arrow's texture. Hooked once; fn gates itself.
local arrowHooked = false
function R.OnArrowRedraw(fn)
    local af = ArrowFrame()
    if arrowHooked or not af then return end
    arrowHooked = true
    local handler = ns.ErrorHandler("rxp:arrow")
    hooksecurefunc(af, "UpdateVisuals", function() xpcall(fn, handler) end)
end

-- Has RXP set the arrow's texture again (and so run fn above). RXP's own
-- function, so our texture is set at the same point RXP sets its own.
function R.RefreshArrow()
    local af = ArrowFrame()
    if af then xpcall(af.UpdateVisuals, ns.ErrorHandler("rxp:arrow"), af) end
end

-- The part of a box RXP paints: its frame shrunk by the backdrop insets
-- (left, right, top, bottom), read from Blizzard's BackdropTemplate data on
-- the frame (Inferred: retail SharedXML Backdrop.lua backdropInfo). RXP's
-- own boxes use 4, 2, 2, 4 (Known: GuideWindow.lua backdrop.edge, .guideName).
function R.Insets(f)
    local ins = f.backdropInfo and f.backdropInfo.insets
    if not ins then return 0, 0, 0, 0 end
    return ins.left or 0, ins.right or 0, ins.top or 0, ins.bottom or 0
end

-- The text RXP draws with the theme font and a fixed "" outline, in the step
-- boxes (title badge and lines) and the header and footer (Known:
-- GuideWindow.lua:1032-1037, 1094-1096, UpdateGuideFontSize). stepText
-- tells the caller which ones RXP sizes its layout from.
local texts, stepText = {}, {}
local function addText(fs, inStep)
    if fs and fs.SetFont then texts[#texts + 1] = fs; stepText[#texts] = inStep end
end
function R.Texts()
    wipe(texts); wipe(stepText)
    local F = Window()
    if not F then return texts, stepText end
    local add = addText
    add(F.GuideName and F.GuideName.text, false)
    add(F.Footer and F.Footer.text, false)
    local pool = F.CurrentStepFrame and F.CurrentStepFrame.framePool
    if type(pool) == "table" then
        for _, step in ipairs(pool) do
            add(step.number and step.number.text, true)
            if type(step.elements) == "table" then
                for _, el in ipairs(step.elements) do add(el.text, true) end
            end
        end
    end
    return texts, stepText
end

-- ---------------------------------------------------------------------------
-- The loaded guide, for the Quest Tracker (Modules/QuestTracker.lua): which
-- quests it names, where the player is in it, and when that changes. All
-- RXP-internal (Assumed, read in RXPGuides 3af2714): addon.currentGuide.steps
-- (step n's index is n, GuideWindow.lua:1959-1961), each step's elements
-- with a numeric questId (accept, complete, turnin and their variants,
-- functions.lua:1164, :1345, :1563), addon.GetGuideProgress (RXPGuides.lua
-- :1397) and addon.GetGuideName (GuideWindow.lua:1531). Each read checks its
-- field: a missing one gives "no guide", never an error.
-- ---------------------------------------------------------------------------

local function CurrentGuide()
    local rxp = Addon()
    local g = rxp and rxp.currentGuide
    -- With no guide picked RXP loads its welcome guide (empty = true, one
    -- step; GuideWindow.lua:1575-1582), which is "no guide" for us.
    if type(g) == "table" and type(g.steps) == "table" and not g.empty then return rxp, g end
end

-- The step the player is on (1-based), or nil.
local function CurrentStep(rxp)
    if type(rxp.GetGuideProgress) ~= "function" then return nil end
    return tonumber((rxp.GetGuideProgress()))
end

-- questID -> the first step at or after the current one that names it, or
-- `past` for a quest the guide names only in steps already behind. nil when
-- no guide is loaded. A new table per call: called once per tracker refresh.
function R.GuideQuests()
    local rxp, g = CurrentGuide()
    if not rxp then return nil end
    local now = CurrentStep(rxp) or 1
    local out, past = {}, #g.steps + 1
    for n, step in ipairs(g.steps) do
        if type(step) == "table" and type(step.elements) == "table" then
            for _, el in ipairs(step.elements) do
                local id = type(el) == "table" and el.questId
                if type(id) == "number" then
                    if n >= now then
                        if not out[id] or out[id] == past then out[id] = n end
                    elseif not out[id] then
                        out[id] = past
                    end
                end
            end
        end
    end
    return out
end

-- name, current step, number of steps; nil when no guide is loaded.
function R.GuideProgress()
    local rxp, g = CurrentGuide()
    if not rxp then return nil end
    local total = #g.steps
    if total == 0 then return nil end
    local name = type(rxp.GetGuideName) == "function" and rxp.GetGuideName(g) or g.name
    local step = math.max(1, math.min(total, CurrentStep(rxp) or 1))
    return tostring(name or ""), step, total
end

-- Calls fn when RXP loads a guide or moves to a step. RXP sends these as
-- AceEvent messages (Known: RXPGuides.lua:115-121 SendEvent -> SendMessage;
-- GuideWindow.lua:793 RXP_STEP_ACTIVATED, :2120 RXP_GUIDE_LOADED; the names
-- are RXP-internal, Assumed). Received on an object of our own embedding
-- AceEvent-3.0, which RXP loads; nothing of RXP's is hooked. Registered once;
-- fn gates itself. Without AceEvent the tracker still follows the guide on
-- its next quest log update.
local guideListener
function R.OnGuideChange(fn)
    if guideListener or not Addon() then return end
    local AceEvent = LibStub("AceEvent-3.0", true)
    if not AceEvent then return end
    guideListener = {}
    AceEvent:Embed(guideListener)
    local function run() xpcall(fn, ns.ErrorHandler("rxp:guide")) end
    guideListener:RegisterMessage("RXP_GUIDE_LOADED", run)
    guideListener:RegisterMessage("RXP_STEP_ACTIVATED", run)
end
