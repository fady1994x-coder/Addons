-- ProseccoUI / Core / Core.lua
-- The SavedVariables table, profiles, ns.Apply(), export/import and /pui.
--
-- One copy of the data (design §6): ns.db IS the active profile table
-- (WarUIGeneralDB.profiles[name]). A profile switch points ns.db at another
-- table and runs ns.Apply(). Nothing else holds a copy, so nothing has to be
-- synced back; code reads ns.db at call time and never keeps it in an upvalue
-- (V2 §6), because a switch, reset or import replaces the table.
--
-- WarUIGeneralDB = {
--   version = 1,
--   activeProfile = { ["Name - Realm"] = "Default" },   -- per character
--   profiles = { Default = { global = { border = {...} }, modules = { <key> = {...} } } },
--   log = { enabled, lines },                           -- Core/Log.lua, outside the profiles
--   owned = { <module key> = { ... } },                 -- ns.OwnedStore, outside the profiles
-- }

local ADDON, ns = ...

ns.version = C_AddOns.GetAddOnMetadata(ADDON, "Version") or "?"
ns.db = nil                     -- the active profile; set at PLAYER_LOGIN

local DB_VERSION = 1
local DEFAULT_PROFILE = "Default"

local GLOBAL_DEFAULTS = {
    border = { style = "solid", size = 1, color = "000000", alpha = 1 },
    -- War UI 3.0 (from ProseccoAdditions 0.7): the colours of module boxes
    -- with "Use Global Background" on: `background` for bodies,
    -- `headerBackground` for header and title boxes (Minimap panels, XP Bar
    -- panel). Defaults: Ellesmere's own window and header colours.
    background = { color = "000000", alpha = 0.75 },
    headerBackground = { color = "1B1B1B", alpha = 1 },
    -- An Ellesmere bar texture under every header colour, or "none" for a
    -- flat colour. Painted through ns.PaintHeader.
    headerTexture = "none",
    -- The Microbar in place of the Minimap's bottom panel, with the clock and
    -- FPS/MS as a badge on the map. Here because both modules read it.
    microbarOnMinimap = false,
}

function ns.Print(msg)
    print("|cffc0392bWar UI|r: " .. tostring(msg))
end

-- ---------------------------------------------------------------------------
-- Helpers
-- ---------------------------------------------------------------------------

-- "RRGGBB" (with or without '#') -> r, g, b in 0..1. Anything else is black,
-- so a hand-edited SavedVariables value cannot break a border.
function ns.HexToRGB(hex)
    local s = tostring(hex or ""):gsub("#", "")
    if not s:match("^%x%x%x%x%x%x$") then s = "000000" end
    return tonumber(s:sub(1, 2), 16) / 255, tonumber(s:sub(3, 4), 16) / 255, tonumber(s:sub(5, 6), 16) / 255
end

function ns.RGBToHex(r, g, b)
    local function byte(v) return math.floor(math.max(0, math.min(1, v or 0)) * 255 + 0.5) end
    return ("%02X%02X%02X"):format(byte(r), byte(g), byte(b))
end

-- A module box's colour: its own (hex, alpha), or the global one of `kind`
-- ("background" or "headerBackground") when `follow` is true.
function ns.BackgroundColor(follow, kind, hex, alpha)
    if follow then
        local g = ns.db.global[kind]
        return g.color, tonumber(g.alpha) or 1
    end
    return hex, alpha
end

-- Paints our header texture `tex` in r, g, b, a: the Global Header
-- Texture tinted by the colour, or the flat colour.
function ns.PaintHeader(tex, r, g, b, a)
    local path = ns.Ellesmere.BarTexturePath(ns.db.global.headerTexture)
    if path then
        tex:SetTexture(path)
        tex:SetVertexColor(r, g, b, a)
    else
        tex:SetVertexColor(1, 1, 1, 1)
        tex:SetColorTexture(r, g, b, a)
    end
end

-- Lays cells out two per row, skipping nil; an odd one gets an empty right
-- half. Returns the new y.
function ns.Rows(W, parent, y, ...)
    local cells = {}
    for i = 1, select("#", ...) do
        local c = select(i, ...)
        if c then cells[#cells + 1] = c end
    end
    for i = 1, #cells, 2 do
        local _, h = W:DualRow(parent, y, cells[i], cells[i + 1] or { type = "spacer" })
        y = y - h
    end
    return y
end

-- A colour picker for one module box, or nil while the module follows the
-- global colour (the row is hidden then). Lay it out with ns.Rows. spec:
-- text, tooltip, cfg (function returning the table), colorKey, alphaKey
-- (nil: no alpha), default (alpha), follows (function), onChange, and
-- optional disabled/disabledTooltip.
function ns.BackgroundCell(spec)
    if spec.follows() then return nil end
    return { type = "colorpicker", text = spec.text, tooltip = spec.tooltip, hasAlpha = spec.alphaKey ~= nil,
        disabled = spec.disabled, disabledTooltip = spec.disabledTooltip,
        getValue = function()
            local c = spec.cfg()
            local r, g, b = ns.HexToRGB(c[spec.colorKey])
            return r, g, b, spec.alphaKey and (tonumber(c[spec.alphaKey]) or spec.default) or 1
        end,
        setValue = function(r, g, b, a)
            local c = spec.cfg()
            c[spec.colorKey] = ns.RGBToHex(r, g, b)
            if spec.alphaKey then c[spec.alphaKey] = a or 1 end
            spec.onChange()
        end }
end

-- The module's "Use Global Background" toggle; `t` returns the table holding
-- `useGlobalBackground`.
function ns.UseGlobalBackgroundCell(t, onChange, tip)
    return { type = "toggle", text = "Use Global Background",
        tooltip = tip or "Draw this module's backgrounds with the Global Background and Global Header Background on the Global Settings page.",
        getValue = function() return t().useGlobalBackground == true end,
        setValue = function(v)
            t().useGlobalBackground = v and true or false
            onChange()
            ns.Ellesmere.RebuildPage()
        end }
end

-- The Microbar's height while it sits under the minimap, in screen units,
-- nil when it does not. The Microbar writes it; the Minimap reads it to draw
-- one border round map and bar. Runtime only.
local minimapBar
local minimapBarFns = {}
function ns.MinimapBar() return minimapBar end
function ns.OnMinimapBar(fn)
    for _, f in ipairs(minimapBarFns) do
        if f == fn then return end
    end
    minimapBarFns[#minimapBarFns + 1] = fn
end
function ns.SetMinimapBar(h)
    if h == minimapBar then return end
    minimapBar = h
    for _, f in ipairs(minimapBarFns) do xpcall(f, ns.ErrorHandler("core:minimapBar")) end
end

function ns.DeepCopy(v)
    if type(v) ~= "table" then return v end
    local out = {}
    for k, nested in pairs(v) do out[k] = ns.DeepCopy(nested) end
    return out
end

-- Missing keys only; a value the user has set is never overwritten.
local function FillDefaults(dst, src)
    for k, v in pairs(src) do
        if type(v) == "table" then
            if type(dst[k]) ~= "table" then dst[k] = {} end
            FillDefaults(dst[k], v)
        elseif dst[k] == nil then
            dst[k] = v
        end
    end
end
ns.FillDefaults = FillDefaults

-- ---------------------------------------------------------------------------
-- Profiles
-- ---------------------------------------------------------------------------

local charKey                   -- "Name - Realm", read once at PLAYER_LOGIN

function ns.CharKey() return charKey or "?" end

-- Fills a profile table with defaults: the global settings and one table per
-- registered module (enabled = false unless the profile says otherwise).
local function FillProfile(p)
    if type(p.global) ~= "table" then p.global = {} end
    FillDefaults(p.global, GLOBAL_DEFAULTS)
    if type(p.modules) ~= "table" then p.modules = {} end
    for _, m in ipairs(ns.ModuleList()) do
        if type(p.modules[m.key]) ~= "table" then p.modules[m.key] = {} end
        FillDefaults(p.modules[m.key], m.defaults)
    end
    return p
end

-- The defaults of the global table only (General page's Reset).
function ns.ResetGlobal()
    ns.db.global = {}
    FillDefaults(ns.db.global, GLOBAL_DEFAULTS)
    ns.Apply()
end

-- A module's settings back to its defaults. `enabled` is kept: Reset changes
-- how a module looks, switching it off goes through its own toggle.
function ns.ResetModuleSettings(key, defaults)
    local enabled = ns.db.modules[key].enabled
    local t = {}
    FillDefaults(t, defaults)
    t.enabled = enabled
    ns.db.modules[key] = t
    ns.Apply()
end

function ns.ActiveProfileName()
    local db = WarUIGeneralDB
    return (type(db) == "table" and db.activeProfile and db.activeProfile[ns.CharKey()]) or DEFAULT_PROFILE
end

function ns.ProfileNames()
    local out = {}
    for name in pairs(WarUIGeneralDB.profiles) do out[#out + 1] = name end
    table.sort(out)
    return out
end

-- Points this character and ns.db at `name` and redraws.
local function Activate(name)
    WarUIGeneralDB.activeProfile[ns.CharKey()] = name
    ns.db = FillProfile(WarUIGeneralDB.profiles[name])
    ns.Log("PROFILE", "active profile: %s", name)
    local needReload = ns.Apply()
    if #needReload > 0 then
        ns.Print(table.concat(needReload, ", ") .. ": type /reload to finish the profile switch.")
    end
end

local function CleanName(name)
    return tostring(name or ""):gsub("^%s+", ""):gsub("%s+$", "")
end

function ns.SwitchProfile(name)
    if not WarUIGeneralDB.profiles[name] then return false, "no such profile." end
    if name ~= ns.ActiveProfileName() then Activate(name) end
    return true
end

-- Creates a profile and switches this character to it. `source` = nil for the
-- installed defaults, or the name of a profile to copy.
function ns.CreateProfile(name, source)
    name = CleanName(name)
    if name == "" then return false, "type a profile name first." end
    if WarUIGeneralDB.profiles[name] then return false, "a profile with that name already exists." end
    local src = source and WarUIGeneralDB.profiles[source]
    WarUIGeneralDB.profiles[name] = src and ns.DeepCopy(src) or {}
    Activate(name)
    return true, name
end

-- Overwrites the active profile with a copy of another one.
function ns.CopyProfileInto(name)
    local src = WarUIGeneralDB.profiles[name]
    if not src then return false, "no such profile." end
    local active = ns.ActiveProfileName()
    if name == active then return false, "that is the active profile." end
    WarUIGeneralDB.profiles[active] = ns.DeepCopy(src)
    Activate(active)
    return true
end

function ns.DeleteProfile(name)
    local profiles = WarUIGeneralDB.profiles
    if not profiles[name] then return false, "no such profile." end
    if #ns.ProfileNames() < 2 then return false, "this is the only profile." end
    profiles[name] = nil
    -- Every character that used it falls back to the first profile left.
    local fallback = ns.ProfileNames()[1]
    for key, p in pairs(WarUIGeneralDB.activeProfile) do
        if p == name then WarUIGeneralDB.activeProfile[key] = fallback end
    end
    if ns.ActiveProfileName() == fallback and ns.db ~= profiles[fallback] then
        Activate(fallback)
    end
    return true, fallback
end

-- The active profile back to the installed defaults.
function ns.ResetProfile()
    local active = ns.ActiveProfileName()
    WarUIGeneralDB.profiles[active] = {}
    Activate(active)
end

-- ---------------------------------------------------------------------------
-- Export / import of the active profile as a readable Lua table, so it can be
-- edited by hand or kept as a backup (from ProseccoTools Core.lua:458-525).
-- ---------------------------------------------------------------------------

local EXPORT_PREFIX = "PUI1"

local function Serialize(v, out)
    local t = type(v)
    if t == "table" then
        out[#out + 1] = "{"
        -- Sorted keys: the same profile always gives the same text.
        local keys = {}
        for k in pairs(v) do
            if type(k) == "string" or type(k) == "number" then keys[#keys + 1] = k end
        end
        table.sort(keys, function(a, b)
            if type(a) == type(b) then return a < b end
            return type(a) == "number"
        end)
        for _, k in ipairs(keys) do
            if type(k) == "string" then
                out[#out + 1] = "[" .. ("%q"):format(k) .. "]="
            else
                out[#out + 1] = "[" .. ("%.14g"):format(k) .. "]="
            end
            Serialize(v[k], out)
            out[#out + 1] = ","
        end
        out[#out + 1] = "}"
    elseif t == "string" then
        out[#out + 1] = ("%q"):format(v)
    elseif t == "number" then
        out[#out + 1] = ("%.14g"):format(v)
    elseif t == "boolean" then
        out[#out + 1] = tostring(v)
    else
        out[#out + 1] = "nil"
    end
end

function ns.ExportProfile()
    local out = {}
    Serialize(ns.db, out)
    return EXPORT_PREFIX .. table.concat(out)
end

-- An export is a table of strings, numbers and booleans. setfenv alone does not
-- stop code in pasted text: strings keep their methods and a function literal
-- can loop forever. Outside string literals, a call needs "(" and a loop needs
-- "function"; an export has neither, nor a long string ("[[", "[=").
local function IsPlainData(text)
    local i, n = 1, #text
    while i <= n do
        local c = text:sub(i, i)
        if c == '"' or c == "'" then            -- skip a quoted string, escapes included
            i = i + 1
            while i <= n and text:sub(i, i) ~= c do
                if text:sub(i, i) == "\\" then i = i + 1 end
                i = i + 1
            end
        elseif c == "(" or text:find("^%[[%[=]", i) or text:find("^function", i) then
            return false
        end
        i = i + 1
    end
    return true
end

-- Replaces the active profile. Returns true, or false and a reason to print.
function ns.ImportProfile(text)
    text = CleanName(text):gsub("^" .. EXPORT_PREFIX, "")
    if text == "" then return false, "nothing to import." end
    if not text:match("^%b{}$") or not IsPlainData(text) then
        return false, "that does not look like a War UI export."
    end
    local fn = loadstring("return " .. text)
    if not fn then return false, "could not read that text." end
    setfenv(fn, {})                       -- no globals
    -- The text comes from outside the addon; a malformed table must not throw.
    local ok, data = pcall(fn)
    if not ok or type(data) ~= "table" then return false, "could not read that text." end
    if type(data.global) ~= "table" and type(data.modules) ~= "table" then
        return false, "no War UI settings found in that text."
    end
    local active = ns.ActiveProfileName()
    WarUIGeneralDB.profiles[active] = data
    Activate(active)
    return true
end

-- ---------------------------------------------------------------------------
-- Startup
-- ---------------------------------------------------------------------------

-- SavedVariables exist from our ADDON_LOADED. Only the shape is checked here;
-- profile contents get their defaults when they become active.
local function InitDB()
    if type(WarUIGeneralDB) ~= "table" then WarUIGeneralDB = {} end
    local db = WarUIGeneralDB
    db.version = db.version or DB_VERSION
    if type(db.activeProfile) ~= "table" then db.activeProfile = {} end
    if type(db.profiles) ~= "table" then db.profiles = {} end
    if type(db.log) ~= "table" then db.log = {} end
    if type(db.owned) ~= "table" then db.owned = {} end
    if type(db.chars) ~= "table" then db.chars = {} end
end

-- Another addon's values from before a module took them over, given back
-- when the module goes off. Account-wide, not in a profile: the values
-- belong to the other addon, and a profile switch, reset or import must not
-- carry them off or throw them away.
function ns.OwnedStore(key)
    local owned = WarUIGeneralDB.owned
    if type(owned[key]) ~= "table" then owned[key] = {} end
    return owned[key]
end

-- This character's table in WarUIGeneralDB.chars: data that belongs to the
-- character, not to a profile.
local function Char()
    local chars = WarUIGeneralDB.chars
    local key = ns.CharKey()
    if type(chars[key]) ~= "table" then chars[key] = {} end
    local c = chars[key]
    if type(c.modules) ~= "table" then c.modules = {} end
    return c
end

-- Module `key`'s own runtime table for this character (XP Bar's session),
-- kept over a /reload. Not settings: no defaults, no Reset, no export.
function ns.CharStore(key)
    local modules = Char().modules
    if type(modules[key]) ~= "table" then modules[key] = {} end
    return modules[key]
end

-- time() at this character's last real login; the same after a /reload.
function ns.LoginStamp() return Char().login end

-- The integration that reads and writes an owned target: Questie's tracker
-- flag, or one of Ellesmere's settings tables (Integrations/Ellesmere.lua
-- ReadOwned lists those targets). Both have OwnedProfile/ReadOwned/WriteOwned.
local function Owner(target)
    if target == "questie" then return ns.Questie end
    return ns.Ellesmere
end

-- Takes over another addon's settings for module `key`. `owned` lists
-- { target, key, value, label } (targets as in Owner above). Saves what each
-- setting is now (once: a second press must not
-- save our own value as "before"), then writes the value the module needs.
-- Prints the labels of the settings it could not reach (addon not loaded).
function ns.TakeOwned(key, owned, tag)
    local store = ns.OwnedStore(key)
    local missing = {}
    for _, o in ipairs(owned) do
        local I = Owner(o.target)
        local profile = I.OwnedProfile(o.target)
        local found, old = I.ReadOwned(o.target, profile, o.key)
        if found then
            local saved = false
            for _, r in ipairs(store) do
                if r.target == o.target and r.key == o.key and r.profile == profile then saved = true break end
            end
            if not saved then
                store[#store + 1] = { target = o.target, profile = profile, key = o.key, value = old }
            end
            I.WriteOwned(o.target, profile, o.key, o.value)
            ns.Log(tag, "owned %s %s = %s (was %s)", o.target, o.key, tostring(o.value), tostring(old))
        else
            missing[#missing + 1] = o.label
        end
    end
    if #missing > 0 then
        ns.Print("not loaded, left alone: " .. table.concat(missing, ", ") .. ".")
    end
end

-- Writes back every value module `key` saved (nil = the other addon's
-- default) into the profile it was taken from. One that cannot be written
-- now (its addon is disabled) is kept for the next time the module goes off.
-- `onlyTarget` limits it to that target's entries (a target the module no
-- longer owns). Returns true when at least one value was written back.
function ns.GiveBackOwned(key, tag, onlyTarget)
    local store = ns.OwnedStore(key)
    local wrote = false
    for i = #store, 1, -1 do
        local r = store[i]
        if (onlyTarget == nil or r.target == onlyTarget)
           and Owner(r.target).WriteOwned(r.target, r.profile, r.key, r.value) then
            ns.Log(tag, "restored %s %s = %s", r.target, r.key, tostring(r.value))
            table.remove(store, i)
            wrote = true
        end
    end
    return wrote
end

-- Like TakeOwned, but only when a value is not what the module needs.
-- Returns true when something was written.
function ns.EnsureOwned(key, owned, tag)
    local differs = false
    for _, o in ipairs(owned) do
        local I = Owner(o.target)
        local ok, found, cur = pcall(function() return I.ReadOwned(o.target, I.OwnedProfile(o.target), o.key) end)
        if ok and found and cur ~= o.value then differs = true break end
    end
    if differs then ns.TakeOwned(key, owned, tag) end
    return differs
end

local boot = CreateFrame("Frame")
boot:RegisterEvent("ADDON_LOADED")
boot:RegisterEvent("PLAYER_LOGIN")
boot:RegisterEvent("PLAYER_ENTERING_WORLD")
boot:SetScript("OnEvent", function(self, event, name)
    if event == "ADDON_LOADED" then
        if name ~= ADDON then return end
        self:UnregisterEvent("ADDON_LOADED")
        InitDB()
    elseif event == "PLAYER_LOGIN" then
        self:UnregisterEvent("PLAYER_LOGIN")
        charKey = UnitName("player") .. " - " .. GetRealmName()
        -- One-time moves of old settings (Register.lua), before anything reads them.
        if ns.MigrateProfiles then
            xpcall(ns.MigrateProfiles, ns.ErrorHandler("core:migrate"))
        end
        local profile = ns.ActiveProfileName()
        if type(WarUIGeneralDB.profiles[profile]) ~= "table" then WarUIGeneralDB.profiles[profile] = {} end
        WarUIGeneralDB.activeProfile[charKey] = profile
        ns.db = FillProfile(WarUIGeneralDB.profiles[profile])
        ns.LogSessionHeader(ns.HookErrors())
        ns.Apply(true)
        ns.Options.Register()
        -- After Ellesmere's own login pass (its profile is active then).
        C_Timer.After(0.5, function() if ns.EnsureAtLogin then ns.EnsureAtLogin() end end)
    elseif event == "PLAYER_ENTERING_WORLD" then
        -- The first one of a UI load: a real login (isInitialLogin) or a
        -- /reload. No stamp yet (first start): this load counts as the login.
        self:UnregisterEvent("PLAYER_ENTERING_WORLD")
        local c = Char()
        if name == true or c.login == nil then c.login = time() end
    end
end)

-- ---------------------------------------------------------------------------
-- /pui
-- ---------------------------------------------------------------------------

SLASH_WARUIGENERAL1 = "/waruigeneral"
SLASH_WARUIGENERAL2 = "/pui"
SlashCmdList.WARUIGENERAL = function(msg)
    msg = tostring(msg or "")
    local cmd, rest = msg:match("^%s*(%S*)%s*(.-)%s*$")
    cmd = cmd:lower()
    if cmd == "log" then
        ns.LogCommand(rest:lower())
    elseif cmd == "mark" then
        if rest == "" then rest = "(no text)" end
        ns.Log("MARK", "%s", rest)
        ns.Print("marker saved: \"" .. rest .. "\" -- written to disk on /reload.")
    elseif cmd == "profile" then
        ns.Print("character " .. ns.CharKey() .. ", profile \"" .. ns.ActiveProfileName()
            .. "\" (" .. #ns.ProfileNames() .. " profiles).")
    elseif cmd == "" then
        ns.Options.Open()
    else
        ns.Print("/pui (or /waruigeneral)  open the settings  |  /pui log [n|clear|on|off]  |  /pui mark <text>  |  /pui profile")
    end
end
