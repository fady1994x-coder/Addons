-- ProseccoUI / Core / Modules.lua
-- The module registry and the one on/off path (design §7).
--
-- A module file registers itself while it loads and does nothing else:
--   local M = ns.RegisterModule("panels", {
--       title    = "Panels",
--       pages    = { "Panels" },
--       defaults = { list = {}, nextId = 1 },     -- `enabled = false` is added here
--       affects  = { "Hides Blizzard's quest list." },  -- nil: switches on without a popup
--       reload   = true,                         -- on/off needs a /reload afterwards
--       locked   = "reason",                     -- cannot be switched on (not tested yet); off in every profile
--   })
--   function M:Enable() end      -- lazy, idempotent; creates frames, registers events
--   function M:Disable() end     -- removes what is visible, or reload = true says it can't
--   function M:Apply() end       -- reads ns.db.modules.<key> at call time; any number of runs
--   function M:BuildPage(pageName, parent, y, W) ... return y end   -- the new y, as ns.Border.Rows
--   function M:SwitchedOn() end  -- optional: only when the user turns it on on its page (after
--                                -- the popup) and Enable worked; never at login or on a profile switch
--
-- Core never names a module. A module never reads another module's table.

local _, ns = ...

local list, byKey = {}, {}
local running = {}      -- key -> true between a successful Enable and the next Disable (runtime only)
local failed = {}       -- key -> true after a failed Enable: not retried until /reload or switched off

function ns.RegisterModule(key, def)
    assert(type(key) == "string" and key:match("^%a[%w_]*$"), "ProseccoUI: bad module key")
    assert(not byKey[key], "ProseccoUI: module registered twice: " .. key)
    -- Ellesmere refuses the whole plugin on a duplicate key or a missing title,
    -- which would take the core pages with it.
    assert(key ~= "General" and key ~= "Profiles", "ProseccoUI: module key taken by the core: " .. key)
    assert(type(def.title) == "string" and type(def.pages) == "table", "ProseccoUI: module needs title and pages: " .. key)
    def.key = key
    def.defaults = def.defaults or {}
    if def.defaults.enabled == nil then def.defaults.enabled = false end   -- every module default OFF
    list[#list + 1] = def
    byKey[key] = def
    return def
end

function ns.ModuleList() return list end
function ns.GetModule(key) return byKey[key] end
-- A module with `locked` (a reason string; not tested yet) is off in every
-- profile; the saved `enabled` is kept for when the lock is lifted.
function ns.IsModuleEnabled(key) return ns.db.modules[key].enabled == true and not byKey[key].locked end

-- One broken module must not take the others down (ProseccoTools lesson):
-- the error is logged with a stack and still shown by BugSack.
local function Call(M, method)
    if type(M[method]) ~= "function" then return true end
    return xpcall(function() M[method](M) end, ns.ErrorHandler(M.key .. ":" .. method))
end

-- Brings every module in line with the active profile (Enable/Disable where
-- `enabled` and the running state differ), then redraws the running ones.
-- Runs at login, after every settings change and after a profile switch.
-- Returns the titles of `reload` modules that changed state, for the caller
-- to ask for a /reload.
-- War UI 2.5: on/off of a `reload` module waits for ONE reload. The state
-- each module had at login; a module whose switch differs from it is pending.
local atLoginState = {}

-- Titles of the `reload` modules switched since login (empty: nothing to do).
function ns.PendingReload()
    local out = {}
    for _, M in ipairs(list) do
        if M.reload and atLoginState[M.key] ~= nil and ns.IsModuleEnabled(M.key) ~= atLoginState[M.key] then
            out[#out + 1] = M.title
        end
    end
    return out
end

function ns.Apply(atLogin)
    local needReload, status = {}, {}
    if atLogin then
        for _, M in ipairs(list) do atLoginState[M.key] = ns.IsModuleEnabled(M.key) end
    end
    for _, M in ipairs(list) do
        local want = ns.IsModuleEnabled(M.key)
        if not want then failed[M.key] = nil end
        if want ~= (running[M.key] == true) and not failed[M.key] then
            if want then
                local ok = Call(M, "Enable")
                -- A failed Enable is not running (no Apply on half a module) and is
                -- not retried on every settings change, which would repeat the error.
                running[M.key] = ok or nil
                failed[M.key] = (not ok) or nil
                if not ok then status[#status + 1] = M.key .. " FAILED" end
            else
                Call(M, "Disable")
                running[M.key] = nil
            end
            if M.reload and not atLogin then needReload[#needReload + 1] = M.title end
        end
        if running[M.key] then
            Call(M, "Apply")
            status[#status + 1] = M.key
        end
    end
    if atLogin then
        ns.Log("SESSION", "modules on: %s", #status > 0 and table.concat(status, ", ") or "none")
    end
    return needReload
end

-- The module page's on/off toggle. A module with `affects` asks first, in
-- Ellesmere's popup, listing what it changes in other addons; Cancel changes
-- nothing (`onCancel` lets the toggle redraw).
function ns.SetModuleEnabled(key, on, onCancel)
    local M = byKey[key]
    -- SwitchedOn writes the settings a module owns in another addon (design
    -- §11 decision 4): only on this explicit switch, never at login, so a
    -- value changed in the other addon is not silently rewritten.
    local function commit()
        ns.db.modules[key].enabled = on
        ns.Apply()
        if on and running[key] then Call(M, "SwitchedOn") end
        -- Rows greyed out by `enabled` keep their old state until the page is
        -- redrawn (FIELD RESULT 2026-10-08 (build 70245): Quest Tracker's
        -- button stayed grey until another page was opened). War UI 2.0: every
        -- module is a tab of one row and the General tab shows every switch,
        -- so all cached tabs are dropped, not only the visible one refreshed.
        ns.Options.Refresh()
    end
    -- No confirm popup (2.4) and no reload per switch (2.5): switch as many
    -- modules as you like, then press Reload UI once (General tab, or the top
    -- of the module's tab).
    commit()
    -- War UI 3.0: a module's sidebar row also comes and goes with a reload.
    local pending = ns.Options.Pending and ns.Options.Pending() or ns.PendingReload()
    if #pending > 0 then
        ns.Print("waiting for a reload: " .. table.concat(pending, ", ") .. ". Press Reload UI (War UI > General) when you are done.")
    end
end

-- The Reload UI button.
function ns.ReloadNow()
    if InCombatLockdown() then ns.Print("type /reload after combat.") return end
    ReloadUI()
end

-- War UI 2.4: at login, every running module with `Ensure` (Chat, Quest
-- Tracker) puts the settings it needs in other addons back in place, e.g.
-- after an EllesmereUI profile import overwrote them. If anything had to be
-- written, the UI reloads once so Ellesmere builds with it (never twice in
-- two minutes, so a value that will not stick cannot loop).
function ns.EnsureAtLogin()
    local changed = {}
    for _, M in ipairs(list) do
        if running[M.key] and type(M.Ensure) == "function" then
            local ok, res = xpcall(M.Ensure, ns.ErrorHandler(M.key .. ":Ensure"))
            if ok and res then changed[#changed + 1] = M.title end
        end
    end
    if #changed == 0 then return end
    local last = tonumber(WarUIGeneralDB.ensureReloadAt) or 0
    if InCombatLockdown() or (time() - last) < 120 then
        ns.Print("set up " .. table.concat(changed, ", ") .. ". Type /reload to finish.")
        return
    end
    WarUIGeneralDB.ensureReloadAt = time()
    ns.Print("set up " .. table.concat(changed, ", ") .. " - reloading.")
    C_Timer.After(1, function()
        if InCombatLockdown() then ns.Print("type /reload after combat to finish.") else ReloadUI() end
    end)
end
