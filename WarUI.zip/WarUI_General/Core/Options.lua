-- WarUI_General / Core / Options.lua (from ProseccoUI / ProseccoAdditions)
-- Our rows in Ellesmere's options panel, built with Ellesmere's own widgets
-- through the plugin API (EllesmereUI/PLUGINS_API.md), via the War UI hub.
--
-- War UI 3.0 (2026-10-16), laid out as ProseccoAdditions 0.7:
--   General   (tabs General | Global Settings | Profiles)  - first row
--   <one row per module (3.0.1: on or off)>, then Click Cast - own tabs each
-- The plugin API takes the sidebar as a snapshot when it registers (PLAYER_LOGIN),
-- so a module just switched on gets its row after a reload (Reload UI on the
-- General tab, which also lists what is waiting).
--
-- A module can live inside another module's row (`hostPage = "<host key>"`,
-- Guide Highlight in Quest Tracker); with the host off it gets a row of its own.
-- Rows that are not modules (Click Cast, own SavedVariables) come in through
-- ns.Options.AddPage.

local _, ns = ...

ns.Options = {}

local GENERAL = "General"       -- the first row's key
local menuKeys = { GENERAL }    -- the row keys registered this session
local inMenu = {}               -- module key -> true when it has (or is in) a row this session
local registered = false

local function RebuildAll()
    ns.Ellesmere.RebuildPages(menuKeys)
end
ns.Options.RebuildAll = RebuildAll

-- Drop every cached page of ours and rebuild the visible one (one frame
-- later, so the click that changed the data finishes first).
function ns.Options.Refresh()
    C_Timer.After(0, function()
        local eui = _G.EllesmereUI
        if not (eui and eui.GetPluginModuleKey) then return end
        local active = eui:GetActiveModule()
        local ours = false
        for _, k in ipairs(menuKeys) do
            local key = eui.GetPluginModuleKey("WarUI", k)
            if key then
                eui:InvalidateModulePageCache(key)
                if key == active then ours = true end
            end
        end
        if ours then eui:RefreshPage(true) end
    end)
end

-- ---------------------------------------------------------------------------
-- Copy / paste window for export and import (from ProseccoTools PT.ShowText).
-- Created the first time it is needed; no global name.
-- ---------------------------------------------------------------------------

local textFrame
local function ShowText(title, text, onImport)
    if not textFrame then
        local f = CreateFrame("Frame", nil, UIParent, "BasicFrameTemplateWithInset")
        f:SetSize(620, 400); f:SetPoint("CENTER")
        -- Above Ellesmere's options panel (DIALOG, level 100: at DIALOG this
        -- window opened BEHIND it, so a click into the import box landed on
        -- the panel and nothing could be typed) and one strata below its
        -- confirm popup (FULLSCREEN_DIALOG), so "Import?" opens on top of this.
        f:SetFrameStrata("FULLSCREEN")
        f:SetToplevel(true)
        f:SetClampedToScreen(true)
        f:SetMovable(true); f:EnableMouse(true); f:RegisterForDrag("LeftButton")
        f:SetScript("OnDragStart", f.StartMoving); f:SetScript("OnDragStop", f.StopMovingOrSizing)
        f.title = f:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
        f.title:SetPoint("TOP", 0, -5)
        local sf = CreateFrame("ScrollFrame", nil, f, "UIPanelScrollFrameTemplate")
        sf:SetPoint("TOPLEFT", 10, -30); sf:SetPoint("BOTTOMRIGHT", -30, 42)
        local eb = CreateFrame("EditBox", nil, sf)
        eb:SetMultiLine(true); eb:SetFontObject(ChatFontNormal); eb:SetWidth(560)
        eb:SetHeight(1500); eb:SetAutoFocus(false)
        -- No length limit: an export is several thousand characters.
        eb:SetMaxLetters(0)
        if eb.SetMaxBytes then eb:SetMaxBytes(0) end
        eb:EnableMouse(true)
        eb:SetScript("OnEscapePressed", function() f:Hide() end)
        sf:SetScrollChild(eb)
        -- A click anywhere in the text area puts the cursor in the box.
        sf:EnableMouse(true)
        sf:SetScript("OnMouseDown", function() eb:SetFocus() end)
        f.edit = eb
        local btn = CreateFrame("Button", nil, f, "UIPanelButtonTemplate")
        btn:SetSize(120, 24); btn:SetPoint("BOTTOM", 0, 12)
        btn:SetText("Import")
        btn:SetScript("OnClick", function()
            if f.onImport then f.onImport(f.edit:GetText()) end
        end)
        f.button = btn
        textFrame = f
    end
    textFrame.title:SetText(title)
    textFrame.edit:SetText(text or "")
    textFrame.onImport = onImport
    textFrame.button:SetShown(onImport ~= nil)
    textFrame:Show()
    textFrame:Raise()
    if onImport then textFrame.edit:SetFocus() else textFrame.edit:HighlightText() end
end


-- ---------------------------------------------------------------------------
-- General: About, the modules, Reload UI. Global Settings: the border,
-- backgrounds and header texture the modules share, with a preview box.
-- ---------------------------------------------------------------------------

local preview                   -- the preview box on the newest built Global Settings page

local function RefreshPreview()
    if preview then ns.Border.Apply(preview, ns.db.global.border) end
end

local function ByTitle(a, b) return a.title < b.title end

-- Titles of modules whose row is out of date: switched on without a row, or
-- off with one. Empty before registration.
function ns.Options.MenuPending()
    local out = {}
    if not registered then return out end
    for _, M in ipairs(ns.ModuleList()) do
        if not M.hostPage and #M.pages > 0 and ns.IsModuleEnabled(M.key) and not inMenu[M.key] then
            out[#out + 1] = M.title
        end
    end
    return out
end

-- Everything a reload would bring in line: `reload` modules switched since
-- login and modules whose sidebar row is out of date.
local function Pending()
    local out, seen = {}, {}
    for _, list in ipairs({ ns.PendingReload(), ns.Options.MenuPending() }) do
        for _, t in ipairs(list) do
            if not seen[t] then seen[t] = true; out[#out + 1] = t end
        end
    end
    return out
end
ns.Options.Pending = Pending

-- The module's on/off toggle cell (General tab and the top of its own row).
local function ToggleCell(M, text)
    local needsRow = not M.hostPage and #M.pages > 0
    return { type = "toggle", text = text or M.title,
        tooltip = (M.description or "") ..
            (M.affects and ("\n\nChanges other addons:\n- " .. table.concat(M.affects, "\n- ")) or "") ..
            ((M.reload or needsRow) and "\n\nPress Reload UI (General tab) when you are done switching: the module's own row in the sidebar comes and goes with a reload." or ""),
        disabled = M.locked and function() return true end or nil,
        disabledTooltip = M.locked,
        getValue = function() return ns.IsModuleEnabled(M.key) end,
        setValue = function(v)
            ns.SetModuleEnabled(M.key, v and true or false, ns.Ellesmere.RefreshPage)
        end }
end
ns.Options.ToggleCell = ToggleCell

-- One reload for every switch made since login.
local function ReloadRow(W, parent, y, always)
    local pending = Pending()
    if #pending == 0 and not always then return y end
    local _, h = W:DualRow(parent, y,
        { type = "button", text = "Reload UI", width = 140,
          disabled = function() return #Pending() == 0 end,
          disabledTooltip = "Nothing waiting for a reload",
          onClick = function() ns.ReloadNow() end },
        { type = "label", text = #pending > 0
            and ("|cffffd100Waiting for a reload:|r " .. table.concat(pending, ", ") .. ".")
            or "Turn modules on or off, then press Reload UI once." })
    return y - h
end
ns.Options.ReloadRow = ReloadRow

-- "Microbar on the Minimap" (a global setting both modules read): on the
-- General tab, the Microbar row and the Minimap row.
function ns.Options.MicrobarOnMinimapCell()
    return { type = "toggle", text = "Microbar on the Minimap",
        tooltip = "The Microbar under Ellesmere's minimap, as wide as the map, in place of the Minimap module's bottom panel; the clock, FPS and latency then show as small badges on the map. Needs Microbar on and EllesmereUI Minimap (Square or Rectangular shape). A change in combat shows when combat ends.",
        disabled = function()
            return not (ns.IsModuleEnabled("volume") and ns.Ellesmere.MinimapLook())
        end,
        disabledTooltip = "This option needs Microbar on and EllesmereUI Minimap loaded.",
        getValue = function() return ns.db.global.microbarOnMinimap == true end,
        setValue = function(v)
            ns.db.global.microbarOnMinimap = v and true or false
            ns.Apply()
            ns.Options.Refresh()
        end }
end

local ABOUT = {
    "War UI: my own modules for EllesmereUI on WoW Forever.",
    "Chat, Loot, Quest Tracker, RXP Theme, Rare Scanner, Click Cast,",
    "and Microbar, Minimap and XP Bar (from ProseccoAdditions by proseccopappa).",
    "Every module has its own row in the sidebar on the left.",
}

local function BuildGeneral(_, parent, y)
    local W = ns.Ellesmere.Widgets()
    local _, h
    _, h = W:SectionHeader(parent, "ABOUT", y); y = y - h
    -- Ellesmere's labels never wrap: one clause a row.
    for _, text in ipairs(ABOUT) do
        _, h = W:DualRow(parent, y, { type = "label", text = text }); y = y - h
    end

    _, h = W:SectionHeader(parent, "MODULES", y); y = y - h
    _, h = W:DualRow(parent, y,
        { type = "label", text = "Choose the modules you want; hover a module for what it does." }); y = y - h
    y = ReloadRow(W, parent, y, true)
    local mods = {}
    for _, M in ipairs(ns.ModuleList()) do mods[#mods + 1] = M end
    table.sort(mods, ByTitle)
    for i = 1, #mods, 2 do
        local a, b = mods[i], mods[i + 1]
        _, h = W:DualRow(parent, y, ToggleCell(a), b and ToggleCell(b) or { type = "spacer" }); y = y - h
    end
    _, h = W:DualRow(parent, y,
        { type = "label", text = "Click Cast is always on: it only does something once you add bindings." }); y = y - h

    _, h = W:SectionHeader(parent, "LAYOUT", y); y = y - h
    _, h = W:DualRow(parent, y, ns.Options.MicrobarOnMinimapCell(), { type = "spacer" }); y = y - h
    return math.abs(y)
end

local function BuildGlobal(_, parent, y)
    local W = ns.Ellesmere.Widgets()
    local _, h
    _, h = W:SectionHeader(parent, "GLOBAL BORDER", y); y = y - h
    y = ns.Border.Rows(W, parent, y, function() return ns.db.global.border end, function()
        ns.Apply()
        RefreshPreview()
    end, true)
    _, h = W:DualRow(parent, y,
        { type = "label", text = "Modules with \"Use Global Border\" on follow these values." }); y = y - h

    local function GlobalColor(text, kind, tip)
        return { type = "colorpicker", text = text, hasAlpha = true, tooltip = tip,
            getValue = function()
                local c = ns.db.global[kind]
                local r, g, b = ns.HexToRGB(c.color)
                return r, g, b, tonumber(c.alpha) or 1
            end,
            setValue = function(r, g, b, a)
                local c = ns.db.global[kind]
                c.color, c.alpha = ns.RGBToHex(r, g, b), a or 1
                ns.Apply()
            end }
    end
    _, h = W:SectionHeader(parent, "GLOBAL BACKGROUND", y); y = y - h
    _, h = W:DualRow(parent, y,
        GlobalColor("Global Background", "background", "The background of module boxes: the XP Bar and its panel, the Microbar, the volume popup."),
        GlobalColor("Global Header Background", "headerBackground", "The background of header and title boxes: the Minimap panels, the XP Bar panel's header.")); y = y - h
    local texNames, texOrder = ns.Ellesmere.BarTextures()
    _, h = W:DualRow(parent, y,
        { type = "dropdown", text = "Global Header Texture", values = texNames, order = texOrder,
          tooltip = "An Ellesmere bar texture on every header, title and badge box, tinted by its colour, or a flat colour.",
          getValue = function() return ns.db.global.headerTexture or "none" end,
          setValue = function(v) ns.db.global.headerTexture = v; ns.Apply() end },
        { type = "spacer" }); y = y - h
    _, h = W:DualRow(parent, y,
        { type = "label", text = "Modules with \"Use Global Background\" on follow these colours." }); y = y - h

    if not ns.Ellesmere.IsSearchPrebuild() then
        _, h = W:SectionHeader(parent, "PREVIEW", y); y = y - h
        local box = CreateFrame("Frame", nil, parent)
        -- Anchored from the left on whole pixels: centred, its edges can land
        -- on half pixels and blur.
        ns.Ellesmere.PixelSize(box, 220, 60)
        ns.Ellesmere.PixelPoint(box, "TOPLEFT", parent, "TOPLEFT", 40, y - 16)
        local bg = box:CreateTexture(nil, "BACKGROUND")
        bg:SetAllPoints()
        bg:SetColorTexture(0.12, 0.12, 0.12, 0.9)
        preview = box
        RefreshPreview()
        y = y - 92
    end

    _, h = W:SectionHeader(parent, "RESET", y); y = y - h
    _, h = W:DualRow(parent, y,
        { type = "button", text = "Reset Global Settings", width = 190,
          onClick = function()
              ns.Ellesmere.Confirm({
                  title = "Reset Global Settings",
                  message = "Put the global border, backgrounds and header texture back to their defaults?",
                  confirmText = "Reset",
                  onConfirm = function() ns.ResetGlobal(); RebuildAll() end,
              })
          end },
        { type = "label", text = "Each module row has its own reset at the bottom." }); y = y - h
    return math.abs(y)
end

-- ---------------------------------------------------------------------------
-- Profiles
-- ---------------------------------------------------------------------------

local newName, newFrom, copyFrom = "", "__defaults", nil

local function Report(ok, msg)
    if msg then ns.Print(msg) end
    if ok then RebuildAll() end
end

local function BuildProfiles(_, parent, y)
    local W = ns.Ellesmere.Widgets()
    local _, h
    local active = ns.ActiveProfileName()
    local names = ns.ProfileNames()

    -- Which profile this character uses
    _, h = W:SectionHeader(parent, "ACTIVE PROFILE", y); y = y - h
    local values, order = {}, {}
    for i, n in ipairs(names) do values[n] = n; order[i] = n end
    _, h = W:DualRow(parent, y,
        { type = "dropdown", text = "Profile",
          tooltip = "Every War UI General setting (all modules except Click Cast), including which modules are on, belongs to this profile. Each character remembers its own choice.",
          values = values, order = order,
          getValue = function() return ns.ActiveProfileName() end,
          setValue = function(v)
              local ok, why = ns.SwitchProfile(v)
              Report(ok, ok and ("now using profile \"" .. v .. "\".") or why)
          end },
        { type = "label", text = "This character: " .. ns.CharKey() }); y = y - h

    -- New profile
    _, h = W:SectionHeader(parent, "NEW PROFILE", y); y = y - h
    local srcValues, srcOrder = { __defaults = "Installed defaults" }, { "__defaults" }
    for _, n in ipairs(names) do
        srcValues[n] = "Copy of \"" .. n .. "\""
        srcOrder[#srcOrder + 1] = n
    end
    if srcValues[newFrom] == nil then newFrom = "__defaults" end
    _, h = W:DualRow(parent, y,
        { type = "input", text = "Name", inputWidth = 160, inputStyle = "popup",
          getValue = function() return newName end,
          setValue = function(v) newName = tostring(v or "") end },
        { type = "dropdown", text = "Start from", values = srcValues, order = srcOrder,
          getValue = function() return newFrom end,
          setValue = function(v) newFrom = v end }); y = y - h
    _, h = W:DualRow(parent, y,
        { type = "label", text = "This character switches to the new profile." },
        { type = "button", text = "Create", width = 130,
          onClick = function()
              local ok, why = ns.CreateProfile(newName, newFrom ~= "__defaults" and newFrom or nil)
              if ok then newName = "" end
              Report(ok, ok and ("created profile \"" .. why .. "\" and switched to it.") or why)
          end }); y = y - h

    -- Copy another profile into this one
    _, h = W:SectionHeader(parent, "COPY INTO \"" .. active .. "\"", y); y = y - h
    local others, otherOrder = {}, {}
    for _, n in ipairs(names) do
        if n ~= active then others[n] = n; otherOrder[#otherOrder + 1] = n end
    end
    if copyFrom == nil or others[copyFrom] == nil then copyFrom = otherOrder[1] end
    local noOther = function() return #otherOrder == 0 end
    _, h = W:DualRow(parent, y,
        { type = "dropdown", text = "Copy from", values = others, order = otherOrder,
          disabled = noOther, disabledTooltip = "There is no other profile",
          getValue = function() return copyFrom end,
          setValue = function(v) copyFrom = v end },
        { type = "button", text = "Copy", width = 130,
          disabled = noOther, disabledTooltip = "There is no other profile",
          onClick = function()
              local from = copyFrom
              ns.Ellesmere.Confirm({
                  title = "Copy profile",
                  message = "Replace everything in \"" .. ns.ActiveProfileName() .. "\" with \""
                      .. tostring(from) .. "\"? The profile you copy from is left alone.",
                  confirmText = "Copy",
                  onConfirm = function()
                      local ok, why = ns.CopyProfileInto(from)
                      Report(ok, ok and ("copied \"" .. tostring(from) .. "\" in.") or why)
                  end,
              })
          end }); y = y - h

    -- Delete / reset
    _, h = W:SectionHeader(parent, "DELETE OR RESET \"" .. active .. "\"", y); y = y - h
    _, h = W:DualRow(parent, y,
        { type = "button", text = "Delete", width = 130,
          disabled = function() return #names < 2 end,
          disabledTooltip = "The only profile cannot be deleted",
          onClick = function()
              local name = ns.ActiveProfileName()
              ns.Ellesmere.Confirm({
                  title = "Delete profile",
                  message = "Delete \"" .. name .. "\"? Characters using it move to the first profile left.",
                  confirmText = "Delete",
                  onConfirm = function()
                      local ok, why = ns.DeleteProfile(name)
                      Report(ok, ok and ("deleted \"" .. name .. "\", now using \"" .. why .. "\".") or why)
                  end,
              })
          end },
        { type = "button", text = "Reset to defaults", width = 160,
          onClick = function()
              local name = ns.ActiveProfileName()
              ns.Ellesmere.Confirm({
                  title = "Reset profile",
                  message = "Put every setting in \"" .. name .. "\" back to the installed defaults? "
                      .. "Modules that are on are switched off. Export first if you want a copy.",
                  confirmText = "Reset",
                  onConfirm = function()
                      ns.ResetProfile()
                      Report(true, "\"" .. name .. "\" reset to defaults.")
                  end,
              })
          end }); y = y - h

    -- Text in and out
    _, h = W:SectionHeader(parent, "EXPORT AND IMPORT", y); y = y - h
    _, h = W:DualRow(parent, y,
        { type = "button", text = "Export", width = 130,
          onClick = function()
              ShowText("Export of \"" .. ns.ActiveProfileName() .. "\" - Ctrl+C to copy", ns.ExportProfile())
          end },
        { type = "button", text = "Import", width = 130,
          onClick = function()
              ShowText("Import into \"" .. ns.ActiveProfileName() .. "\" - Ctrl+V, then Import", "",
                  function(text)
                      ns.Ellesmere.Confirm({
                          title = "Import",
                          message = "Replace everything in \"" .. ns.ActiveProfileName()
                              .. "\" with the pasted settings? Other profiles are not touched.",
                          confirmText = "Import",
                          onConfirm = function()
                              local ok, why = ns.ImportProfile(text)
                              if ok then textFrame:Hide() end
                              Report(ok, ok and ("imported into \"" .. ns.ActiveProfileName() .. "\".")
                                  or ("import failed: " .. why))
                          end,
                      })
                  end)
          end }); y = y - h
    return math.abs(y)
end



-- ---------------------------------------------------------------------------
-- Module rows: the on/off toggle, the module's own rows, the rows of any
-- module hosted on it, and a reset button.
-- ---------------------------------------------------------------------------

local extraPages = {}           -- ns.Options.AddPage specs, by page name
local extraOrder = {}

-- A row that is not a module: spec = { page, key?, build(parent, y, W) -> y,
-- onLeave(), onShow() }. Its row key is spec.key or the page name without
-- spaces; it is always there.
function ns.Options.AddPage(spec)
    if extraPages[spec.page] then return end
    spec.key = spec.key or spec.page:gsub("[^%w]", "")
    extraPages[spec.page] = spec
    extraOrder[#extraOrder + 1] = spec.page
end

-- Old call from module files; rows are built in ns.Options.Register.
function ns.Options.AddModule() end

local function ResetButton(W, parent, y, M)
    local _, h = W:DualRow(parent, y,
        { type = "button", text = "Reset " .. M.title, width = 180,
          onClick = function()
              ns.Ellesmere.Confirm({
                  title = "Reset " .. M.title,
                  message = "Put every " .. M.title .. " setting back to its defaults? On/off stays as it is.",
                  confirmText = "Reset",
                  onConfirm = function()
                      ns.ResetModuleSettings(M.key, M.defaults)
                      RebuildAll()
                  end,
              })
          end },
        { type = "spacer" })
    return y - h
end

local hosted = {}               -- host key -> { modules drawn on its row }

local function HostedRows(G, pageName, parent, y, W, own)
    local _, h
    if not own then
        _, h = W:SectionHeader(parent, G.title:upper(), y); y = y - h
    end
    _, h = W:DualRow(parent, y, ToggleCell(G, "Enable " .. G.title),
        { type = "label", text = G.description or "" }); y = y - h
    if G.BuildPage then y = G:BuildPage(pageName, parent, y, W) end
    return y
end

local function BuildModulePage(M, pageName, parent, y, W, guests)
    local _, h
    if pageName == M.pages[1] then
        _, h = W:DualRow(parent, y, ToggleCell(M, "Enable " .. M.title),
            { type = "label", text = M.locked or (M.reload and "Needs a reload: press Reload UI when you are done switching." or "") }); y = y - h
        y = ReloadRow(W, parent, y, false)
    end
    if M.BuildPage then y = M:BuildPage(pageName, parent, y, W) end
    if pageName == M.pages[#M.pages] then
        for _, G in ipairs(guests) do y = HostedRows(G, pageName, parent, y, W) end
        _, h = W:SectionHeader(parent, "RESET", y); y = y - h
        y = ResetButton(W, parent, y, M)
        for _, G in ipairs(guests) do y = ResetButton(W, parent, y, G) end
    end
    return y
end

local function ModuleRow(M, guests)
    return {
        key = M.key, title = M.title, description = M.description,
        pages = M.pages,
        buildPage = function(pageName, parent, y)
            local W = ns.Ellesmere.Widgets()
            return math.abs(BuildModulePage(M, pageName, parent, y, W, guests))
        end,
        onPageCacheRestore = function(pageName)
            if M.PageShown then M:PageShown(pageName) end
        end,
    }
end

-- A hosted module whose host is off: a row of its own with one page.
local function GuestRow(G)
    return {
        key = G.key, title = G.title, description = G.description,
        pages = { G.title },
        buildPage = function(pageName, parent, y)
            local W = ns.Ellesmere.Widgets()
            local _, h
            y = HostedRows(G, pageName, parent, y, W, true)
            _, h = W:SectionHeader(parent, "RESET", y); y = y - h
            y = ResetButton(W, parent, y, G)
            return math.abs(y)
        end,
    }
end

local function ExtraRow(spec)
    return {
        key = spec.key, title = spec.page, description = spec.description,
        pages = { spec.page },
        buildPage = function(_, parent, y)
            local W = ns.Ellesmere.Widgets()
            return math.abs(spec.build(parent, y, W))
        end,
        onPageCacheRestore = spec.onShow and function() spec.onShow() end or nil,
        -- Lists (bindings) can change while the panel is elsewhere: build it
        -- fresh next time.
        onModuleLeave = function()
            if spec.onLeave then pcall(spec.onLeave) end
            local eui = _G.EllesmereUI
            local key = eui and eui.GetPluginModuleKey and eui.GetPluginModuleKey("WarUI", spec.key)
            if key then eui:InvalidateModulePageCache(key) end
        end,
    }
end

-- Called from Register.lua (last file in the toc): every module file has
-- registered. The rows themselves wait for ns.Options.Register (PLAYER_LOGIN),
-- when the profile says which modules are on.
local finished = false
function ns.Options.Finish()
    if finished then return end
    finished = true
    for _, M in ipairs(ns.ModuleList()) do
        if M.hostPage then
            hosted[M.hostPage] = hosted[M.hostPage] or {}
            table.insert(hosted[M.hostPage], M)
        end
    end
end

-- PLAYER_LOGIN (Core.lua), after the first Apply: hands the rows to the War
-- UI hub, which registers them with Ellesmere right after (one frame later).
function ns.Options.Register()
    if registered then return end
    local rows = {}
    rows[1] = {
        key = GENERAL, title = "General", order = 0,
        description = "Modules, the settings every module shares, and profiles.",
        pages = { "General", "Global Settings", "Profiles" },
        buildPage = function(pageName, parent, y)
            if pageName == "Profiles" then return BuildProfiles(pageName, parent, y) end
            if pageName == "Global Settings" then return BuildGlobal(pageName, parent, y) end
            return BuildGeneral(pageName, parent, y)
        end,
    }
    local mods = {}
    for _, M in ipairs(ns.ModuleList()) do
        -- War UI 3.0.1: every module has its row, on or off (its toggle is at
        -- the top), so nothing waits for a reload to show up.
        if not M.hostPage and #M.pages > 0 then mods[#mods + 1] = M end
    end
    for _, M in ipairs(mods) do
        local guests = {}
        for _, G in ipairs(hosted[M.key] or {}) do
            guests[#guests + 1] = G
            inMenu[G.key] = true
        end
        rows[#rows + 1] = ModuleRow(M, guests)
        inMenu[M.key] = true
    end
    for host, list in pairs(hosted) do
        if not inMenu[host] then
            for _, G in ipairs(list) do
                rows[#rows + 1] = GuestRow(G)
                inMenu[G.key] = true
            end
        end
    end
    for _, page in ipairs(extraOrder) do rows[#rows + 1] = ExtraRow(extraPages[page]) end
    for i = 2, #rows do menuKeys[#menuKeys + 1] = rows[i].key end
    for _, row in ipairs(rows) do WarUI.AddModule(row) end
    registered = true
    ns.Log("SESSION", "options: %d row(s) under War UI", #rows)
end

-- Opens the panel on a module's row (moduleKey nil = General). A module
-- without a row this session (off) opens General.
function ns.Options.Open(moduleKey)
    local key, page = GENERAL, nil
    local M = moduleKey and ns.GetModule(moduleKey)
    if M then
        if M.hostPage and inMenu[M.hostPage] then
            local host = ns.GetModule(M.hostPage)
            key, page = host.key, host.pages[#host.pages]
        elseif inMenu[M.key] then
            key = M.key
        end
    elseif moduleKey and extraPages[moduleKey] then
        key = extraPages[moduleKey].key
    end
    if InCombatLockdown() or not (WarUI and WarUI.Open and WarUI.Open(key, page)) then
        ns.Print("the settings could not be opened (in combat?). Try /warui.")
    end
end
