-- ProseccoUI / Media / Manifest.lua
-- Every file in Media/ that ProseccoUI registers with LibSharedMedia, by type.
-- WoW cannot list the files in a folder, so a new file needs a line here, and
-- the game must be restarted (not just /reload) before it can load a file
-- that did not exist when the client started (design §9).
--
--   [type] = { ["Name shown in dropdowns"] = "path under Media\\" }
-- Types are LibSharedMedia's: font, statusbar, border, background, sound.
-- Media/RXP is not listed: RestedXP loads those files by path through the
-- RXP Theme module's texturePath (tools/rxp_textures.py draws them).

local _, ns = ...

-- War UI: the shared namespace, so WarUI_Chat / WarUI_RXPTheme /
-- WarUI_QuestTracker (separate addons) register their modules into this core.
WarUIGeneral = ns

ns.MediaManifest = {
    font = {
        ["Prosecco"]            = "Fonts\\Prosecco-Regular.otf",
        ["Prosecco ExtraLight"] = "Fonts\\Prosecco-ExtraLight.otf",
        ["Prosecco Light"]      = "Fonts\\Prosecco-Light.otf",
        ["Prosecco Medium"]     = "Fonts\\Prosecco-Medium.otf",
        ["Prosecco SemiBold"]   = "Fonts\\Prosecco-SemiBold.otf",
        ["Prosecco Bold"]       = "Fonts\\Prosecco-Bold.otf",
        ["Prosecco Caps"]       = "Fonts\\ProseccoCaps.otf",
    },
}
