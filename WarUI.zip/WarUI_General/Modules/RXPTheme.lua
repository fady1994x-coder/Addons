-- ProseccoUI / Modules / RXPTheme.lua
-- A RestedXP Guides theme, "Prosecco", through RXP's own theme API (design §8,
-- §11 decision 8): colours, font, flat textures of our own (Media/RXP, drawn
-- by tools/rxp_textures.py; RXP's art is CC BY-NC-SA and is not copied). You
-- pick it in RXP's options like any theme; War UI does not change RXP's
-- theme setting.
--
-- What a theme cannot do is done in one pass after RXP draws (post-hooks in
-- Integrations/RXP.lua), and only while Prosecco is the theme in use:
--   - the font face and outline of the step text, header and footer (RXP sets
--     the face only when it creates a string, and always with no outline);
--   - a background per part and our border, under the header, step list,
--     footer, step boxes and their badges, on whole pixels, in place of RXP's
--     background and edge art (our rxp-borders file is empty);
--   - RXP's own logo and class icon in the header (or none), optionally the
--     guide name centred on the header, no version line in the footer and a
--     footer shown only under the mouse.
-- RXP's spacing and margins inside the guide window are never written ("a
-- reskin should not do this", decision 8; ProseccoTools DEVNOTES "RXP Guides:
-- arkitekturregler"). The exceptions are Alexander's (design §11 "Beslut
-- 2026-10-07"): Header Extend moves RXP's scroll frame down, the Active
-- Targets and Active Items titles are re-anchored and get our font, and the
-- header, footer and step badges are raised a few frame levels.
--
-- Off: no frames, no hooks. Once on, the hooks stay until /reload (WoW cannot
-- remove one) and do nothing while the module is off. Turning it off needs a
-- /reload: the theme stays in RXP's list until then.

-- War UI: this module runs on the shared core in WarUI_General.
local ns = WarUIGeneral

local THEME = "Prosecco"
local FLAT = "Interface\\Buttons\\WHITE8X8"

local M = ns.RegisterModule("rxpTheme", {
    title       = "RXP Theme",
    description = "A Prosecco theme for RestedXP Guides: colours, font, flat art and War UI's border.",
    pages       = { "RXP Theme" },
    defaults    = {
        enabled = true,     -- War UI 2.4: on by default
        font = "",                  -- "" = Ellesmere's font
        outline = "ellesmere",      -- ellesmere | none | OUTLINE | THICKOUTLINE
        bgColor = "000000", bgAlpha = 0.8,       -- RXP's other windows (theme background)
        headerColor = "000000", headerAlpha = 1, -- our backgrounds under the guide window's parts
        footerColor = "000000", footerAlpha = 1,
        listColor = "000000", listAlpha = 0.8,
        stepColor = "000000", stepAlpha = 0.8,
        badgeColor = "000000", badgeAlpha = 1,
        badgePadding = 4,                        -- px our badge box reaches past RXP's on each side
        footerRaise = 1,                         -- px our footer box reaches above RXP's top edge
        headerDrop = 2,                          -- px our header box reaches below RXP's bottom edge, list moved too
        headerOverlap = 0,                       -- px more, over the list, which stays put
        sidePadding = 0,                         -- px all guide window boxes reach past RXP's left and right
        hideVersion = false,                     -- the version line in the footer
        footerMouseover = false,                 -- footer shown only under the mouse
        hideLogos = false,                       -- the header's logo and class icon
        centerHeader = false,                    -- guide name centred on the whole header
        rowColor = "1A1A1A", rowAlpha = 0.9,     -- the steps in the list
        accentColor = "4D4D4D",                  -- a list step under the mouse
        pinColor = "D9D9D9",                     -- map pins, route lines, timer bars, tooltip text
        textColor = "FFFFFF",
        border = { useGlobal = true, style = "solid", size = 1, color = "000000", alpha = 1 },
        -- Active Targets and Active Items: their frame, their title badge, their border
        winColor = "000000", winAlpha = 0.4,
        winTitleColor = "000000", winTitleAlpha = 1,
        winBorder = { useGlobal = true, style = "solid", size = 1, color = "000000", alpha = 1 },
        winPadding = 4,                          -- px our window box reaches past RXP's on each side
        winTitlePadding = 2,                     -- the same for the title box
        winCenterTitle = false,                  -- title box centred over the window
        winTitleBar = true,                      -- title box as a bar across the whole window
        arrowTexture = "prosecco",               -- a key in ARROWS below
        arrowColor = "E1E1E1",                   -- the arrow's look before this setting
    },
    affects     = {
        "Adds the theme \"Prosecco\" to RestedXP Guides. Pick it in RXP's options: Look and Feel > Choose Theme.",
        "While that theme is in use, War UI sets the font and outline of the guide text, draws its own backgrounds and border under the guide window and step boxes, and shows RestedXP's own logo in the header. RXP's spacing and margins inside the guide window are not changed; Header Extend moves the step list down and the title settings move the titles of Active Targets and Active Items.",
        "Turning it off needs a /reload; RXP then goes back to its default theme. Picking another theme in RXP also needs a /reload to get RXP's own font back.",
    },
    reload      = true,
})

local function DB() return ns.db.modules.rxpTheme end

local active = false        -- between Enable and Disable; gates the hooks
local lastTheme             -- what the theme was built from at the last Apply (runtime only)
local lastArrow             -- what the arrow was drawn with at the last Apply (runtime only)
local arrowTinted = false   -- our colour is on RXP's arrow now (runtime only)
local warned = false        -- "RXP not loaded" printed this session
local waiter                -- frame that waits for the end of combat (Apply)

-- ---------------------------------------------------------------------------
-- Theme
-- ---------------------------------------------------------------------------

local function FontPath()
    local name = DB().font
    if name and name ~= "" then return ns.Media.Font(name) end
    return (ns.Ellesmere.Font())
end

local function OutlineFlag()
    local o = DB().outline
    if o == "none" then return "" end
    if o == "ellesmere" then return select(2, ns.Ellesmere.Font()) or "" end
    return o
end

local function RGBA(hex, a)
    local r, g, b = ns.HexToRGB(hex)
    return { r, g, b, a }
end

-- What the theme is built from. Apply runs after every ProseccoUI settings
-- change, in any module; RXP only redraws (and reloads its guide) when this
-- has changed.
local function ThemeKey()
    local d = DB()
    return strjoin("|", FontPath(), d.bgColor, tostring(d.bgAlpha), d.rowColor, tostring(d.rowAlpha),
        d.accentColor, d.pinColor, d.textColor)
end

-- A new table every time: RXP fills it in place and restyles its step boxes
-- only when the theme table changes (Integrations/RXP.lua RegisterTheme).
-- Every key RXP Blue has is given, so nothing of RXP's art is filled in.
local function BuildTheme()
    local d = DB()
    local r, g, b = ns.HexToRGB(d.textColor)
    local path = ns.RXP.TEXTURE_PATH
    return {
        name = THEME,
        displayName = "Prosecco",
        author = "War UI",
        applicable = true,
        background = RGBA(d.bgColor, tonumber(d.bgAlpha) or 0.8),
        bottomFrameBG = RGBA(d.rowColor, tonumber(d.rowAlpha) or 0.9),
        bottomFrameHighlight = RGBA(d.accentColor, 1),
        mapPins = RGBA(d.pinColor, 1),
        tooltip = "|cFF" .. ns.RGBToHex(ns.HexToRGB(d.pinColor)),
        textColor = { r, g, b },
        font = FontPath(),
        texturePath = path,
        headerTexture = "rxp-banner",
        -- guideName is the header and footer: RXP Blue gives them no fill and
        -- paints them with its banner art, which ours leaves empty.
        bgTextures = { edge = FLAT, bottom = FLAT, guideName = FLAT },
        edges = { edge = path .. "rxp-borders", guideName = path .. "rxp-borders" },
    }
end

-- ---------------------------------------------------------------------------
-- The pass after RXP draws
-- ---------------------------------------------------------------------------

-- RXP frame -> our frame under it, carrying the part's background and our
-- border. Weak keys: nothing is stored on RXP's frames; ours are their
-- children so they follow RXP's show, hide and fade (RXP hides an empty step
-- box with SetAlpha(0)).
local skins = setmetatable({}, { __mode = "k" })
local footerTouched = false     -- we have hidden part of RXP's footer (runtime only)
local headerTouched = false     -- we have hidden RXP's logos or guide-name line (runtime only)
local nameLine                  -- our guide-name line on the header (CenterName below)

-- Gives RXP's footer back as RXP shows it.
local function RestoreFooter()
    if footerTouched then
        ns.RXP.SetFooter(true, true)
        footerTouched = false
    end
end

-- Gives RXP's header back as RXP shows it.
local function RestoreHeader()
    if headerTouched then
        ns.RXP.SetHeaderIcons(true)
        ns.RXP.SetHeaderTextShown(true)
        headerTouched = false
    end
    if nameLine then nameLine:Hide() end
end

local function HideEdges()
    for _, f in pairs(skins) do f:Hide() end
    ns.RXP.ShiftScrollFrame(0)
    local wins, titles = ns.RXP.Windows()
    for i, w in ipairs(wins) do
        if titles[i] then ns.RXP.PlaceTitle(titles[i], w, false, 0, 0) end
    end
    RestoreFooter()
    RestoreHeader()
end

-- What GetFont returned right after our SetFont, per string. A string that
-- still reads the same was set by us and not reset by RXP, whatever form
-- the client gives the path or the flags in (Ellesmere's outline is e.g.
-- "OUTLINE, SLUG"), and whether or not the font file could be loaded. That
-- makes every write a fixpoint (ProseccoTools DEVNOTES "RXP Guides").
-- The wanted path and flags are kept too, so a settings change is a change.
local gotPath = setmetatable({}, { __mode = "k" })
local gotFlags = setmetatable({}, { __mode = "k" })
local wantKey = setmetatable({}, { __mode = "k" })

local function Fonts()
    -- The colour too: RXP sets it only when it creates a string (Known:
    -- GuideWindow.lua:1036, 1094). It has no effect on sizes, so it is not
    -- part of the fixpoint and is written every pass.
    local tr, tg, tb = ns.HexToRGB(DB().textColor)
    local path, flags = FontPath(), OutlineFlag()
    local want = path .. "|" .. flags
    local texts, inStep = ns.RXP.Texts()
    local relayout = false
    for i, fs in ipairs(texts) do
        fs:SetTextColor(tr, tg, tb)
        local cur, size, curFlags = fs:GetFont()
        -- size is nil for a string RXP has not given a font yet.
        if size and not (wantKey[fs] == want and cur == gotPath[fs] and curFlags == gotFlags[fs]) then
            fs:SetFont(path, size, flags)
            local p, _, f = fs:GetFont()
            gotPath[fs], gotFlags[fs], wantKey[fs] = p, f, want
            if inStep[i] then relayout = true end
        end
    end
    return relayout
end

-- Frame levels. Our frame for a part goes UNDER the part, so RXP's own
-- content on it (text, the header's logo and class icon, the badge's step
-- number) is drawn over our border. Our frame carries the background; Apply's
-- holder is one level up and Ellesmere's line container one more (Known:
-- Core/Border.lua Apply, EllesmereUI_PixelPerfect.lua PP.CreateBorder), so
-- the lines are at our level + 2 and the part has to be at + 3 or more.
-- Counted from the step list's level B (RXP: the list's scroll area is at
-- B+1, its rows at B+2, Known: GuideWindow.lua:31-41, 1987):
--   step list: ours at B-2 (lines at B, under the rows);
--   header and footer, which lie over the list's edges (Known:
--   GuideWindow.lua:1388-1394, 1414): ours at B+4, over the rows, the part
--   lifted to B+7 and the footer's resize grip and cog to B+8;
--   step box at S: ours at S-3; its title badge lifted to S+4, ours at S+1,
--   over the box's line.
-- FIELD RESULT 2026-10-06 (0.4.0-dev3): with our border over the parts, a
-- Pixels border at 16 px covered the badge's number and the header's logo.
local PART = {
    header = { color = "headerColor", alpha = "headerAlpha" },
    footer = { color = "footerColor", alpha = "footerAlpha" },
    list   = { color = "listColor",   alpha = "listAlpha" },
    step   = { color = "stepColor",   alpha = "stepAlpha" },
    badge  = { color = "badgeColor",  alpha = "badgeAlpha" },
    window = { color = "winColor",      alpha = "winAlpha",      border = "winBorder", whole = true, under = true },
    wtitle = { color = "winTitleColor", alpha = "winTitleAlpha", border = "winBorder", whole = true, under = true },
}

-- The strata just below a frame's own, for `under` parts (BACKGROUND has none).
local STRATA_BELOW = {
    LOW = "BACKGROUND", MEDIUM = "LOW", HIGH = "MEDIUM", DIALOG = "HIGH",
    FULLSCREEN = "DIALOG", FULLSCREEN_DIALOG = "FULLSCREEN", TOOLTIP = "FULLSCREEN_DIALOG",
}

local function Skin(box, k, level, grow, raise, side, drop)
    local f = skins[box]
    if not f then
        f = CreateFrame("Frame", nil, box)
        f:EnableMouse(false)
        f.tex = f:CreateTexture(nil, "BACKGROUND")
        f.tex:SetAllPoints(f)
        skins[box] = f
    end
    local d, keys = DB(), PART[k]
    -- `under`: Active Targets and Active Items. Their buttons are one level
    -- above the window and RXP's window sits low, so no level under the
    -- window leaves room for the window's box, the title's box over it and
    -- both borders: the title's border covered the icons (FIELD RESULT
    -- 2026-10-07 (build 70245), dev15 screenshot). One strata down, all of
    -- ours is under all of RXP's window, and `level` orders only ours.
    local below = keys.under and STRATA_BELOW[box:GetFrameStrata()]
    if below then f:SetFrameStrata(below) end
    f:SetFrameLevel(math.max(0, level))
    local r, g, b = ns.HexToRGB(d[keys.color])
    f.tex:SetColorTexture(r, g, b, tonumber(d[keys.alpha]) or 1)
    ns.RXP.ClearBackground(box)
    -- The part RXP paints (its frame less the backdrop insets), grown only
    -- for the badge: a solid line is drawn inside it, a textured one centred
    -- on its edge, as on our other frames. RXP's badge is a few pixels wider
    -- than its number, so a border of a few pixels covers the number; a
    -- bigger box of ours around the same number makes room without moving
    -- anything of RXP's (Alexander 2026-10-07).
    -- `raise` moves only the top edge up that many pixels: the footer's top
    -- line otherwise lies exactly on the step list's bottom line, and
    -- Alexander wants the footer over it (2026-10-07).
    -- `whole`: Active Targets and Active Items use the whole frame. RXP's
    -- insets there are uneven (4, 2, 2, 4; Known: GuideWindow.lua:129), so
    -- a box that follows them puts the centred title text 1 px off centre
    -- (FIELD RESULT 2026-10-07 (build 70245), dev14 screenshot).
    local l, r2, t, b2 = 0, 0, 0, 0
    if not keys.whole then l, r2, t, b2 = ns.RXP.Insets(box) end
    if raise and raise ~= 0 then t = t - raise * ns.Ellesmere.PixelUnit(box) end
    -- `side` moves only the left and right edges out that many pixels: RXP's
    -- list rows and step text reach almost to the edge, so a thick border
    -- crowds them; the boxes grow instead of RXP's layout moving
    -- (Alexander 2026-10-07, decision on the "pixel avstånden" screenshot).
    -- `drop` moves only the bottom edge down that many pixels: two lines of
    -- guide name sit close to the header's bottom line (Alexander
    -- 2026-10-07). The header lies over the list, so it covers the list's top.
    if drop and drop ~= 0 then b2 = b2 - drop * ns.Ellesmere.PixelUnit(box) end
    if side and side ~= 0 then
        local u = ns.Ellesmere.PixelUnit(box)
        l, r2 = l - side * u, r2 - side * u
    end
    if ns.Border.Outside(f, box, grow or 0, l, r2, t, b2) then
        ns.Border.Apply(f, DB()[keys.border or "border"])
        f:Show()
    else
        f:Hide()
    end
end

local function Parts()
    local B = ns.RXP.BaseLevel()
    local side = tonumber(DB().sidePadding) or 0
    local boxes, kind, owner = ns.RXP.Boxes()
    for i, box in ipairs(boxes) do
        local k = kind[i]
        if k == "list" then
            Skin(box, k, B - 2, 0, 0, side)
        elseif k == "header" then
            ns.RXP.SetLevel(box, B + 7)
            -- Header Extend pushes the list down with it; Header Overlap
            -- reaches over the list without moving it (Alexander 2026-10-07).
            Skin(box, k, B + 4, 0, 0, side, (tonumber(DB().headerDrop) or 0) + (tonumber(DB().headerOverlap) or 0))
        elseif k == "footer" then
            ns.RXP.SetLevel(box, B + 7)
            Skin(box, k, B + 4, 0, tonumber(DB().footerRaise) or 0, side)
        elseif k == "step" then
            Skin(box, k, box:GetFrameLevel() - 3, 0, 0, side)
        else    -- badge
            local S = owner[i]:GetFrameLevel()
            ns.RXP.SetLevel(box, S + 4)
            Skin(box, k, S + 1, tonumber(DB().badgePadding) or 0)
        end
    end
    local sf = ns.RXP.ScrollFrame()
    if sf then ns.RXP.ShiftScrollFrame((tonumber(DB().headerDrop) or 0) * ns.Ellesmere.PixelUnit(sf)) end
    local grip, cog = ns.RXP.FooterButtons()
    ns.RXP.SetLevel(grip, B + 8)
    ns.RXP.SetLevel(cog, B + 8)
end

-- The footer: with Footer on Mouseover it shows only while the mouse is
-- over it; Hide Version Text keeps the version line hidden.
local function Footer()
    local d = DB()
    if not (d.hideVersion or d.footerMouseover) then
        RestoreFooter()
        return
    end
    local shown = not d.footerMouseover or ns.RXP.FooterHovered()
    ns.RXP.SetFooter(shown, shown and not d.hideVersion)
    footerTouched = true
end

-- The guide name centred on the whole header. RXP anchors its line from 29
-- px in on the left (room for the logo) to the right edge (Known:
-- GuideWindow.lua:1397-1400), so it is centred right of the middle. Our own
-- line across the whole header (less the backdrop insets) shows RXP's text,
-- font and colour, and RXP's line is hidden with alpha 0; RXP's anchors are
-- not written. Ours is on our own frame, a child of the header one level
-- up. RXP's line is hidden only once ours shows its text, so if RXP changes
-- that line, RXP's own stays visible.
local function CenterName()
    local fs, header = ns.RXP.HeaderText()
    if not (fs and header) then return end
    if not nameLine then
        local host = CreateFrame("Frame", nil, header)
        host:EnableMouse(false)
        host:SetAllPoints(header)
        nameLine = host:CreateFontString(nil, "OVERLAY")
        nameLine:SetJustifyH("CENTER")
        nameLine:SetJustifyV("MIDDLE")
        nameLine.host = host
    end
    nameLine.host:SetFrameLevel(header:GetFrameLevel() + 1)
    -- Centred on our header box, which is what shows: it reaches further
    -- down with Header Extend and Overlap, and its sides follow Side
    -- Padding, so RXP's frame centre is too high (Alexander 2026-10-07).
    nameLine:ClearAllPoints()
    local box = skins[header]
    if box and box:IsShown() then
        nameLine:SetPoint("LEFT", box, "LEFT", 0, 0)
        nameLine:SetPoint("RIGHT", box, "RIGHT", 0, 0)
    else
        local l, r = ns.RXP.Insets(header)
        nameLine:SetPoint("LEFT", header, "LEFT", l, 0)
        nameLine:SetPoint("RIGHT", header, "RIGHT", -r, 0)
    end
    local path, size, flags = fs:GetFont()
    if not path then return end             -- RXP has not given its line a font yet
    nameLine:SetFont(path, size, flags)
    -- Only r, g, b: RXP's line is hidden with alpha 0, and a string's alpha
    -- comes back as the fourth value of GetTextColor, so copying all four
    -- hid ours on the next pass.
    -- FIELD RESULT 2026-10-07 (build 70245): with all four copied, our line
    -- had alpha 0 a second after it showed, with no SetAlpha call on it.
    local cr, cg, cb = fs:GetTextColor()
    nameLine:SetTextColor(cr, cg, cb)
    nameLine:SetText(fs:GetText() or "")
    nameLine:Show()
    ns.RXP.SetHeaderTextShown(false)
end

-- The header: RXP's own logo and class icon, or none; the guide name where
-- RXP puts it, or centred.
local function Header()
    local d = DB()
    ns.RXP.UseRXPIcons()
    if not (d.hideLogos or d.centerHeader) then
        RestoreHeader()
        return
    end
    headerTouched = true
    ns.RXP.SetHeaderIcons(not d.hideLogos)
    if d.centerHeader then
        CenterName()
    else
        if nameLine then nameLine:Hide() end
        ns.RXP.SetHeaderTextShown(true)
    end
end

local function OnHeaderText()
    if active and DB().centerHeader and ns.RXP.ActiveName() == THEME then CenterName() end
end

local function OnFooterHover()
    if active and DB().footerMouseover and ns.RXP.ActiveName() == THEME then Footer() end
end

-- Active Targets and Active Items, the same way as the guide window: our
-- frame under each, one strata below RXP's (see Skin), the title's box
-- above the window's. RXP's windows are UIParent children in MEDIUM
-- (Inferred: no SetFrameStrata in ActiveItemFrame.lua or Targeting.lua).
-- A window whose background RXP's own option hides (no backdrop) gets no
-- background or border of ours either.
-- The padding grows our boxes outward, as on the step badge: RXP puts the
-- buttons 2-6 px from its frame's edge and the frames and buttons are its
-- own (secure buttons, positions set by RXP; decision 8), so room between a
-- button and the border is made by a bigger box of ours, not by moving them.
-- The title's text gets our font face and outline at RXP's size (RXP sets
-- face, size 9 and no outline in UpdateVisuals, Known: ActiveItemFrame.lua:210,
-- Targeting.lua:809); written only when it differs.
local function TitleFont(t)
    local fs = t.text
    if not (fs and fs.GetFont) then return end
    local path, size, flags = fs:GetFont()
    local want, wantFlags = FontPath(), OutlineFlag()
    if want and size and (path ~= want or (flags or "") ~= wantFlags) then
        fs:SetFont(want, size, wantFlags)
    end
end

-- Whole pixels each title box moves from RXP's place (x right, y up), so
-- both windows look alike: one to the left, and the same room between the
-- title and the first button in both. RXP puts the targets' buttons 15 below
-- the top and the title 8 above it, the items' button 16 below and the
-- title 10 above (Known: Targeting.lua:875, 1077; ActiveItemFrame.lua:302,
-- 425 with height 43). Alexander's mock-up 2026-10-07.
local TITLE_NUDGE = {
    RXPTargetFrame = { -1, 2 },
    RXPItemFrame   = { -1, -1 },
}
local NO_NUDGE = { 0, 0 }

-- Title Bar: the title box spans the whole width of the window's box, at
-- its top, with the title centred in it, like the guide window's header over
-- its list. The window's box reaches up to the title's top. A tab of its own
-- never lined up with the window's edges and differed with the title's
-- length (Alexander, dev18 screenshot, 2026-10-07).
local function TitleBar(t, winSkin, titlePad)
    local f = skins[t]
    if not (f and winSkin) then return end
    local u = ns.Ellesmere.PixelUnit(t)
    local h = (math.floor(t:GetHeight() / u + 0.5) + 2 * titlePad) * u
    f:ClearAllPoints()
    f:SetPoint("TOPLEFT", winSkin, "TOPLEFT", 0, 0)
    f:SetPoint("BOTTOMRIGHT", winSkin, "TOPRIGHT", 0, -h)
end

local function Windows()
    local wins, titles = ns.RXP.Windows()
    local d = DB()
    local bar = d.winTitleBar == true
    local pad = tonumber(d.winPadding) or 0
    local titlePad = tonumber(d.winTitlePadding) or 0
    for i, w in ipairs(wins) do
        local t = titles[i]
        local titleY
        if t then
            local nudge = TITLE_NUDGE[w:GetName() or ""] or NO_NUDGE
            local u = ns.Ellesmere.PixelUnit(t)
            local centred = bar or d.winCenterTitle == true
            titleY = ns.RXP.PlaceTitle(t, w, centred, (centred and 0 or nudge[1]) * u, nudge[2] * u)
        end
        local barOn = bar and t and titleY and w.backdropInfo
        if w.backdropInfo then
            -- Not upward: the top edge stays on RXP's, so the title box
            -- straddles it like a tab instead of running 4 px above a
            -- second top line (Alexander's dev14 screenshot). With the
            -- title bar the top goes up to the title's top instead.
            local raise = -pad
            if barOn then
                raise = titleY / ns.Ellesmere.PixelUnit(w) + titlePad - pad
            end
            Skin(w, "window", 1, pad, raise)
        elseif skins[w] then
            skins[w]:Hide()
        end
        if t then
            Skin(t, "wtitle", 4, titlePad)
            if barOn then TitleBar(t, skins[w], titlePad) end
            TitleFont(t)
        end
    end
end

-- The waypoint arrows to pick from: key -> name shown and file in Media/RXP.
-- A new arrow is a white file there (it is tinted with Arrow Color) plus a
-- line here and in ARROW_ORDER; WoW needs a full restart for a new file.
local ARROWS = {
    prosecco = { text = "Prosecco", file = "rxp_navigation_arrow-1" },
    bordered = { text = "Prosecco Bordered", file = "rxp_navigation_arrow-bordered" },
}
local ARROW_ORDER = { "prosecco", "bordered" }

-- Runs right after RXP sets the arrow's texture (Integrations/RXP.lua
-- OnArrowRedraw). With another theme or the module off, only takes our
-- colour off again.
local function Arrow()
    local tex = ns.RXP.ArrowTexture()
    if not tex then return end
    if active and ns.RXP.ActiveName() == THEME then
        local arrow = ARROWS[DB().arrowTexture] or ARROWS.prosecco
        tex:SetTexture(ns.RXP.TEXTURE_PATH .. arrow.file)
        tex:SetVertexColor(ns.HexToRGB(DB().arrowColor))
        arrowTinted = true
    elseif arrowTinted then
        tex:SetVertexColor(1, 1, 1)
        arrowTinted = false
    end
end

local function WindowsPass()
    if active and ns.RXP.ActiveName() == THEME then Windows() end
end

local function Pass()
    if not active then return end
    if ns.RXP.ActiveName() ~= THEME then
        HideEdges()             -- another theme picked in RXP's options
        return
    end
    local relayout = Fonts()
    Parts()
    ns.RXP.OnWindowRedraw(WindowsPass)
    Windows()
    if DB().centerHeader then ns.RXP.OnHeaderText(OnHeaderText) end
    Header()
    if DB().footerMouseover then ns.RXP.OnFooterHover(OnFooterHover) end
    Footer()
    -- RXP sized the step lines for the font before ours; one more layout
    -- with ours (this pass runs again inside it and changes nothing).
    if relayout then ns.RXP.Relayout() end
end

-- ---------------------------------------------------------------------------
-- Module
-- ---------------------------------------------------------------------------

function M:Enable()
    if not ns.RXP.IsLoaded() then
        if not warned then
            warned = true
            ns.Print("RXP Theme is on, but RestedXP Guides is not loaded.")
        end
        return
    end
    active = true
    ns.RXP.OnRedraw(Pass)
    ns.RXP.OnArrowRedraw(Arrow)
end

-- After combat: Apply again, which reads the settings as they are then.
local function OnCombatEnd()
    waiter:UnregisterEvent("PLAYER_REGEN_ENABLED")
    M:Apply()
end

-- RXP's guide window is plain frames (no secure templates in the step
-- display, ProseccoTools DEVNOTES "Beslut: vi bygger inte om RXP-fönstret"),
-- and RXP redraws it in combat itself, so the pass also runs in combat. A
-- new theme does not: RXP's redraw for it scales Active Targets, which has
-- secure buttons (Integrations/RXP.lua RegisterTheme). It waits for the end
-- of combat; a /pui profile switch or an import is how it can happen there.
function M:Apply()
    if not active then return end
    local key = ThemeKey()
    if key ~= lastTheme then
        if InCombatLockdown() then
            if not waiter then
                waiter = CreateFrame("Frame")
                waiter:SetScript("OnEvent", function()
                    xpcall(OnCombatEnd, ns.ErrorHandler("rxpTheme:combat"))
                end)
            end
            waiter:RegisterEvent("PLAYER_REGEN_ENABLED")
        else
            ns.RXP.RegisterTheme(BuildTheme())     -- RXP redraws if Prosecco is picked
            lastTheme = key
        end
    end
    -- Not on every pass: RXP turns the arrow many times a second, and
    -- setting its texture only when RXP does keeps us out of that.
    local arrowKey = strjoin("|", tostring(DB().arrowTexture), tostring(DB().arrowColor), tostring(ns.RXP.ActiveName()))
    if arrowKey ~= lastArrow then
        ns.RXP.RefreshArrow()
        lastArrow = arrowKey
    end
    Pass()
end

function M:Disable()
    active = false
    if waiter then waiter:UnregisterEvent("PLAYER_REGEN_ENABLED") end
    lastArrow = nil
    HideEdges()
    Arrow()
end

-- ---------------------------------------------------------------------------
-- Settings page
-- ---------------------------------------------------------------------------

local OUTLINE_VALUES = { ellesmere = "Ellesmere's outline", none = "None", OUTLINE = "Outline", THICKOUTLINE = "Thick Outline" }
local OUTLINE_ORDER = { "ellesmere", "none", "OUTLINE", "THICKOUTLINE" }

local function Status()
    if not ns.RXP.IsLoaded() then return "RestedXP Guides is not loaded." end
    if not ns.IsModuleEnabled("rxpTheme") then return "RXP Theme is off: turn it on above." end
    if ns.RXP.Selected() ~= THEME then
        return "Now pick \"Prosecco by War UI\" in RestedXP's options: Look and Feel > Choose Theme."
    end
    if ns.RXP.ActiveName() ~= THEME then return "Picked in RestedXP; it shows after /reload." end
    return "RestedXP uses the Prosecco theme."
end

local function Color(text, key, alphaKey, tooltip)
    return { type = "colorpicker", text = text, hasAlpha = alphaKey ~= nil, tooltip = tooltip,
        getValue = function()
            local r, g, b = ns.HexToRGB(DB()[key])
            if alphaKey then return r, g, b, tonumber(DB()[alphaKey]) or 1 end
            return r, g, b
        end,
        setValue = function(r, g, b, a)
            DB()[key] = ns.RGBToHex(r, g, b)
            if alphaKey then DB()[alphaKey] = a or 1 end
            ns.Apply()
        end }
end

function M:BuildPage(_, parent, y, W)
    local _, h
    local function changed() ns.Apply() end
    _, h = W:DualRow(parent, y, { type = "label", text = Status() }); y = y - h

    _, h = W:SectionHeader(parent, "FONT", y); y = y - h
    local fonts, fontOrder = ns.Media.FontList()
    _, h = W:DualRow(parent, y,
        { type = "dropdown", text = "Font", values = fonts, order = fontOrder,
          tooltip = "The guide text. Its size is RestedXP's own (Font Size in RXP's options).",
          getValue = function() return DB().font end,
          setValue = function(v) DB().font = v; changed() end },
        { type = "dropdown", text = "Outline", values = OUTLINE_VALUES, order = OUTLINE_ORDER,
          tooltip = "Step text, step titles, header and footer. The step list keeps RXP's plain text.",
          getValue = function() return DB().outline end,
          setValue = function(v) DB().outline = v; changed() end }); y = y - h

    _, h = W:SectionHeader(parent, "COLOURS", y); y = y - h
    _, h = W:DualRow(parent, y,
        Color("Header", "headerColor", "headerAlpha"),
        Color("Footer", "footerColor", "footerAlpha")); y = y - h
    _, h = W:DualRow(parent, y,
        Color("Step List", "listColor", "listAlpha", "The background behind the list of steps."),
        Color("Step Boxes", "stepColor", "stepAlpha", "The boxes with the current steps.")); y = y - h
    _, h = W:DualRow(parent, y,
        Color("Step Badge", "badgeColor", "badgeAlpha", "The small box with the step number on each step box."),
        Color("Text", "textColor")); y = y - h
    _, h = W:DualRow(parent, y,
        { type = "slider", text = "Step Badge Padding", min = 0, max = 16, step = 1,
          tooltip = "Makes the step badge's box this many pixels larger on each side, so a thick border does not cover the step number.",
          getValue = function() return DB().badgePadding end,
          setValue = function(v) DB().badgePadding = v; changed() end },
        { type = "slider", text = "Footer Raise", min = 0, max = 16, step = 1,
          tooltip = "Moves the top edge of the footer's box this many pixels up, over the step list's bottom edge.",
          getValue = function() return DB().footerRaise end,
          setValue = function(v) DB().footerRaise = v; changed() end }); y = y - h
    _, h = W:DualRow(parent, y,
        { type = "slider", text = "Header Extend", min = 0, max = 16, step = 1,
          tooltip = "Moves the bottom edge of the header's box this many pixels down, and the step list's rows and scroll bar down with it.",
          getValue = function() return DB().headerDrop end,
          setValue = function(v) DB().headerDrop = v; changed() end },
        { type = "slider", text = "Header Overlap", min = 0, max = 16, step = 1,
          tooltip = "Moves the bottom edge of the header's box this many pixels further down, over the step list, without moving the list.",
          getValue = function() return DB().headerOverlap end,
          setValue = function(v) DB().headerOverlap = v; changed() end }); y = y - h
    _, h = W:DualRow(parent, y,
        { type = "slider", text = "Side Padding", min = 0, max = 16, step = 1,
          tooltip = "Makes the boxes of the header, step list, footer and step boxes this many pixels wider on each side, so a thick border does not crowd RestedXP's text. RestedXP's own spacing is not changed.",
          getValue = function() return DB().sidePadding end,
          setValue = function(v) DB().sidePadding = v; changed() end }); y = y - h
    _, h = W:DualRow(parent, y,
        Color("List Steps", "rowColor", "rowAlpha", "Each step in the guide list."),
        Color("List Step Highlight", "accentColor", nil, "A step in the list under the mouse.")); y = y - h
    _, h = W:DualRow(parent, y,
        Color("Map Pins", "pinColor", nil, "Map pin text, route lines on the map, timer bars and the tooltip line."),
        Color("Other RXP Windows", "bgColor", "bgAlpha", "RestedXP's remaining windows, such as the leveling tracker. Active Targets and Active Items have their own section below.")); y = y - h
    _, h = W:DualRow(parent, y,
        { type = "toggle", text = "Hide Version Text",
          tooltip = "Hides RestedXP's version line in the footer of the guide window.",
          getValue = function() return DB().hideVersion == true end,
          setValue = function(v) DB().hideVersion = v and true or false; changed() end },
        { type = "toggle", text = "Footer on Mouseover",
          tooltip = "Shows the guide window's footer, with its cog and resize grip, only while the mouse is over it. Timer bars still show.",
          getValue = function() return DB().footerMouseover == true end,
          setValue = function(v) DB().footerMouseover = v and true or false; changed() end }); y = y - h
    _, h = W:DualRow(parent, y,
        { type = "toggle", text = "Hide Logos",
          tooltip = "Hides RestedXP's logo and class icon in the header of the guide window.",
          getValue = function() return DB().hideLogos == true end,
          setValue = function(v) DB().hideLogos = v and true or false; changed() end },
        { type = "toggle", text = "Center Header Text",
          tooltip = "Centres the guide name on the whole header. RestedXP centres it in the space right of the logo.",
          getValue = function() return DB().centerHeader == true end,
          setValue = function(v) DB().centerHeader = v and true or false; changed() end }); y = y - h

    _, h = W:SectionHeader(parent, "BORDER", y); y = y - h
    y = ns.Border.Rows(W, parent, y, function() return DB().border end, changed)

    _, h = W:SectionHeader(parent, "WAYPOINT ARROW", y); y = y - h
    local arrows = {}
    for k, a in pairs(ARROWS) do arrows[k] = a.text end
    _, h = W:DualRow(parent, y,
        { type = "dropdown", text = "Arrow Texture", values = arrows, order = ARROW_ORDER,
          tooltip = "The arrow RestedXP shows toward the next waypoint.",
          getValue = function() return DB().arrowTexture end,
          setValue = function(v) DB().arrowTexture = v; changed() end },
        Color("Arrow Color", "arrowColor", nil, "The colour of the waypoint arrow.")); y = y - h

    _, h = W:SectionHeader(parent, "ACTIVE TARGETS AND ACTIVE ITEMS", y); y = y - h
    _, h = W:DualRow(parent, y,
        Color("Window", "winColor", "winAlpha", "The frame behind the buttons."),
        Color("Title", "winTitleColor", "winTitleAlpha", "The small title box on top of the window.")); y = y - h
    _, h = W:DualRow(parent, y,
        { type = "slider", text = "Window Padding", min = 0, max = 16, step = 1,
          tooltip = "Makes the window's box this many pixels larger to the left, right and bottom, so the buttons do not sit against the border. The top stays under the title.",
          getValue = function() return DB().winPadding end,
          setValue = function(v) DB().winPadding = v; changed() end },
        { type = "slider", text = "Title Padding", min = 0, max = 16, step = 1,
          tooltip = "Makes the title box this many pixels larger on each side, so a thick border does not cover the title.",
          getValue = function() return DB().winTitlePadding end,
          setValue = function(v) DB().winTitlePadding = v; changed() end }); y = y - h
    _, h = W:DualRow(parent, y,
        { type = "toggle", text = "Title Bar",
          tooltip = "Draws the title as a bar across the whole top of the window, with the title centred in it.",
          getValue = function() return DB().winTitleBar == true end,
          setValue = function(v) DB().winTitleBar = v and true or false; changed(); ns.Ellesmere.RefreshPage() end },
        { type = "toggle", text = "Center Title",
          tooltip = "Centres the title box over the window. RestedXP puts it at the left. Always on with Title Bar.",
          disabled = function() return DB().winTitleBar == true end,
          disabledTooltip = "Title Bar centres the title",
          getValue = function() return DB().winCenterTitle == true end,
          setValue = function(v) DB().winCenterTitle = v and true or false; changed() end }); y = y - h
    y = ns.Border.Rows(W, parent, y, function() return DB().winBorder end, changed)
    _, h = W:DualRow(parent, y,
        { type = "label", text = "Spacing and margins inside the guide window are RestedXP's own and are not changed. Header Extend moves the step list down." }); y = y - h
    return y
end
