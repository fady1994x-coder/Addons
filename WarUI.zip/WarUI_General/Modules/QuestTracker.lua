-- ProseccoUI / Modules / QuestTracker.lua
-- Our own quest tracker (design §8 "Questie: tre nivåer", §12 step 6). This
-- file is the data half and the module's on/off: the quest log read from
-- Blizzard's quest API into a plain list. The frame is drawn in
-- QuestTrackerFrame.lua, which reads the list through M.Quests() and never
-- calls the quest API itself, so a wrong text and a wrong position are looked
-- for in different files (design §5).
--
-- Source of truth is Blizzard's quest API, as Questie's own tracker on
-- Forever (Known: Questie Modules/Tracker/TrackerData.lua, QuestLogCache.lua
-- 2026-10-08 42ee926): C_QuestLog.GetInfo per log index, GetQuestObjectives
-- per quest, IsComplete/IsFailed for the whole quest. An objective's
-- `finished` decides whether it is done, never its counters: Blizzard's own
-- tracker does the same, and Forever has rows that read 1/1 unfinished
-- (Known: Questie docs/quest-completion-semantics.md). The special item is
-- read as Blizzard's own tracker on Forever reads it (Known: wow-ui-source
-- forever 1.60.1 (70245) Blizzard_ObjectiveTrackerShared.lua:147).
--
-- Other trackers (design §11 decision 2, Alexander 2026-10-08): Ellesmere's
-- Quest Tracker module stays on for its QoL (auto-accept, auto-turn-in, the
-- quest item key); we own only its Visibility, set to "never", and Ellesmere
-- then hides Blizzard's tracker itself (alpha 0 and its click sinks off, in
-- combat too; Known: EllesmereUIQuestTracker_Visibility.lua:212-238,
-- EllesmereUI_Visibility.lua:57). A scalar written outside Ellesmere's own
-- setter wins over a stored mode set (Known: EllesmereUI_Visibility.lua
-- :448-477 ActiveModes), so "never" holds whatever mode the user picked
-- there; only a stored per-spec visibilityOverride beats it (:724-733).
-- Questie's tracker is turned off with its trackerEnabled flag. Both are
-- written when the module is switched on (after the popup) or with "Set
-- Values", given back when it goes off, never rewritten at login.
-- Blizzard's tracker is never touched by us: hiding that Edit Mode frame from
-- addon code taints its layout (Inferred from Ellesmere's own rule,
-- EllesmereUIQuestTracker_Visibility.lua:8-14), so without Ellesmere's Quest
-- Tracker the page says it stays visible.
--
-- New quests: Blizzard's tracker frame watches every accepted quest while
-- autoQuestWatch is on, also while Ellesmere keeps it at alpha 0 (Known:
-- Blizzard_ObjectiveTracker.lua:32-37; FIELD RESULT 2026-10-09 (build
-- 70291): a new quest came in watched). It also re-sorts the watch list by
-- distance on zone changes (:22-30), which is the order we show without a
-- guide. So nothing here adds or sorts watches.
--
-- Off: no frames shown, no events.

-- War UI: this module runs on the shared core in WarUI_General.
local ns = WarUIGeneral

local OWNED = {
    { target = "questTracker", key = "visibility",     value = "never", label = "Ellesmere Quest Tracker: Visibility" },
    { target = "questie",      key = "trackerEnabled", value = false,   label = "Questie: Tracker" },
}

local M = ns.RegisterModule("questTracker", {
    title       = "Quest Tracker",
    description = "War UI's own quest tracker, built on Blizzard's quest log, in place of Ellesmere's and Questie's trackers.",
    pages       = { "Quest Tracker" },
    defaults    = {
        enabled = true,     -- War UI 2.4: on by default
        -- Where Blizzard's tracker sits by default: under the minimap.
        point = "TOPRIGHT", x = -40, y = -260,
        width = 260,
        maxHeight = 520,            -- the frame grows with its content up to this, then scrolls
        fixedHeight = false,        -- Always Max Height: the frame is maxHeight tall whatever it holds
        padding = 8,                -- px between the frame's edge and the text
        unlocked = false,
        collapsed = false,          -- the header click folds the frame to its header
        folded = {},                -- questID -> true: the quest shows only its title (right-click)
        altAbandon = true,          -- alt-click a title: abandon the quest
        abandonConfirm = true,      -- ask first (Ellesmere's confirm popup)
        -- Ellesmere's tracker background (bgR/G/B 0.035, bgAlpha 0.75,
        -- EllesmereUIQuestTracker.lua:55-58).
        bgColor = "090909", bgAlpha = 0.75,
        -- headerColor/headerAlpha: the header's own background with Header
        -- Seam; unset (no default) = Background, until set on the page.
        -- Ellesmere's tracker font sizes (EllesmereUIQuestTracker.lua:51-53).
        headerSize = 13, titleSize = 12, objectiveSize = 10,
        headerHeight = 0,           -- px; 0 = the header text's height plus 6
        font = "",                  -- "" = Ellesmere's font; one face for every text in the tracker
        outline = "ellesmere",      -- ellesmere | none | OUTLINE | THICKOUTLINE
        shadow = false,
        headerSeam = false,         -- a border line under the header while the tracker is open
        completed = "top",          -- "top" | "bottom" | "inorder": completed quests within a zone
        currentZoneOnly = false,
        questSpacing = 3,           -- px between quests in the list (his ask 2026-10-09)
        foldedZones = {},           -- zone name -> true: folded to its header by a click (his ask 2026-10-09)
        itemButtons = true,         -- the quest's special item as a clickable button (step 6c, his ask)
        itemSize = 26,              -- px, Blizzard's tracker button size
        rxpDot = true,
        rxpProgress = true,
        rxpHighlight = false,       -- a band across the tracker behind guide quests' titles; works with the dot
        highlightColor = "3F99FF", highlightAlpha = 0.25,               -- the box
        highlightBorderColor = "3F99FF", highlightBorderAlpha = 1,      -- its 1 px edge
        progressBorderColor = "000000", progressBorderAlpha = 1,    -- the progress bar's 1 px edge
        completedText = true,       -- "Quest Completed" in the middle of the screen
        border = { useGlobal = true, style = "solid", size = 1, color = "000000", alpha = 1 },
    },
    affects     = {
        "Ellesmere's Quest Tracker Visibility is set to Never, so Blizzard's tracker is hidden. Its auto-accept, auto-turn-in and quest item key keep working.",
        "Questie's tracker is turned off.",
        "The values from before are put back when Quest Tracker is turned off.",
        "Confirming reloads the UI.",
    },
    reload      = true,
})

local function DB() return ns.db.modules.questTracker end
M.DB = DB

local function WriteOwned() ns.TakeOwned("questTracker", OWNED, "QT") end
local function RestoreOwned() ns.GiveBackOwned("questTracker", "QT") end
M.WriteOwned = WriteOwned
M.OWNED = OWNED

-- ---------------------------------------------------------------------------
-- Data
-- ---------------------------------------------------------------------------

-- quests[i] = {
--   id, title, level, zone (the quest log header above it), logIndex,
--   watched, complete, failed, frequency, item (special item link or nil),
--   loaded (false while Blizzard has not sent every objective's text yet),
--   objectives = { { text, type, finished, have, need }, ... },
-- }
-- Log order: zone by zone, as in the quest log. Replaced on every refresh.
local quests = {}

-- Blizzard's objective rows that are not ready to read, as Questie's
-- QuestLogCache rejects them (Known: Questie QuestieLib.lua:436-460
-- IsObjectiveDataLoaded): no text or no type yet, or a label around a
-- missing name (" : 2/5"). An exactly empty text is a permanent empty row
-- Blizzard adds to some quests; it is skipped, not waited for.
local function Pending(o)
    if o.text == "" then return false end       -- before the type: such rows may have none
    return o.text == nil or o.type == nil or o.text:match("^%s*:") ~= nil
end

local function ReadObjectives(questID, q)
    local rows = C_QuestLog.GetQuestObjectives(questID)
    if not rows then q.loaded = false return end
    for _, o in ipairs(rows) do
        if Pending(o) then
            q.loaded = false
        elseif o.text ~= "" then
            q.objectives[#q.objectives + 1] = {
                text = o.text, type = o.type, finished = o.finished == true,
                have = o.numFulfilled, need = o.numRequired,
            }
        end
    end
end

-- Every quest in the log. Mainline's GetInfo returns quests under collapsed
-- headers too, and nil after the last entry (Known: Questie TrackerData.lua
-- Refresh, "modernLog" branch), so the loop runs until nil.
local function ReadLog()
    local list, zone = {}, nil
    local i = 1
    while true do
        local info = C_QuestLog.GetInfo(i)
        if not info then break end
        if info.isHeader then
            zone = info.title
        elseif not info.isHidden and info.questID and info.questID > 0 then
            local id = info.questID
            local q = {
                id = id, title = info.title, level = info.level, zone = zone, logIndex = i,
                watched = C_QuestLog.GetQuestWatchType(id) ~= nil,
                complete = C_QuestLog.IsComplete(id) == true,
                failed = C_QuestLog.IsFailed(id) == true,
                frequency = info.frequency,
                loaded = true,
                objectives = {},
            }
            -- The special item, as Blizzard's tracker reads it: link for the
            -- button's item attribute, texture for its icon (Known:
            -- Blizzard_ObjectiveTrackerShared.lua:106-117, build 70291).
            q.item, q.itemTexture, q.charges, q.showWhenComplete = GetQuestLogSpecialItemInfo(i)
            ReadObjectives(id, q)
            list[#list + 1] = q
        end
        i = i + 1
    end
    -- Timed quests. Modern timers carry their quest id (Known:
    -- QuestLogDocumentation.lua:540, QuestTimerInfo; the same path Questie's
    -- tracker takes on Forever, TrackerQuestTimers.lua:97-104). Stored as the
    -- GetTime() the timer runs out, so the frame's ticker needs no re-read.
    local timers = C_QuestLog.GetQuestTimers and C_QuestLog.GetQuestTimers()
    if timers then
        local ends = {}
        local now = GetTime()
        for _, t in ipairs(timers) do ends[t.questID] = now + t.questTimer end
        for _, q in ipairs(list) do q.timerEnds = ends[q.id] end
    end
    return list
end

-- The list for the frame (QuestTrackerFrame.lua). Read at call time; the
-- table is replaced on every refresh.
function M.Quests() return quests end

-- Whether anything the frame shows differs between two reads. Field by field,
-- so a burst of QUEST_LOG_UPDATE that changes nothing draws nothing.
local function SameQuest(a, b)
    if a.id ~= b.id or a.title ~= b.title or a.level ~= b.level or a.zone ~= b.zone
       or a.watched ~= b.watched or a.complete ~= b.complete or a.failed ~= b.failed
       -- The item and its charges change the button; the timer's seconds tick
       -- every read, so only its coming or going counts (the ticker draws it).
       or a.item ~= b.item or a.charges ~= b.charges
       -- logIndex feeds the item buttons' cooldown and tooltip, so a log
       -- renumbering alone must also redraw.
       or a.logIndex ~= b.logIndex
       or (a.timerEnds == nil) ~= (b.timerEnds == nil)
       or #a.objectives ~= #b.objectives then
        return false
    end
    for i, o in ipairs(a.objectives) do
        local p = b.objectives[i]
        if o.text ~= p.text or o.finished ~= p.finished then return false end
    end
    return true
end

local function SameList(a, b)
    if #a ~= #b then return false end
    for i, q in ipairs(a) do
        if not SameQuest(q, b[i]) then return false end
    end
    return true
end

-- ---------------------------------------------------------------------------
-- Updates
-- ---------------------------------------------------------------------------

-- QUEST_LOG_UPDATE comes in bursts (several per objective tick, and many at
-- login), so a burst is read once, on the next frame.
local host
local active = false
local queued = false
local first = true          -- the first read after switching on or a /reload
local forceDraw = false     -- something besides the quest list changed (zone, guide)

local function Refresh()
    queued = false
    if not active then return end
    local old = quests
    quests = ReadLog()
    -- Folded ids whose quest left the log would otherwise pile up in
    -- SavedVariables forever.
    local folded = ns.db.modules.questTracker.folded
    if next(folded) then
        local inLog = {}
        for _, q in ipairs(quests) do inLog[q.id] = true end
        for id in pairs(folded) do
            if not inLog[id] then folded[id] = nil end
        end
    end
    -- Same for folded zones: a zone with no quests left in the log has
    -- nothing to fold, and names must not pile up in SavedVariables.
    local foldedZones = ns.db.modules.questTracker.foldedZones
    if next(foldedZones) then
        local zones = {}
        for _, q in ipairs(quests) do zones[q.zone or ""] = true end
        for z in pairs(foldedZones) do
            if not zones[z] then foldedZones[z] = nil end
        end
    end
    -- "Quest Completed" only for a quest that was in the last read and not
    -- complete then: not at login, a reload, or for a quest accepted complete.
    if not first then
        local was = {}
        for _, q in ipairs(old) do was[q.id] = q.complete end
        for _, q in ipairs(quests) do
            if q.complete and was[q.id] == false then M.ShowCompleted(q.title) end
        end
    end
    if first or forceDraw or not SameList(old, quests) then
        M.Draw()
    end
    first, forceDraw = false, false
end

local function Queue(redraw)
    if redraw then forceDraw = true end
    if queued then return end
    queued = true
    C_Timer.After(0, function()
        xpcall(Refresh, ns.ErrorHandler("questTracker:refresh"))
    end)
end
M.Queue = Queue

-- QUEST_LOG_UPDATE: objectives, completion, accept and abandon all end in it.
-- QUEST_WATCH_LIST_CHANGED: tracked/untracked and Blizzard's re-sort by
-- distance, which do not change the log. ZONE_CHANGED_NEW_AREA: the zone
-- that "Current Zone Only" keeps open. PLAYER_REGEN_DISABLED/ENABLED: the
-- item buttons are secure, so their layout waits out combat (the frame
-- freezes them at the pull and lays them out again after it).
-- BAG_UPDATE_COOLDOWN: only the buttons' cooldown swipes, no redraw.
local EVENTS = { "QUEST_LOG_UPDATE", "QUEST_WATCH_LIST_CHANGED", "ZONE_CHANGED_NEW_AREA",
                 "PLAYER_REGEN_DISABLED", "PLAYER_REGEN_ENABLED", "BAG_UPDATE_COOLDOWN" }

local function OnEvent(_, event)
    if event == "PLAYER_REGEN_DISABLED" then
        M.EnterCombat()
        return
    end
    if event == "BAG_UPDATE_COOLDOWN" then
        M.UpdateItemCooldowns()
        return
    end
    Queue(event ~= "QUEST_LOG_UPDATE")
end

function M:Enable()
    active = true
    if not host then
        host = CreateFrame("Frame")
        host:SetScript("OnEvent", OnEvent)
    end
    for _, e in ipairs(EVENTS) do host:RegisterEvent(e) end
    -- A guide loaded or a step done moves quests in the order and changes the
    -- progress bar; no quest log event comes with it.
    ns.RXP.OnGuideChange(function()
        if active then Queue(true) end
    end)
    first = true
    Queue(true)
end

-- A settings change: draw again from the list we have.
function M:Apply()
    M.Draw()
end

function M:Disable()
    active = false
    if host then host:UnregisterAllEvents() end
    quests = {}
    M.HideFrame()
    RestoreOwned()
end

function M:SwitchedOn() WriteOwned() end

-- At login (War UI 2.4): Ellesmere's tracker hidden and Questie's off, always.
function M.Ensure() return ns.EnsureOwned("questTracker", OWNED, "QT") end
