-------------------------------------------------------------------------------
--  WarUI_General / Modules / RareScannerOptions.lua
--  The Rare Scanner tab under War UI > General (Ellesmere DualRow layout).
-------------------------------------------------------------------------------
local G  = WarUIGeneral
local ns = G.RareScanner
local M  = ns.M

local function DB() return G.db.modules.rareScanner end
local function Apply() G.Apply() end
local function Off() return not G.IsModuleEnabled("rareScanner") end
local OFF_TIP = "Turn Rare Scanner on first"

local function Toggle(text, key, tip)
    return { type = "toggle", text = text, tooltip = tip,
        disabled = Off, disabledTooltip = OFF_TIP,
        getValue = function() return DB()[key] == true end,
        setValue = function(v) DB()[key] = v and true or false; Apply() end }
end

local function Slider(text, key, minV, maxV, step, tip)
    return { type = "slider", text = text, min = minV, max = maxV, step = step, tooltip = tip,
        disabled = Off, disabledTooltip = OFF_TIP,
        getValue = function() return tonumber(DB()[key]) or minV end,
        setValue = function(v) DB()[key] = v; Apply() end }
end

local function Dropdown(text, key, list, order, tip)
    local values = { _noLoc = true }
    for k, v in pairs(list) do values[k] = v[1] end
    return { type = "dropdown", text = text, values = values, order = order, tooltip = tip,
        disabled = Off, disabledTooltip = OFF_TIP,
        getValue = function() return DB()[key] end,
        setValue = function(v) DB()[key] = v; Apply() end }
end

local function Button(text, width, onClick, tip)
    return { type = "button", text = text, width = width, tooltip = tip,
        disabled = Off, disabledTooltip = OFF_TIP, onClick = onClick }
end

function M:BuildPage(_, parent, y, W)
    local _, h

    -- TEST first: that is what you come here for while setting it up.
    _, h = W:SectionHeader(parent, "TEST", y); y = y - h
    _, h = W:DualRow(parent, y,
        Button("Test Alert", 170, function() ns.Test() end,
            "Places a fake rare 80 yards ahead-left of you. Walk and turn: the arrow keeps pointing at it."),
        Button("Nearest Known Rare", 170, function() ns.TestNearest() end,
            "Points the arrow at the nearest rare spawn on this map from the database (the rare itself may not be up).")); y = y - h
    _, h = W:DualRow(parent, y,
        Button("Clear Alerts", 170, function() ns.Clear() end),
        Button("Move (Unlock Mode)", 170, function() ns.OpenUnlockMode() end,
            "Opens EllesmereUI Unlock Mode. The alert is listed as \"Rare Scanner\".")); y = y - h

    local mapID = ns.PlayerPos and ns.PlayerPos()
    local count, seen = 0, {}
    for _, r in ipairs(ns.RaresOnMap(mapID)) do
        if not seen[r.id] then seen[r.id] = true; count = count + 1 end
    end
    local zone = (GetZoneText and GetZoneText()) or "this zone"
    _, h = W:DualRow(parent, y,
        { type = "label", text = string.format("Database: %d known rare(s) in %s. /rare list prints them.", count, zone) }); y = y - h

    _, h = W:SectionHeader(parent, "DETECTION", y); y = y - h
    _, h = W:DualRow(parent, y,
        Toggle("Scan Nameplates", "scanNameplates",
            "Checks every enemy nameplate. Enemy nameplates must be shown (default key: V)."),
        Toggle("Target & Mouseover", "scanTarget", "Checks your target and the unit under the mouse.")); y = y - h
    _, h = W:DualRow(parent, y,
        Toggle("Map Icons (Vignettes)", "scanVignettes",
            "Uses the skull icons on the minimap when the client shows them. Gives the exact position."),
        Toggle("Include Rare Elites", "rareElites", "Also alert for rare elites (gold dragon).")); y = y - h
    _, h = W:DualRow(parent, y,
        Toggle("Ignore Dead Rares", "ignoreDead", "No alert for a rare that is already dead."),
        Toggle("Hide When Killed", "hideKilled", "The alert goes away a few seconds after the rare dies.")); y = y - h

    _, h = W:SectionHeader(parent, "ALERT", y); y = y - h
    _, h = W:DualRow(parent, y,
        Toggle("Play Sound", "sound"),
        Dropdown("Sound", "soundKit", ns.SOUNDS, ns.SOUND_ORDER)); y = y - h
    _, h = W:DualRow(parent, y,
        Toggle("Flash Taskbar", "flash", "Flashes the WoW icon on the taskbar when the game is in the background."),
        Toggle("Chat Message", "chat", "Prints the rare, its level and coordinates in chat.")); y = y - h
    _, h = W:DualRow(parent, y,
        Toggle("Center Screen Text", "centerText", "Shows the rare's name in the middle of the screen (raid warning style)."),
        Slider("Scale (%)", "scale", 50, 200, 5)); y = y - h
    _, h = W:DualRow(parent, y,
        Slider("Repeat Cooldown (min)", "cooldown", 0, 60, 1,
            "The same rare does not alert again for this long (also after you close it with X)."),
        Slider("Forget After (sec)", "timeout", 30, 900, 30,
            "The alert goes away this long after the rare was last seen.")); y = y - h

    _, h = W:SectionHeader(parent, "ARROW", y); y = y - h
    _, h = W:DualRow(parent, y,
        Toggle("Show Arrow", "showArrow"),
        Slider("Arrow Size", "arrowSize", 32, 160, 4)); y = y - h
    _, h = W:DualRow(parent, y,
        Dropdown("Arrow Color", "arrowColor", ns.COLORS, ns.COLOR_ORDER,
            "Direction: green when you face the rare, yellow to the side, red behind you."),
        Toggle("Show Distance", "showDistance", "Yards to the rare (or \"near\" while its nameplate is on screen).")); y = y - h
    _, h = W:DualRow(parent, y,
        Slider("Arrived Distance (yd)", "arriveDist", 3, 40, 1,
            "Closer than this the arrow turns into a pulsing green \"here\"."),
        { type = "spacer" }); y = y - h
    _, h = W:DualRow(parent, y,
        { type = "label", text = "Where the arrow points, best first: the map icon, the rare's nameplate on screen (up = straight ahead), its nearest known spawn, then where you last saw it. Click the rare's name on the alert to target it." }); y = y - h

    _, h = W:SectionHeader(parent, "WORLD MAP", y); y = y - h
    _, h = W:DualRow(parent, y,
        Toggle("Skulls on the Map", "mapPins",
            "Shows a skull on the world map at every known spawn point. Hover for level, last seen and respawn time; click to point the arrow there."),
        Slider("Skull Size", "pinSize", 10, 32, 1)); y = y - h
    _, h = W:DualRow(parent, y,
        Toggle("Show Rare Elites", "mapElites", "Gold skulls. Silver = rare, red = up right now."),
        Toggle("Hide Ignored Rares", "mapHideIgnored")); y = y - h
    _, h = W:DualRow(parent, y,
        { type = "label", text = "Respawn timers are not in the database: Rare Scanner learns them when you see a rare dead and later alive again (saved for all characters)." }); y = y - h

    _, h = W:SectionHeader(parent, "WAYPOINT", y); y = y - h
    _, h = W:DualRow(parent, y,
        Toggle("TomTom Waypoint", "tomtom", "Adds a TomTom waypoint (if TomTom is installed)."),
        Toggle("Map Pin", "mapPin", "Places Blizzard's map pin on the rare and tracks it.")); y = y - h

    _, h = W:SectionHeader(parent, "IGNORED RARES", y); y = y - h
    local names = {}
    for k in pairs(DB().ignored or {}) do
        local rec = type(k) == "number" and ns.RARES and ns.RARES[k]
        names[#names + 1] = rec and rec[1] or tostring(k)
    end
    table.sort(names)
    _, h = W:DualRow(parent, y,
        { type = "label", text = #names > 0 and table.concat(names, ", ")
            or "None. Click \"Ignore\" on an alert, or type /rare ignore <name>." }); y = y - h
    _, h = W:DualRow(parent, y,
        Button("Clear Ignore List", 170, function()
            wipe(DB().ignored)
            G.Options.Refresh()
        end),
        { type = "label", text = "Slash: /rare test | nearest | clear | list | move | ignore | unignore | debug" }); y = y - h
    return y
end
