-------------------------------------------------------------------------------
--  WarUI_General / Modules / RareScanner.lua
--  Rare Scanner: spots rare and rare elite mobs and shows an alert with an
--  arrow that points at the rare.
--
--  How a rare is found (each source can be switched off):
--    * enemy nameplates (NAME_PLATE_UNIT_ADDED + a 0.5 s sweep);
--    * your target and mouseover;
--    * map vignettes (the skull icons on the minimap), if the client has them.
--  A unit counts as rare when UnitClassification says "rare"/"rareelite", or
--  when its NPC ID is a rare in the QuestieDB_Forever data
--  (RareScannerData.lua, ns.RareScanner.RARES).
--
--  Where the arrow points, best first:
--    1. the vignette position (exact, live);
--    2. the rare's nameplate on screen (straight up = straight ahead);
--    3. the nearest known spawn point of that rare (database) close to
--       where you saw it;
--    4. the spot where you were when you last saw it.
--
--  12.x engine notes: the combat log is closed to addons, unit values can be
--  "secret" - every unit value is checked with issecretvalue before it is
--  compared, and every newer API is called through pcall.
--  Settings: War UI > General > Rare Scanner. Slash: /rare (/rarescanner).
-------------------------------------------------------------------------------
local G  = WarUIGeneral
G.RareScanner = G.RareScanner or {}
local ns = G.RareScanner
local RARES = ns.RARES or {}

local MEDIA       = "Interface\\AddOns\\WarUI_General\\Media\\RareScanner\\"
local ARROW_TEX   = MEDIA .. "arrow.png"
local GLOW_TEX    = MEDIA .. "glow.png"
local SKULL_TEX   = "Interface\\TargetingFrame\\UI-TargetingFrame-Skull"
local UNLOCK_KEY  = "WarUI_RareScanner"
local CARD_W, CARD_H = 250, 50
local PREFIX      = "|cffffd100Rare Scanner|r: "

local issecretvalue = issecretvalue or function() return false end
local function Secret(v) return v ~= nil and issecretvalue(v) end
local atan2 = math.atan2 or function(y, x) return math.atan(y, x) end
local sqrt, abs, pi, floor = math.sqrt, math.abs, math.pi, math.floor

-------------------------------------------------------------------------------
--  Settings
-------------------------------------------------------------------------------
local DEFAULTS = {
    enabled        = true,     -- on by default (new module, easy to test)
    -- detection
    scanNameplates = true,
    scanTarget     = true,
    scanVignettes  = true,
    rareElites     = true,
    ignoreDead     = true,
    -- alert
    sound          = true,
    soundKit       = "raidwarning",
    flash          = true,
    chat           = true,
    centerText     = true,
    cooldown       = 5,        -- minutes before the same rare alerts again
    timeout        = 180,      -- seconds after the last sighting before the alert goes
    hideKilled     = true,
    -- arrow
    showArrow      = true,
    arrowSize      = 72,
    arrowColor     = "direction",
    showDistance   = true,
    arriveDist     = 12,       -- yards: "you are there"
    scale          = 100,      -- percent
    -- waypoint
    tomtom         = false,
    mapPin         = false,
    -- world map
    mapPins        = true,     -- skulls on the world map where rares spawn
    mapElites      = true,
    pinSize        = 16,
    mapHideIgnored = true,
    -- other
    ignored        = {},       -- [npcID or name] = true
    pos            = nil,      -- { point, relPoint, x, y } from Unlock Mode
}
ns.DEFAULTS = DEFAULTS

local SOUNDS = {
    raidwarning = { "Raid Warning", 8959 },
    readycheck  = { "Ready Check", 8960 },
    alarm       = { "Alarm Clock", 12867 },
    pvpflag     = { "PvP Flag Taken", 8174 },
    none        = { "None", nil },
}
ns.SOUND_ORDER = { "raidwarning", "readycheck", "alarm", "pvpflag", "none" }
ns.SOUNDS = SOUNDS

local COLORS = {
    direction = { "Direction (green = ahead)" },
    gold      = { "Gold",   1.00, 0.82, 0.10 },
    red       = { "Red",    1.00, 0.25, 0.20 },
    green     = { "Green",  0.20, 1.00, 0.35 },
    blue      = { "Blue",   0.25, 0.65, 1.00 },
    white     = { "White",  1.00, 1.00, 1.00 },
    accent    = { "EUI Accent" },
}
ns.COLOR_ORDER = { "direction", "gold", "red", "green", "blue", "white", "accent" }
ns.COLORS = COLORS

local db
local function Bind()
    db = G.db and G.db.modules and G.db.modules.rareScanner or nil
    if db and type(db.ignored) ~= "table" then db.ignored = {} end
    return db ~= nil
end
function ns.DB() Bind(); return db end

local function Say(msg) print(PREFIX .. tostring(msg)) end

-------------------------------------------------------------------------------
--  Sighting history (account-wide, outside the profiles):
--  WarUIGeneralDB.rareHistory[npcID] = { seen, killed, respawn, count }
--  seen/killed = time() of the last sighting / last time seen dead.
--  respawn = shortest observed time from "first seen dead" to "seen alive
--  again" (an estimate: it depends on when you happened to look). The QuestieDB data has no respawn
--  timers, so this is learned while you play.
-------------------------------------------------------------------------------
function ns.History(npcID, create)
    if not npcID or type(WarUIGeneralDB) ~= "table" then return nil end
    local all = WarUIGeneralDB.rareHistory
    if type(all) ~= "table" then
        if not create then return nil end
        all = {}
        WarUIGeneralDB.rareHistory = all
    end
    local h = all[npcID]
    if not h and create then h = {}; all[npcID] = h end
    return h
end

local recorded = {}     -- [npcID] = { at, dead } (throttle: the sweep runs twice a second)
local function RecordSighting(npcID, dead)
    if not npcID then return end
    local r = recorded[npcID]
    local t = GetTime()
    dead = dead and true or false
    if r and t - r.at < 10 and r.dead == dead then return end
    recorded[npcID] = { at = t, dead = dead }
    local h = ns.History(npcID, true)
    if not h then return end
    local now = time()
    if dead then
        -- A new death: the first time it is seen dead (a corpse seen again
        -- later must not move the time).
        if not h.killed or h.counted or now - h.killed > 3600 then
            h.count = (h.count or 0) + 1
            h.killed = now
            h.counted = nil
        end
    else
        if h.killed and not h.counted and (now - h.killed) > 60 then
            local d = now - h.killed
            if not h.respawn or d < h.respawn then h.respawn = d end
            h.counted = true
        end
    end
    h.seen = now
end

-------------------------------------------------------------------------------
--  Database helpers
-------------------------------------------------------------------------------
local nameIndex
local function ByName(name)
    if not name or Secret(name) then return nil end
    if not nameIndex then
        nameIndex = {}
        for id, r in pairs(RARES) do
            if not nameIndex[r[1]] then nameIndex[r[1]] = id end
        end
    end
    return nameIndex[name]
end

-- Rares of the database that spawn on this map: { {id, rec, x, y}, ... }
function ns.RaresOnMap(mapID)
    local out = {}
    if not mapID then return out end
    for id, r in pairs(RARES) do
        local pts = r[6] and r[6][mapID]
        if pts then
            for i = 1, #pts - 1, 2 do
                out[#out + 1] = { id = id, rec = r, x = pts[i], y = pts[i + 1] }
            end
        end
    end
    return out
end

local function NpcIDFromGUID(guid)
    if not guid or Secret(guid) then return nil end
    local kind, _, _, _, _, id = strsplit("-", guid)
    if kind == "Creature" or kind == "Vehicle" then return tonumber(id) end
    return nil
end

-------------------------------------------------------------------------------
--  Map geometry
-------------------------------------------------------------------------------
local mapSize = {}      -- [mapID] = { w, h } in yards, or false

local function MapYards(mapID)
    if mapSize[mapID] ~= nil then return mapSize[mapID] end
    local size = false
    if C_Map and C_Map.GetWorldPosFromMapPos and CreateVector2D then
        local ok, _, a = pcall(C_Map.GetWorldPosFromMapPos, mapID, CreateVector2D(0, 0))
        local ok2, _, b = pcall(C_Map.GetWorldPosFromMapPos, mapID, CreateVector2D(1, 1))
        if ok and ok2 and a and b then
            -- World X runs north, world Y runs west: map x (east) is world Y.
            local w, h = abs(a.y - b.y), abs(a.x - b.x)
            if w > 0 and h > 0 then size = { w, h } end
        end
    end
    mapSize[mapID] = size
    return size
end

-- The player's map and position (0-100), or nil (instance, loading screen).
local function PlayerPos()
    if not (C_Map and C_Map.GetBestMapForUnit) then return nil end
    local ok, mapID = pcall(C_Map.GetBestMapForUnit, "player")
    if not ok or not mapID then return nil end
    local ok2, pos = pcall(C_Map.GetPlayerMapPosition, mapID, "player")
    if not ok2 or not pos then return nil end
    local x, y = pos:GetXY()
    if not x or (x == 0 and y == 0) then return nil end
    return mapID, x * 100, y * 100
end
ns.PlayerPos = PlayerPos

-- Yards east and south from the player to (x, y) on mapID, or nil.
local function Offset(mapID, px, py, tx, ty)
    local s = MapYards(mapID)
    if not s then return nil end
    return (tx - px) / 100 * s[1], (ty - py) / 100 * s[2]
end

-- A point `yards` away from the player at `angle` (radians ccw from where
-- the player looks). Used by the test alert.
local function PointFromPlayer(yards, angle)
    local mapID, px, py = PlayerPos()
    if not mapID then return nil end
    local s = MapYards(mapID)
    local facing = GetPlayerFacing and GetPlayerFacing() or 0
    if not s or not facing or Secret(facing) then return nil end
    local a = facing + angle
    -- angle a ccw from north: north = -south, west = -east
    local east, south = -math.sin(a) * yards, -math.cos(a) * yards
    return mapID, px + east / s[1] * 100, py + south / s[2] * 100
end

-------------------------------------------------------------------------------
--  Active rares
-------------------------------------------------------------------------------
-- entry = { key, npcID, name, level, elite, source, firstSeen, lastSeen,
--           unit (token last seen on), vignette (guid), map, x, y (target),
--           seenMap, seenX, seenY, dead, test, spin }
local active = {}           -- list, newest first
local byKey = {}
local lastAlert = {}        -- [key] = GetTime() of the last sound/flash
local dismissed = {}        -- [key] = GetTime() when closed with X (quiet for the cooldown)
local current               -- entry on the card

local Refresh               -- forward

local function EntryKey(npcID, name) return npcID and ("id" .. npcID) or ("n" .. tostring(name)) end

local function IsIgnored(npcID, name)
    if not db then return false end
    return (npcID and db.ignored[npcID]) or (name and db.ignored[name]) or false
end

-- Nearest database spawn of this rare within `maxYards` of the player.
local function NearestSpawn(npcID, mapID, px, py, maxYards)
    local r = npcID and RARES[npcID]
    local pts = r and r[6] and mapID and r[6][mapID]
    if not pts then return nil end
    local best, bx, by
    for i = 1, #pts - 1, 2 do
        local e, s = Offset(mapID, px, py, pts[i], pts[i + 1])
        if e then
            local d = sqrt(e * e + s * s)
            if d <= maxYards and (not best or d < best) then best, bx, by = d, pts[i], pts[i + 1] end
        end
    end
    return bx, by
end

local function SetWaypoint(e)
    if not (e.map and e.x) then return end
    if db.tomtom and TomTom and TomTom.AddWaypoint then
        pcall(TomTom.AddWaypoint, TomTom, e.map, e.x / 100, e.y / 100,
            { title = e.name, persistent = false, minimap = true, world = true })
    end
    if db.mapPin and C_Map and C_Map.SetUserWaypoint and UiMapPoint then
        pcall(function()
            C_Map.SetUserWaypoint(UiMapPoint.CreateFromCoordinates(e.map, e.x / 100, e.y / 100))
            if C_SuperTrack and C_SuperTrack.SetSuperTrackedUserWaypoint then
                C_SuperTrack.SetSuperTrackedUserWaypoint(true)
            end
        end)
    end
end

local function Announce(e)
    if e.quiet then return end          -- map pin click: just the arrow
    local now = GetTime()
    local last = lastAlert[e.key]
    if last and now - last < (db.cooldown or 5) * 60 and not e.test then return end
    lastAlert[e.key] = now
    local kind = e.elite and "Rare Elite" or "Rare"
    if db.sound then
        local s = SOUNDS[db.soundKit] or SOUNDS.raidwarning
        if s[2] then pcall(PlaySound, s[2], "Master") end
    end
    if db.flash and FlashClientIcon then pcall(FlashClientIcon) end
    if db.centerText and RaidNotice_AddMessage and RaidWarningFrame then
        pcall(RaidNotice_AddMessage, RaidWarningFrame,
            "|cffffd100" .. kind .. ":|r " .. e.name, { r = 1, g = 0.82, b = 0.1 })
    end
    if db.chat then
        local where = ""
        if e.x then where = string.format(" at %.1f, %.1f", e.x, e.y) end
        Say(string.format("|cffff8040%s|r%s%s (%s, %s)%s", e.name,
            e.level and e.level > 0 and (" [" .. e.level .. "]") or "",
            e.test and " |cff888888(test)|r" or "", kind, e.source or "?", where))
    end
    SetWaypoint(e)
    G.Log("RARE", "found %s (%s) via %s", tostring(e.name), tostring(e.npcID), tostring(e.source))
end

-- Adds or refreshes an entry. info = { npcID, name, level, elite, source,
-- unit, vignette, map, x, y, dead, test, spin }
local function Found(info)
    if not db then return end
    local key = info.key or EntryKey(info.npcID, info.name)
    if not info.test and IsIgnored(info.npcID, info.name) then return end
    local now = GetTime()
    if not info.test and dismissed[key] then
        if now - dismissed[key] < (db.cooldown or 5) * 60 then return end
        dismissed[key] = nil
    end
    local e = byKey[key]
    local isNew = not e
    if isNew then
        e = { key = key, firstSeen = now }
        byKey[key] = e
        table.insert(active, 1, e)
    end
    e.quiet = nil
    for k, v in pairs(info) do e[k] = v end
    e.lastSeen = now
    if info.dead then e.deadAt = e.deadAt or now else e.deadAt = nil end
    if info.vignette and info.x then e.exactAt = now end
    -- Where to point when the vignette and the nameplate are gone: the
    -- nearest known spawn, else where you were when you last saw it. A
    -- vignette position (exact) seen in the last 3 seconds is kept.
    local exact = e.exactAt and now - e.exactAt < 3
    if not info.map and not info.vignette and not info.test and not exact then
        local mapID, px, py = PlayerPos()
        if mapID then
            e.seenMap, e.seenX, e.seenY = mapID, px, py
            local sx, sy = NearestSpawn(e.npcID, mapID, px, py, 150)
            if sx then e.map, e.x, e.y = mapID, sx, sy
            else e.map, e.x, e.y = mapID, px, py end
        end
    end
    if isNew and not (info.dead and db.ignoreDead) then
        current = e
        Announce(e)
    end
    if isNew and ns.MapRefresh then ns.MapRefresh() end
    Refresh()
end
ns.Found = Found

local function Remove(e)
    if not e then return end
    byKey[e.key] = nil
    for i = #active, 1, -1 do if active[i] == e then table.remove(active, i) end end
    if current == e then current = nil end
    if ns.MapRefresh then ns.MapRefresh() end
end

-- Is this rare on the alert list right now (for the map pins)?
function ns.IsActive(npcID)
    local e = npcID and byKey["id" .. npcID]
    return e ~= nil and not e.test
end
ns.IsIgnored = function(npcID, name) return IsIgnored(npcID, name) end

-- Point the arrow at a spot (map pin click).
function ns.PointAt(npcID, mapID, x, y)
    if not Bind() or not G.IsModuleEnabled("rareScanner") then return end
    local rec = RARES[npcID]
    if not rec then return end
    local key = "test"
    byKey[key] = nil
    for i = #active, 1, -1 do if active[i].key == key then table.remove(active, i) end end
    Found({ key = key, test = true, npcID = npcID, name = rec[1], level = rec[3], elite = rec[4],
        source = "map pin", map = mapID, x = x, y = y, quiet = true })
end

function ns.Clear()
    wipe(active); wipe(byKey); current = nil
    Refresh()
end

function ns.Dismiss()
    if current then
        if not current.test then dismissed[current.key] = GetTime() end   -- quiet for the cooldown
        Remove(current)
    end
    Refresh()
end

function ns.Ignore(e)
    e = e or current
    if not (e and db) or e.test then ns.Dismiss(); return end
    db.ignored[e.npcID or e.name] = true
    Say("ignoring " .. tostring(e.name) .. ". Undo on the Rare Scanner tab or /rare unignore " .. tostring(e.name))
    Remove(e)
    Refresh()
end

function ns.Unignore(what)
    if not db then return false end
    for k in pairs(db.ignored) do
        if tostring(k):lower() == tostring(what):lower()
           or (type(k) == "number" and RARES[k] and RARES[k][1]:lower() == tostring(what):lower()) then
            db.ignored[k] = nil
            return true
        end
    end
    return false
end

-------------------------------------------------------------------------------
--  Detection
-------------------------------------------------------------------------------
local function CheckUnit(unit)
    if not db or not unit then return end
    local ok, exists = pcall(UnitExists, unit)
    if not ok or not exists or Secret(exists) then return end
    if UnitIsPlayer(unit) then return end
    local pc = UnitPlayerControlled(unit)
    if Secret(pc) or pc then return end

    local guid = UnitGUID(unit)
    local npcID = NpcIDFromGUID(guid)
    local name = UnitName(unit)
    if Secret(name) then name = nil end
    if not npcID and name then npcID = ByName(name) end
    local rec = npcID and RARES[npcID]

    local cls = UnitClassification(unit)
    if Secret(cls) then cls = nil end
    local isRare = cls == "rare" or cls == "rareelite"
    local elite = cls == "rareelite"
    if not isRare and rec then isRare, elite = true, rec[4] end
    if not isRare then return end
    if elite and not db.rareElites then return end

    local dead = UnitIsDead(unit)
    if Secret(dead) then dead = false end
    local key = EntryKey(npcID, name)
    RecordSighting(npcID, dead)        -- history for the map tooltips, even when no alert
    if dead and db.ignoreDead and not byKey[key] then return end

    local level = UnitLevel(unit)
    if Secret(level) then level = nil end
    Found({ key = key, npcID = npcID, name = name or (rec and rec[1]) or "Rare",
        level = level or (rec and rec[3]), elite = elite, unit = unit, dead = dead,
        source = unit:find("^nameplate") and "nameplate" or unit })
end
ns.CheckUnit = CheckUnit

-- Vignettes: the skull/star icons. Kill vignettes and database rares only.
local function VignetteIsRare(info, npcID)
    if npcID and RARES[npcID] then return true end
    local atlas = info.atlasName
    if type(atlas) ~= "string" or Secret(atlas) then return false end
    atlas = atlas:lower()
    return atlas:find("kill") ~= nil or atlas:find("rare") ~= nil
end

local function ScanVignettes()
    if not (db and db.scanVignettes and C_VignetteInfo and C_VignetteInfo.GetVignettes) then return end
    local ok, list = pcall(C_VignetteInfo.GetVignettes)
    if not ok or type(list) ~= "table" then return end
    local mapID = PlayerPos()
    for _, guid in ipairs(list) do
        local ok2, info = pcall(C_VignetteInfo.GetVignetteInfo, guid)
        if ok2 and info and not Secret(info.name) then
            local npcID = NpcIDFromGUID(info.objectGUID)
            if VignetteIsRare(info, npcID) then
                local rec = npcID and RARES[npcID]
                local x, y
                if mapID and C_VignetteInfo.GetVignettePosition then
                    local ok3, pos = pcall(C_VignetteInfo.GetVignettePosition, guid, mapID)
                    if ok3 and pos then
                        local vx, vy = pos:GetXY()
                        if vx and vx > 0 then x, y = vx * 100, vy * 100 end
                    end
                end
                local key = EntryKey(npcID, info.name)
                RecordSighting(npcID, info.isDead)
                if not (info.isDead and db.ignoreDead and not byKey[key]) then
                    Found({ key = key, npcID = npcID, name = info.name or (rec and rec[1]) or "Rare",
                        level = rec and rec[3], elite = rec and rec[4] or false, vignette = guid,
                        map = x and mapID or nil, x = x, y = y, dead = info.isDead and true or false,
                        source = "vignette" })
                end
            end
        end
    end
end

local function NamePlateUnits()
    local out = {}
    if not (C_NamePlate and C_NamePlate.GetNamePlates) then return out end
    local ok, plates = pcall(C_NamePlate.GetNamePlates)
    if not ok or type(plates) ~= "table" then return out end
    for _, p in ipairs(plates) do
        local u = p.namePlateUnitToken or (p.UnitFrame and p.UnitFrame.unit)
        if u and not Secret(u) then out[#out + 1] = u end
    end
    return out
end

local function Sweep()
    if not db then return end
    if db.scanTarget then CheckUnit("target") end
    if db.scanNameplates then
        for _, u in ipairs(NamePlateUnits()) do CheckUnit(u) end
    end
    ScanVignettes()
    -- Expire
    local now = GetTime()
    for i = #active, 1, -1 do
        local e = active[i]
        local gone = (now - (e.lastSeen or now)) > (db.timeout or 180)
        if e.deadAt and db.hideKilled and now - e.deadAt > 4 then gone = true end
        if gone then Remove(e) end
    end
    if not current and active[1] then current = active[1] end
    Refresh()
end

-------------------------------------------------------------------------------
--  Frames: holder (moved in Unlock Mode) = arrow + card
-------------------------------------------------------------------------------
local holder, arrowFrame, arrow, glow, card, nameFS, subFS, distFS, countFS, skull, accent
local targetBtn
local unlockActive = false

local function Font(fs, size)
    local font, flag
    if G.Ellesmere and G.Ellesmere.Font then
        local ok, f, o = pcall(G.Ellesmere.Font)
        if ok then font, flag = f, o end
    end
    fs:SetFont(font or STANDARD_TEXT_FONT, size, flag or "OUTLINE")
    fs:SetShadowOffset(0, 0)
end

local function AccentRGB()
    local c = EllesmereUI and EllesmereUI.ELLESMERE_GREEN
    if c then return c.r, c.g, c.b end
    return 0.05, 0.82, 0.62
end

local function SmallButton(parent, text, w)
    local b = CreateFrame("Button", nil, parent)
    b:SetSize(w, 16)
    local bg = b:CreateTexture(nil, "BACKGROUND")
    bg:SetAllPoints(); bg:SetColorTexture(1, 1, 1, 0.08)
    local fs = b:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    Font(fs, 10); fs:SetPoint("CENTER"); fs:SetText(text)
    b:SetScript("OnEnter", function() bg:SetColorTexture(1, 1, 1, 0.2) end)
    b:SetScript("OnLeave", function() bg:SetColorTexture(1, 1, 1, 0.08) end)
    return b
end

local OnUpdate     -- forward

local function BuildFrames()
    if holder then return end
    holder = CreateFrame("Frame", "WarUIRareScannerFrame", UIParent)
    holder:SetSize(CARD_W, CARD_H + 80)
    holder:SetFrameStrata("HIGH")
    holder:SetClampedToScreen(true)
    holder:Hide()

    arrowFrame = CreateFrame("Frame", nil, holder)
    arrowFrame:SetSize(72, 72)
    arrowFrame:SetPoint("BOTTOM", holder, "BOTTOM", 0, CARD_H + 4)
    glow = arrowFrame:CreateTexture(nil, "BACKGROUND")
    glow:SetTexture(GLOW_TEX)
    glow:SetPoint("CENTER"); glow:SetSize(110, 110)
    glow:SetBlendMode("ADD")
    arrow = arrowFrame:CreateTexture(nil, "ARTWORK")
    arrow:SetTexture(ARROW_TEX)
    arrow:SetAllPoints()
    distFS = arrowFrame:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
    distFS:SetPoint("LEFT", arrowFrame, "RIGHT", 4, 0)

    card = CreateFrame("Frame", nil, holder)
    card:SetSize(CARD_W, CARD_H)
    card:SetPoint("BOTTOM", holder, "BOTTOM", 0, 0)
    local bg = card:CreateTexture(nil, "BACKGROUND")
    bg:SetAllPoints(); bg:SetColorTexture(0.04, 0.04, 0.05, 0.88)
    -- 1px border
    for _, side in ipairs({ { "TOPLEFT", "TOPRIGHT", nil, 1 }, { "BOTTOMLEFT", "BOTTOMRIGHT", nil, 1 },
                            { "TOPLEFT", "BOTTOMLEFT", 1, nil }, { "TOPRIGHT", "BOTTOMRIGHT", 1, nil } }) do
        local t = card:CreateTexture(nil, "BORDER")
        t:SetColorTexture(0, 0, 0, 1)
        t:SetPoint(side[1]); t:SetPoint(side[2])
        if side[3] then t:SetWidth(side[3]) else t:SetHeight(side[4]) end
    end
    accent = card:CreateTexture(nil, "ARTWORK")
    accent:SetPoint("TOPLEFT", 1, -1); accent:SetPoint("BOTTOMLEFT", 1, 1); accent:SetWidth(3)

    skull = card:CreateTexture(nil, "ARTWORK")
    skull:SetTexture(SKULL_TEX)
    skull:SetSize(22, 22)
    skull:SetPoint("LEFT", card, "LEFT", 12, 0)

    nameFS = card:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
    nameFS:SetPoint("TOPLEFT", card, "TOPLEFT", 42, -9)
    nameFS:SetPoint("RIGHT", card, "RIGHT", -58, 0)
    nameFS:SetJustifyH("LEFT"); nameFS:SetWordWrap(false)
    subFS = card:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    subFS:SetPoint("TOPLEFT", nameFS, "BOTTOMLEFT", 0, -4)
    subFS:SetPoint("RIGHT", card, "RIGHT", -58, 0)
    subFS:SetJustifyH("LEFT"); subFS:SetWordWrap(false)
    countFS = card:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    countFS:SetPoint("BOTTOMRIGHT", card, "BOTTOMRIGHT", -6, 5)

    local close = SmallButton(card, "X", 18)
    close:SetPoint("TOPRIGHT", card, "TOPRIGHT", -5, -5)
    close:SetScript("OnClick", function() ns.Dismiss() end)
    local ign = SmallButton(card, "Ignore", 40)
    ign:SetPoint("RIGHT", close, "LEFT", -3, 0)
    ign:SetScript("OnClick", function() ns.Ignore() end)

    -- Click the name to target the rare: a secure macro button of its own
    -- (parented to UIParent, not to our frame, so our frame can still be
    -- shown/hidden in combat). Its macro text is only changed out of combat.
    if not InCombatLockdown() then
        local ok, btn = pcall(CreateFrame, "Button", "WarUIRareScannerTarget", UIParent, "SecureActionButtonTemplate")
        if ok and btn then
            targetBtn = btn
            btn:SetFrameStrata("HIGH")
            btn:SetFrameLevel(100)
            btn:SetSize(1, 1)
            btn:SetPoint("CENTER", UIParent, "BOTTOMLEFT", -100, -100)
            btn:RegisterForClicks("AnyUp", "AnyDown")
            btn:SetAttribute("type", "macro")
            btn:SetAttribute("macrotext", "")
            btn:SetScript("OnEnter", function(self)
                GameTooltip:SetOwner(self, "ANCHOR_TOP")
                GameTooltip:SetText("Click to target")
                GameTooltip:Show()
            end)
            btn:SetScript("OnLeave", function() GameTooltip:Hide() end)
            btn:Hide()
        end
    end

    holder:SetScript("OnUpdate", OnUpdate)
end

-- The secure button is anchored to UIParent (never to our frames, so ours
-- stay free to move, scale and hide in combat) and laid over the card's
-- left part (not the X / Ignore buttons), only out of combat.
local pendingTarget     -- name to put on the button after combat (false = none)
local targetName
local function PlaceTargetButton()
    if not (targetBtn and card) or InCombatLockdown() then return end
    local l, b, w, h = card:GetRect()
    if not l then return end
    local f = card:GetEffectiveScale() / UIParent:GetEffectiveScale()
    targetBtn:ClearAllPoints()
    targetBtn:SetPoint("BOTTOMLEFT", UIParent, "BOTTOMLEFT", l * f, b * f)
    targetBtn:SetSize(math.max(1, (w - 70) * f), h * f)
end

local function SetTargetButton(name)
    if not targetBtn then return end
    if InCombatLockdown() then
        if name ~= targetName then pendingTarget = name or false end
        return
    end
    pendingTarget = nil
    if name then PlaceTargetButton() end
    if name == targetName then return end
    targetName = name
    if name then
        targetBtn:SetAttribute("macrotext", "/cleartarget\n/targetexact " .. name)
        targetBtn:Show()
    else
        targetBtn:SetAttribute("macrotext", "")
        targetBtn:Hide()
    end
end

function ns.ApplyPosition()
    if not holder then return end
    holder:ClearAllPoints()
    local p = db and db.pos
    if p and p.point then
        holder:SetPoint(p.point, UIParent, p.relPoint or p.point, p.x or 0, p.y or 0)
    else
        holder:SetPoint("TOP", UIParent, "TOP", 0, -140)
    end
end

function ns.ApplyStyle()
    if not holder or not db then return end
    local size = db.arrowSize or 72
    arrowFrame:SetSize(size, size)
    glow:SetSize(size * 1.6, size * 1.6)
    arrowFrame:SetShown(db.showArrow)
    holder:SetSize(CARD_W, CARD_H + (db.showArrow and (size + 8) or 0))
    holder:SetScale((db.scale or 100) / 100)
    Font(nameFS, 14); Font(subFS, 11); Font(countFS, 10); Font(distFS, 13)
end

-------------------------------------------------------------------------------
--  Arrow
-------------------------------------------------------------------------------
local PREVIEW = { key = "preview", name = "Rare Scanner", elite = false, source = "preview", spin = true, preview = true }

-- Angle (radians, ccw; 0 = straight up/ahead) and distance in yards, or nil.
local function Direction(e)
    -- Nameplate on screen: point at it.
    if e.unit and C_NamePlate and C_NamePlate.GetNamePlateForUnit then
        local ok, plate = pcall(C_NamePlate.GetNamePlateForUnit, e.unit)
        if ok and plate and plate:IsVisible() and UnitExists(e.unit) then
            local nm = UnitName(e.unit)
            if not Secret(nm) and nm == e.name then
                local x, y = plate:GetCenter()
                if x then
                    local s = plate:GetEffectiveScale() / UIParent:GetEffectiveScale()
                    local cx, cy = UIParent:GetCenter()
                    local dx, dy = x * s - cx, y * s - cy
                    return atan2(-dx, dy), nil, "screen"
                end
            end
        end
    end
    -- World position (vignette / database / last seen)
    if e.map and e.x then
        local mapID, px, py = PlayerPos()
        if mapID == e.map then
            local east, south = Offset(mapID, px, py, e.x, e.y)
            local facing = GetPlayerFacing and GetPlayerFacing()
            if east and facing and not Secret(facing) then
                local ang = atan2(-east, -south) - facing
                return ang, sqrt(east * east + south * south), "world"
            elseif east then
                return nil, sqrt(east * east + south * south), "world"
            end
        end
        return nil, nil, "othermap"
    end
    return nil, nil, nil
end

local function ArrowColor(ang)
    local key = db and db.arrowColor or "direction"
    if key == "accent" then return AccentRGB() end
    local c = COLORS[key]
    if c and c[2] then return c[2], c[3], c[4] end
    -- direction: 0 = ahead (green) .. pi = behind (red)
    local a = abs(((ang or 0) + pi) % (2 * pi) - pi) / pi     -- 0..1
    if a < 0.5 then return a * 2, 1, 0.15 end
    return 1, 1 - (a - 0.5) * 2, 0.15
end

local spin, pulse, throttle = 0, 0, 0
OnUpdate = function(_, dt)
    throttle = throttle + dt
    pulse = pulse + dt
    if throttle < 0.025 then return end
    local step = throttle
    throttle = 0
    local e = current or (unlockActive and PREVIEW) or nil
    if not e or not db then return end

    local ang, dist, mode = Direction(e)
    if e.spin then
        spin = (spin + step * 1.5) % (2 * pi)
        ang, mode = spin, "spin"
    end
    local arrived = dist and dist <= (db.arriveDist or 12)
    if ang and not arrived then
        arrow:SetTexture(ARROW_TEX)
        arrow:SetRotation(ang)
        arrow:SetAlpha(1)
        arrow:SetVertexColor(ArrowColor(ang))
    elseif arrived then
        arrow:SetRotation(0)
        arrow:SetVertexColor(0.2, 1, 0.35)
        arrow:SetAlpha(0.5 + 0.5 * abs(math.sin(pulse * 4)))
    else
        arrow:SetRotation(0)
        arrow:SetVertexColor(0.6, 0.6, 0.6)
        arrow:SetAlpha(0.35)
    end
    -- Glow pulses for the first 5 seconds of a new alert
    local age = GetTime() - (e.firstSeen or 0)
    if age < 5 or e.preview then
        glow:SetAlpha(0.25 + 0.35 * abs(math.sin(pulse * 3)))
    else
        glow:SetAlpha(0.12)
    end
    glow:SetVertexColor(arrow:GetVertexColor())

    if db.showDistance then
        if arrived then distFS:SetText("|cff33ff55here|r")
        elseif dist then distFS:SetText(string.format("%d yd", floor(dist + 0.5)))
        elseif mode == "screen" then distFS:SetText("|cffaaaaaanear|r")
        elseif mode == "othermap" then distFS:SetText("|cffaaaaaaother zone|r")
        else distFS:SetText("") end
        distFS:Show()
    else
        distFS:Hide()
    end
end

-------------------------------------------------------------------------------
--  Card
-------------------------------------------------------------------------------
local SOURCE_TEXT = {
    nameplate = "nameplate", target = "your target", mouseover = "mouseover",
    vignette = "map icon", test = "test", database = "database spawn", preview = "Unlock Mode preview",
    ["map pin"] = "map pin (spawn point)",
}

Refresh = function()
    if not holder then return end
    if not db or not G.IsModuleEnabled("rareScanner") then
        holder:Hide(); SetTargetButton(nil); return
    end
    if current and not byKey[current.key] then current = nil end
    if not current and active[1] then current = active[1] end
    local e = current or (unlockActive and PREVIEW) or nil
    if not e then
        holder:Hide()
        SetTargetButton(nil)
        return
    end
    local r, g, b = 0.75, 0.80, 0.95                 -- rare: silver-blue
    if e.elite then r, g, b = 1.0, 0.75, 0.15 end    -- rare elite: gold
    accent:SetColorTexture(r, g, b, 1)
    skull:SetVertexColor(r, g, b)
    nameFS:SetText(e.name or "?")
    nameFS:SetTextColor(r, g, b)
    local parts = {}
    parts[#parts + 1] = e.elite and "Rare Elite" or "Rare"
    if e.level and e.level > 0 then parts[#parts + 1] = "Level " .. e.level end
    if e.deadAt or e.dead then parts[#parts + 1] = "|cffff4040dead|r" end
    parts[#parts + 1] = "|cff999999" .. (SOURCE_TEXT[e.source] or tostring(e.source or "")) .. "|r"
    subFS:SetText(table.concat(parts, " · "))
    subFS:SetTextColor(1, 1, 1, 0.85)
    countFS:SetText(#active > 1 and ("+" .. (#active - 1) .. " more") or "")
    holder:Show()
    SetTargetButton(not e.test and not e.preview and e.name or nil)
end
ns.Refresh = function() Refresh() end

-------------------------------------------------------------------------------
--  Test helpers (settings page + /rare test)
-------------------------------------------------------------------------------
function ns.Test()
    if not Bind() then return end
    if not G.IsModuleEnabled("rareScanner") then
        Say("turn Rare Scanner on first (War UI > General > Rare Scanner).")
        return
    end
    local mapID, x, y = PointFromPlayer(80, pi / 4)     -- 80 yards, ahead-left
    local info = { key = "test", test = true, npcID = nil, name = "Test Rare (Mother Fang)",
        level = UnitLevel("player"), elite = false, source = "test", firstSeen = GetTime() }
    if mapID then
        info.map, info.x, info.y = mapID, x, y
    else
        info.spin = true
        Say("no map position here (instance?), so the test arrow just spins.")
    end
    byKey.test = nil
    for i = #active, 1, -1 do if active[i].key == "test" then table.remove(active, i) end end
    lastAlert.test = nil
    Found(info)
    if mapID then Say("a test rare was placed 80 yards ahead-left of you. Turn around and walk: the arrow follows it.") end
end

function ns.TestNearest()
    if not Bind() then return end
    if not G.IsModuleEnabled("rareScanner") then
        Say("turn Rare Scanner on first (War UI > General > Rare Scanner).")
        return
    end
    local mapID, px, py = PlayerPos()
    if not mapID then Say("no map position here."); return end
    local best, bd
    for _, r in ipairs(ns.RaresOnMap(mapID)) do
        local east, south = Offset(mapID, px, py, r.x, r.y)
        local d = east and sqrt(east * east + south * south) or (abs(r.x - px) + abs(r.y - py))
        if not bd or d < bd then best, bd = r, d end
    end
    if not best then Say("the database has no rares on this map."); return end
    local key = "test"
    byKey[key] = nil
    for i = #active, 1, -1 do if active[i].key == key then table.remove(active, i) end end
    lastAlert[key] = nil
    Found({ key = key, test = true, npcID = best.id, name = best.rec[1], level = best.rec[3],
        elite = best.rec[4], source = "database", map = mapID, x = best.x, y = best.y })
end

-------------------------------------------------------------------------------
--  EllesmereUI Unlock Mode. Every callback copes with a missing db and never
--  throws (an error stops Ellesmere's positioning for every module).
-------------------------------------------------------------------------------
local unlockDone = false
local function RegisterUnlock()
    if unlockDone or not (EllesmereUI and EllesmereUI.RegisterUnlockElements) then return end
    unlockDone = true
    pcall(EllesmereUI.RegisterUnlockElements, EllesmereUI, {
        {
            key      = UNLOCK_KEY,
            label    = "Rare Scanner",
            getFrame = function() return holder end,
            getSize  = function()
                if not holder then return CARD_W, CARD_H + 80 end
                return holder:GetWidth(), holder:GetHeight()
            end,
            isHidden = function()
                local ok, on = pcall(G.IsModuleEnabled, "rareScanner")
                return not (db and ok and on)
            end,
            savePosition = function(_, point, relPoint, x, y)
                if db then db.pos = { point = point, relPoint = relPoint or point, x = x, y = y } end
            end,
            loadPosition = function() return db and db.pos or nil end,
            clearPosition = function() if db then db.pos = nil end end,
            applyPosition = function() pcall(ns.ApplyPosition) end,
        },
    }, "WarUI_General")
    if EllesmereUI.RegisterUnlockModeListener then
        pcall(EllesmereUI.RegisterUnlockModeListener, EllesmereUI, UNLOCK_KEY, function(on)
            unlockActive = on and true or false
            pcall(Refresh)
        end)
    end
end

function ns.OpenUnlockMode()
    if InCombatLockdown() then return end
    if EllesmereUI and EllesmereUI.OpenUnlockMode then
        if EllesmereUI.Hide then pcall(EllesmereUI.Hide, EllesmereUI) end
        EllesmereUI:OpenUnlockMode()
    end
end

-------------------------------------------------------------------------------
--  Module
-------------------------------------------------------------------------------
local defaults = {}
for k, v in pairs(DEFAULTS) do defaults[k] = v end

local M = G.RegisterModule("rareScanner", {
    title       = "Rare Scanner",
    description = "Alerts you when a rare or rare elite shows up and points an arrow at it.",
    pages       = { "Rare Scanner" },
    defaults    = defaults,
})
ns.M = M

local ev = CreateFrame("Frame")
local sweeper
local EVENTS = { "NAME_PLATE_UNIT_ADDED", "PLAYER_TARGET_CHANGED", "UPDATE_MOUSEOVER_UNIT",
    "VIGNETTE_MINIMAP_UPDATED", "VIGNETTES_UPDATED", "ZONE_CHANGED_NEW_AREA",
    "PLAYER_ENTERING_WORLD", "PLAYER_REGEN_ENABLED" }

ev:SetScript("OnEvent", function(_, event, arg1)
    if not db then return end
    if event == "NAME_PLATE_UNIT_ADDED" then
        if db.scanNameplates then CheckUnit(arg1) end
    elseif event == "PLAYER_TARGET_CHANGED" then
        if db.scanTarget then CheckUnit("target") end
    elseif event == "UPDATE_MOUSEOVER_UNIT" then
        if db.scanTarget then CheckUnit("mouseover") end
    elseif event == "VIGNETTE_MINIMAP_UPDATED" or event == "VIGNETTES_UPDATED" then
        ScanVignettes()
    elseif event == "PLAYER_REGEN_ENABLED" then
        if pendingTarget ~= nil then SetTargetButton(pendingTarget or nil) end
    else
        Sweep()
    end
end)

function M:Enable()
    if not Bind() then error("Rare Scanner: no settings yet") end
    BuildFrames()
    if ns.AttachToMap then pcall(ns.AttachToMap) end
    RegisterUnlock()
    for _, e in ipairs(EVENTS) do pcall(ev.RegisterEvent, ev, e) end
    if not sweeper then
        sweeper = C_Timer.NewTicker(0.5, function()
            if db and G.IsModuleEnabled("rareScanner") then
                local ok, err = pcall(Sweep)
                if not ok then G.Log("ERROR", "rareScanner sweep: %s", tostring(err)) end
            end
        end)
    end
end

function M:Apply()
    Bind()
    ns.ApplyStyle()
    ns.ApplyPosition()
    Refresh()
    if ns.MapRefresh then ns.MapRefresh() end
end

function M:Disable()
    Bind()
    ev:UnregisterAllEvents()
    if sweeper then sweeper:Cancel(); sweeper = nil end
    wipe(active); wipe(byKey); current = nil
    if holder then holder:Hide() end
    SetTargetButton(nil)
    if ns.MapRefresh then ns.MapRefresh() end
end

-------------------------------------------------------------------------------
--  Slash
-------------------------------------------------------------------------------
SLASH_WARUIRARESCANNER1 = "/rare"
SLASH_WARUIRARESCANNER2 = "/rarescanner"
SlashCmdList.WARUIRARESCANNER = function(msg)
    msg = (msg or ""):match("^%s*(.-)%s*$")
    local cmd, rest = msg:match("^(%S*)%s*(.-)$")
    cmd = (cmd or ""):lower()
    if not G.db then return end
    Bind()
    if cmd == "test" then
        ns.Test()
    elseif cmd == "nearest" then
        ns.TestNearest()
    elseif cmd == "clear" or cmd == "hide" then
        ns.Clear()
    elseif cmd == "on" or cmd == "off" or cmd == "toggle" then
        local on = (cmd == "on") or (cmd == "toggle" and not G.IsModuleEnabled("rareScanner"))
        G.SetModuleEnabled("rareScanner", on)
        Say(G.IsModuleEnabled("rareScanner") and "on" or "off")
    elseif cmd == "move" or cmd == "unlock" then
        ns.OpenUnlockMode()
    elseif cmd == "ignore" and rest ~= "" then
        local id = tonumber(rest) or ByName(rest)
        db.ignored[id or rest] = true
        Say("ignoring " .. rest)
    elseif cmd == "unignore" and rest ~= "" then
        Say(ns.Unignore(rest) and ("no longer ignoring " .. rest) or (rest .. " was not ignored"))
    elseif cmd == "list" then
        local mapID = PlayerPos()
        local seen, names = {}, {}
        for _, r in ipairs(ns.RaresOnMap(mapID)) do
            if not seen[r.id] then
                seen[r.id] = true
                names[#names + 1] = string.format("%s [%d]%s", r.rec[1], r.rec[3], r.rec[4] and " elite" or "")
            end
        end
        table.sort(names)
        Say(#names .. " rare(s) on this map" .. (#names > 0 and (": " .. table.concat(names, ", ")) or "."))
    elseif cmd == "debug" then
        local mapID, px, py = PlayerPos()
        local s = mapID and MapYards(mapID)
        Say(string.format("on=%s map=%s pos=%s size=%s facing=%s active=%d current=%s vignettes=%s nameplates=%d",
            tostring(G.IsModuleEnabled("rareScanner")), tostring(mapID),
            px and string.format("%.1f,%.1f", px, py) or "-",
            s and string.format("%dx%d yd", s[1], s[2]) or "-",
            tostring(GetPlayerFacing and GetPlayerFacing()), #active,
            current and tostring(current.name) or "-",
            tostring(C_VignetteInfo ~= nil), #NamePlateUnits()))
    else
        G.Options.Open("rareScanner")
    end
end
