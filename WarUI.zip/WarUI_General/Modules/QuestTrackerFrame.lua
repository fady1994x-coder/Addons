-- ProseccoUI / Modules / QuestTrackerFrame.lua
-- The Quest Tracker's frame and settings page (step 6b, steg6b-forslag.md
-- with Alexander's decisions of 2026-10-08). Reads the quest list through
-- M.Quests() (QuestTracker.lua) and never calls the quest log API itself.
--
-- One frame of ours on UIParent: a header ("Quests" left, the quest log's
-- fill right), the loaded RXP guide's progress under it, then the watched
-- quests by zone in a scroll frame. The quest item buttons (step 6c) are
-- secure action buttons on the scroll child; everything else is ours and
-- insecure. While any button exists the whole draw waits out combat: the
-- buttons cannot be moved then, and neither can the scroll child they hang
-- on (a protected frame protects what it is anchored to). The redraw the
-- data half queues on PLAYER_REGEN_ENABLED catches the tracker up.
--
-- Order: with an RXP guide loaded, quests the guide names come first, by the
-- next step that names them; the rest follow in Blizzard's watch order,
-- which Blizzard's tracker keeps sorted by distance (QuestTracker.lua). Zones
-- come in the order of their first quest. Within a zone, completed quests go
-- to the top, the bottom or stay where they are (Completed Quests).

-- War UI: this module runs on the shared core in WarUI_General.
local ns = WarUIGeneral

local M = ns.GetModule("questTracker")
local DB = M.DB

-- War UI: a small public API so other War UI addons (WarUI_GuideHighlight)
-- can draw on the quests this tracker shows. drawn[i] = { id, row (title row,
-- our Button), last (the quest's last row), title (FontString), r, g, b (the
-- title's own colour), gutter }; empty while folded or hidden. Callbacks run
-- right after every draw.
local drawn, drawCallbacks = {}, {}
local function FireDrawn()
    for _, fn in ipairs(drawCallbacks) do
        xpcall(fn, ns.ErrorHandler("questTracker:onDraw"))
    end
end
WarUIQuestTracker = {
    IsActive = function() return ns.IsModuleEnabled("questTracker") end,
    Quests   = function() return drawn end,
    OnDraw   = function(fn) if type(fn) == "function" then drawCallbacks[#drawCallbacks + 1] = fn end end,
}

local DOT_TEX = ns.RXP.TEXTURE_PATH .. "white_circle"   -- our own texture, also used by the RXP theme
local DOT_R, DOT_G, DOT_B = 0.25, 0.6, 1                -- the blue of the guide dot
local ZONE_R, ZONE_G, ZONE_B = 0.85, 0.85, 0.85
local OBJ_R, OBJ_G, OBJ_B = 0.8, 0.8, 0.8
-- Ellesmere's tracker colours: completed 40FF59 (EllesmereUIQuestTracker.lua:66).
local DONE_R, DONE_G, DONE_B = 0.251, 1, 0.349
local FAIL_R, FAIL_G, FAIL_B = 1, 0.25, 0.25
local INDENT = 10           -- objectives under their quest title, UI units
local SCROLL_STEP = 24

local function num(v, fallback) return tonumber(v) or fallback end

local frame, header, progress, scroll, child
local rows = {}             -- row pool, reused on every draw
local expanded = {}         -- zone -> true: opened by a click while Current Zone Only is on (runtime)
local buttons = {}          -- secure item button pool (step 6c), laid out only out of combat
local itemPlan = {}         -- the draw's button placements, filled by DrawRows for LayoutItems
local timerRows = {}        -- { fs, ends }: timed quests' rows the ticker refreshes
local ticker                -- 1 s C_Timer ticker, running only while timerRows has rows
local unlockActive = false  -- EllesmereUI's Unlock Mode is open: show the tracker even with nothing tracked

-- ---------------------------------------------------------------------------
-- Frames
-- ---------------------------------------------------------------------------

-- Every text in the tracker (and "Quest Completed") takes the same face,
-- outline and shadow from the TEXT settings; only the sizes differ.
local function Font(fs, size)
    local d = DB()
    local path, flags = ns.Ellesmere.Font()
    if d.font and d.font ~= "" then path = ns.Media.Font(d.font) end
    if d.outline == "none" then
        flags = ""
    elseif d.outline ~= "ellesmere" then
        flags = d.outline
    end
    fs:SetFont(path, tonumber(size) or 12, flags or "")
    if d.shadow then
        fs:SetShadowColor(0, 0, 0, 1)
        fs:SetShadowOffset(1, -1)
    else
        fs:SetShadowOffset(0, 0)
    end
end

local function OnDragStart()
    -- With secure buttons under the frame, moving it in combat is blocked.
    if buttons[1] and InCombatLockdown() then return end
    frame.dragRight, frame.dragTop = frame:GetRight(), frame:GetTop()
    frame:StartMoving()
end

-- StopMovingOrSizing re-anchors the frame to the screen; the drag is turned
-- into a change of our own offsets instead (as Panels), so the saved
-- position stays the one the page shows.
local function OnDragStop()
    frame:StopMovingOrSizing()
    local d = DB()
    if frame.dragRight then
        d.x = math.floor((tonumber(d.x) or 0) + (frame:GetRight() - frame.dragRight) + 0.5)
        d.y = math.floor((tonumber(d.y) or 0) + (frame:GetTop() - frame.dragTop) + 0.5)
    end
    frame.dragRight, frame.dragTop = nil, nil
    M.Draw()
    ns.Ellesmere.RefreshPage()
end

local function OnHeaderClick(_, button)
    if button ~= "LeftButton" or DB().unlocked then return end
    DB().collapsed = not DB().collapsed
    M.Draw()
end

local function OnWheel(_, delta)
    local max = math.max(0, child:GetHeight() - scroll:GetHeight())
    scroll:SetVerticalScroll(math.max(0, math.min(max, scroll:GetVerticalScroll() - delta * SCROLL_STEP)))
end

local function EnsureFrame()
    if frame then return end
    frame = CreateFrame("Frame", "WarUIQuestTrackerFrame", UIParent)
    frame:Hide()                        -- M.Draw decides; an empty frame never flashes up
    frame:SetFrameStrata("LOW")
    frame:SetMovable(true)
    frame:SetClampedToScreen(true)
    frame:SetDontSavePosition(true)     -- our offsets are the saved position
    frame:RegisterForDrag("LeftButton")
    frame:SetScript("OnDragStart", OnDragStart)
    frame:SetScript("OnDragStop", OnDragStop)
    frame.bg = frame:CreateTexture(nil, "BACKGROUND")
    -- With Header Seam the header above the seam has its own background.
    frame.headerBg = frame:CreateTexture(nil, "BACKGROUND")

    header = CreateFrame("Button", nil, frame)
    header:RegisterForClicks("LeftButtonUp")
    header:RegisterForDrag("LeftButton")
    header:SetScript("OnClick", OnHeaderClick)
    header:SetScript("OnDragStart", function() if DB().unlocked then OnDragStart() end end)
    header:SetScript("OnDragStop", function() if frame.dragRight then OnDragStop() end end)
    header.title = header:CreateFontString(nil, "OVERLAY")
    header.title:SetPoint("LEFT")
    header.count = header:CreateFontString(nil, "OVERLAY")
    header.count:SetPoint("RIGHT")

    progress = CreateFrame("Frame", nil, frame)
    progress.name = progress:CreateFontString(nil, "OVERLAY")
    progress.name:SetPoint("TOPLEFT")
    progress.name:SetJustifyH("LEFT")
    progress.name:SetWordWrap(false)
    progress.pct = progress:CreateFontString(nil, "OVERLAY")
    progress.pct:SetPoint("TOPRIGHT")
    -- The bar's 1 px border: ns.Border.Apply on a frame round the track.
    progress.box = CreateFrame("Frame", nil, progress)
    progress.track = progress:CreateTexture(nil, "ARTWORK")
    progress.track:SetColorTexture(1, 1, 1, 0.12)
    progress.fill = progress:CreateTexture(nil, "OVERLAY")
    progress.fill:SetColorTexture(DOT_R, DOT_G, DOT_B, 1)

    -- Header Seam: our border's line under the header, edge to edge, as the
    -- Damage Meter's Header Seam (ns.Border.Seam). Above the background and
    -- the border holder (frame level + 1, Core/Border.lua).
    frame.seam = CreateFrame("Frame", nil, frame)
    frame.seam:SetFrameLevel(frame:GetFrameLevel() + 2)
    frame.seam:EnableMouse(false)
    frame.seam.tex = frame.seam:CreateTexture(nil, "OVERLAY")

    scroll = CreateFrame("ScrollFrame", nil, frame)
    scroll:SetScript("OnMouseWheel", OnWheel)
    child = CreateFrame("Frame", nil, scroll)
    scroll:SetScrollChild(child)
end

-- Quest rows open the quest or untrack it, as on Blizzard's tracker
-- (Known: Blizzard_QuestObjectiveTracker.lua:51-69, build 70245): a chat link
-- first while the edit box is open, then the watch toggle (Shift), else the
-- quest log. QuestMapFrame_OpenToQuestDetails is what Blizzard's tracker
-- calls; Forever loads it (Known: Blizzard_UIPanels_Game.toc, Mainline/
-- QuestMapFrame.lua:1175 for the mainline family, camelot included). That it
-- opens the quest log from an addon, in combat too, is Unverified.
-- Alt-click: abandon after a confirm popup (Ellesmere's, so no Blizzard
-- StaticPopup is driven from addon code). The calls are the ones Blizzard's
-- own Abandon makes (Known: QuestMapFrame.lua:1473-1494 QuestMapQuestOptions_
-- AbandonQuest, build 70291): select the quest, mark it, then AbandonQuest on
-- accept. The previous selection is put back so the quest log keeps its own.
local function MarkForAbandon(id)
    local old = C_QuestLog.GetSelectedQuest()
    C_QuestLog.SetSelectedQuest(id)
    C_QuestLog.SetAbandonQuest()
    return old
end

local function Abandon(id)
    if not C_QuestLog.CanAbandonQuest(id) then
        ns.Print("This quest can't be abandoned.")
        return
    end
    local title = C_QuestLog.GetTitleForQuestID(id) or "this quest"
    local old = MarkForAbandon(id)
    local items = C_QuestLog.GetAbandonQuestItems()
    C_QuestLog.SetSelectedQuest(old or 0)
    local function DoAbandon()
        -- The quest may have left the log while the popup was open; then
        -- SetAbandonQuest would mark whatever the log has selected.
        if not C_QuestLog.GetLogIndexForQuestID(id) then return end
        local prev = MarkForAbandon(id)
        if C_QuestLog.GetAbandonQuest() == id then C_QuestLog.AbandonQuest() end
        C_QuestLog.SetSelectedQuest(prev or 0)
    end
    if not DB().abandonConfirm then
        DoAbandon()
        return
    end
    local msg = "Abandon \"" .. title .. "\"?"
    if items and #items > 0 then
        msg = msg .. "\nItems from this quest will be destroyed."
    end
    ns.Ellesmere.Confirm({
        title = "Abandon Quest",
        message = msg,
        confirmText = "Abandon",
        onConfirm = DoAbandon,
    })
end

local function OnQuestClick(self, button)
    local id = self.questID
    if not id then return end
    -- Right-click folds the quest to its title and back; left-click keeps
    -- Blizzard's tracker behaviour below.
    if button == "RightButton" then
        local folded = DB().folded
        folded[id] = not folded[id] or nil
        M.Draw()
        return
    end
    if button ~= "LeftButton" then return end
    if ChatFrameUtil.TryInsertQuestLinkForQuestID(id) then return end
    -- The watch toggle first, so a QUESTWATCHTOGGLE bound to Alt keeps untracking.
    if IsModifiedClick("QUESTWATCHTOGGLE") then
        C_QuestLog.RemoveQuestWatch(id)
        return
    end
    if IsAltKeyDown() and DB().altAbandon then
        Abandon(id)
        return
    end
    -- Questie's tracker on Forever refuses this in combat (Known: Questie
    -- TrackerUtils.lua:92-98, 42ee926); that it is blocked there is Inferred.
    if InCombatLockdown() then
        ns.Print("The quest log opens after combat.")
        return
    end
    QuestMapFrame_OpenToQuestDetails(id)
end

-- Every zone header folds and opens on a click (his ask 2026-10-09). With
-- Current Zone Only on, other zones keep the runtime toggle (closed by
-- default, open for this session); otherwise the choice is saved per zone.
local function OnZoneClick(self, button)
    if button ~= "LeftButton" or not self.zone then return end
    local d = DB()
    if d.currentZoneOnly and self.zone ~= (GetRealZoneText() or "") then
        expanded[self.zone] = not expanded[self.zone] or nil
    else
        d.foldedZones[self.zone] = not d.foldedZones[self.zone] or nil
    end
    M.Draw()
end

-- The minimize icon in the gutter: folds the quest to its title, the same
-- toggle as a right-click on the title (his ask 2026-10-09).
local function OnFoldClick(self)
    local id = self:GetParent().questID
    if not id then return end
    local folded = DB().folded
    folded[id] = not folded[id] or nil
    M.Draw()
end

local function Row(i)
    local r = rows[i]
    if r then return r end
    r = CreateFrame("Button", nil, child)
    r:RegisterForClicks("LeftButtonUp", "RightButtonUp")
    r.text = r:CreateFontString(nil, "OVERLAY")
    r.text:SetJustifyH("LEFT")
    r.text:SetJustifyV("TOP")
    r.text:SetWordWrap(true)
    -- Guide Highlight box: on the scroll child, one level under the rows, so
    -- the row's text and dot draw over it; its border through ns.Border.Apply.
    r.hl = CreateFrame("Frame", nil, child)
    r.hl:SetFrameLevel(child:GetFrameLevel())
    r.hl.bg = r.hl:CreateTexture(nil, "BACKGROUND")
    r.hl.bg:SetAllPoints(r.hl)
    -- The dot's outline is the same circle in black, one pixel larger all round.
    r.dotEdge = r:CreateTexture(nil, "OVERLAY", nil, 0)
    r.dotEdge:SetTexture(DOT_TEX)
    r.dotEdge:SetVertexColor(0, 0, 0, 1)
    r.dot = r:CreateTexture(nil, "OVERLAY", nil, 1)
    r.dot:SetTexture(DOT_TEX)
    r.dot:SetVertexColor(DOT_R, DOT_G, DOT_B, 1)
    -- Minimize icon, in the dot's place on quests outside the guide.
    r.fold = CreateFrame("Button", nil, r)
    r.fold:SetScript("OnClick", OnFoldClick)
    r.fold.txt = r.fold:CreateFontString(nil, "OVERLAY")
    r.fold.txt:SetPoint("CENTER")
    rows[i] = r
    return r
end

-- ---------------------------------------------------------------------------
-- Quest item buttons (step 6c)
-- ---------------------------------------------------------------------------

-- Blizzard's own tracker buttons use the item from protected code, which an
-- addon cannot (Known: Blizzard_ObjectiveTrackerShared.lua:94-104, build
-- 70291: QuestObjectiveItemButtonMixin calls UseQuestLogSpecialItem). The
-- addon way is Questie's: a SecureActionButtonTemplate whose item attribute
-- is the quest item's link (Known: Questie TrackerItemButton.lua:22-87,
-- 772e558). Attributes, anchors and visibility are only touched out of
-- combat (LayoutItems below).
local function OnItemEnter(self)
    if not self.logIndex then return end
    GameTooltip:SetOwner(self, "ANCHOR_LEFT")
    GameTooltip:SetQuestLogSpecialItem(self.logIndex)
end

local function ItemButton(i)
    local b = buttons[i]
    if b then return b end
    b = CreateFrame("Button", "WarUIQuestItem" .. i, child, "SecureActionButtonTemplate")
    b:SetAttribute("type1", "item")
    -- Both, as Questie: Forever can fire clicks on the down press.
    b:RegisterForClicks("AnyUp", "AnyDown")
    b.icon = b:CreateTexture(nil, "ARTWORK")
    b.icon:SetAllPoints(b)
    b.icon:SetTexCoord(0.08, 0.92, 0.08, 0.92)      -- trim the icon's baked edge
    b.cooldown = CreateFrame("Cooldown", nil, b, "CooldownFrameTemplate")
    b.cooldown:SetAllPoints(b.icon)
    b.count = b:CreateFontString(nil, "OVERLAY")
    b.count:SetPoint("BOTTOMRIGHT", -2, 2)
    ns.Border.Apply(b, { style = "solid", size = 1, color = "000000", alpha = 1 })
    b:SetScript("OnEnter", OnItemEnter)
    b:SetScript("OnLeave", function() GameTooltip:Hide() end)
    buttons[i] = b
    return b
end

local function UpdateCooldown(b)
    if not b.logIndex then return end
    local start, duration, enable = GetQuestLogSpecialItemCooldown(b.logIndex)
    if start then
        CooldownFrame_Set(b.cooldown, start, duration, enable)
    else
        b.cooldown:Clear()
    end
end

-- BAG_UPDATE_COOLDOWN (QuestTracker.lua's host): only the swipes change.
function M.UpdateItemCooldowns()
    for _, b in ipairs(buttons) do
        if b:IsShown() then UpdateCooldown(b) end
    end
end

-- Places the buttons the draw planned. Never in combat: the pool's frames
-- are protected, so the layout waits for the redraw the data half queues on
-- PLAYER_REGEN_ENABLED (M.Draw as a whole waits too, so this cannot run in
-- combat through the draw).
local function LayoutItems()
    -- Also guarded here, not only in M.Draw: before the first button exists
    -- M.Draw runs in combat (a /reload or an enable mid-fight, itemButtons
    -- default on), and creating or placing a secure button then is blocked.
    -- The rows draw with their right-side gap; the forced redraw on
    -- PLAYER_REGEN_ENABLED places the buttons.
    if InCombatLockdown() then return end
    local d = DB()
    local size = num(d.itemSize, 26)
    for i, p in ipairs(itemPlan) do
        local b = ItemButton(i)
        -- "item:<id>" as Questie (TrackerItemButton.lua:90), not the full
        -- link: the proven form on Forever. The link is kept in the plan for
        -- the data half's comparisons.
        b:SetAttribute("item1", p.item:match("item:%d+") or p.item)
        b.logIndex = p.logIndex
        b.icon:SetTexture(p.tex)
        Font(b.count, num(d.objectiveSize, 10))
        b.count:SetTextColor(1, 1, 1)
        if p.charges and p.charges > 1 then
            b.count:SetText(p.charges)
            b.count:Show()
        else
            b.count:Hide()
        end
        b:SetSize(size, size)
        b:ClearAllPoints()
        b:SetPoint("TOPRIGHT", child, "TOPRIGHT", 0, -p.y)
        UpdateCooldown(b)
        b:Show()
    end
    for i = #itemPlan + 1, #buttons do
        buttons[i].logIndex = nil
        buttons[i]:Hide()
    end
end

-- The pull (PLAYER_REGEN_DISABLED, QuestTracker.lua's host). The wheel moves
-- the scroll child the secure buttons hang on, which is a protected move in
-- combat; the redraw after combat turns it back on.
function M.EnterCombat()
    if frame and buttons[1] then scroll:EnableMouseWheel(false) end
end

-- ---------------------------------------------------------------------------
-- Timed quests (step 6c)
-- ---------------------------------------------------------------------------

local function TimeText(s)
    s = math.max(0, math.floor(s + 0.5))
    if s >= 3600 then
        return string.format("%d:%02d:%02d", math.floor(s / 3600), math.floor(s % 3600 / 60), s % 60)
    end
    return string.format("%d:%02d", math.floor(s / 60), s % 60)
end

local function TickTimers()
    for _, t in ipairs(timerRows) do
        t.fs:SetText("Time left: " .. TimeText(t.ends - GetTime()))
    end
end

-- Runs the 1 s ticker exactly while a timer row shows; it only writes the
-- rows' texts, never lays anything out. When a timer runs out the quest
-- fails, and QUEST_LOG_UPDATE redraws past the row.
local function SetTicker()
    if timerRows[1] then
        if not ticker then ticker = C_Timer.NewTicker(1, TickTimers) end
    elseif ticker then
        ticker:Cancel()
        ticker = nil
    end
end

-- ---------------------------------------------------------------------------
-- Order
-- ---------------------------------------------------------------------------

-- Watched quests in display order, grouped by zone: zones (in order) and
-- zone -> its quests. `guide` (questID -> step) or nil.
local function Ordered(guide)
    local d = DB()
    local watchIdx = {}
    for i = 1, C_QuestLog.GetNumQuestWatches() do
        local id = C_QuestLog.GetQuestIDForQuestWatchIndex(i)
        if id then watchIdx[id] = i end
    end
    local list = {}
    for _, q in ipairs(M.Quests()) do
        if q.watched then list[#list + 1] = q end
    end
    local LAST = math.huge
    table.sort(list, function(a, b)
        local ga, gb = guide and guide[a.id] or LAST, guide and guide[b.id] or LAST
        if ga ~= gb then return ga < gb end
        local wa, wb = watchIdx[a.id] or LAST, watchIdx[b.id] or LAST
        if wa ~= wb then return wa < wb end
        return a.logIndex < b.logIndex
    end)
    local zones, byZone = {}, {}
    for _, q in ipairs(list) do
        local z = q.zone or ""
        if not byZone[z] then
            byZone[z] = {}
            zones[#zones + 1] = z
        end
        local t = byZone[z]
        t[#t + 1] = q
    end
    if d.completed == "top" or d.completed == "bottom" then
        for _, z in ipairs(zones) do
            local done, open = {}, {}
            for _, q in ipairs(byZone[z]) do
                if q.complete then done[#done + 1] = q else open[#open + 1] = q end
            end
            local a, b = done, open
            if d.completed == "bottom" then a, b = open, done end
            for _, q in ipairs(b) do a[#a + 1] = q end
            byZone[z] = a
        end
    end
    return zones, byZone, #list
end

-- ---------------------------------------------------------------------------
-- Drawing
-- ---------------------------------------------------------------------------

-- Lays out one text row at y (from the top of the scroll child, going down)
-- and returns the y under it.
local function PlaceRow(r, y, x, w, text, size, cr, cg, cb)
    Font(r.text, size)
    r.text:SetTextColor(cr, cg, cb)
    r.text:ClearAllPoints()
    r.text:SetPoint("TOPLEFT", r, "TOPLEFT", 0, 0)
    r.text:SetWidth(w)
    r.text:SetText(text)
    local h = math.ceil(r.text:GetStringHeight())
    r:ClearAllPoints()
    r:SetPoint("TOPLEFT", child, "TOPLEFT", x, -y)
    r:SetSize(w, h)
    r:Show()
    return y + h
end

local function TitleText(q)
    return q.level and q.level > 0 and ("[" .. q.level .. "] " .. q.title) or tostring(q.title)
end

local function DrawRows(width, guide)
    local d = DB()
    local zones, byZone, shown = Ordered(guide)
    local titleSize, objSize = num(d.titleSize, 12), num(d.objectiveSize, 10)
    -- Title gutter: wide enough for the guide dot, which the scroll frame
    -- would otherwise clip at its left edge from Title Size 13 up.
    local dotSize = math.floor(titleSize * 0.6 + 0.5)
    -- Also room for the dot's outline and the Guide Highlight's border left of it.
    local gutter = math.max(INDENT, dotSize + 6)
    local here = d.currentZoneOnly and GetRealZoneText() or nil
    local u = ns.Ellesmere.PixelUnit(frame)
    local hr, hg, hb = ns.HexToRGB(d.highlightColor)
    local ha = num(d.highlightAlpha, 0.25)
    -- A fixed 1 px solid border in the chosen colour (built per draw, which
    -- runs on settings and quest changes, not per frame).
    local hlBorder = { style = "solid", size = 1, color = d.highlightBorderColor, alpha = num(d.highlightBorderAlpha, 1) }
    local itemSize = num(d.itemSize, 26)
    local qGap = num(d.questSpacing, 3)
    wipe(itemPlan)
    wipe(timerRows)
    wipe(drawn)
    local y, n = 0, 0
    local function nextRow()
        n = n + 1
        local r = Row(n)
        r.questID, r.zone = nil, nil
        r:SetScript("OnClick", nil)
        r:EnableMouse(false)
        r.dot:Hide()
        r.dotEdge:Hide()
        r.fold:Hide()
        r.hl:Hide()
        return r
    end
    for zi, z in ipairs(zones) do
        local quests = byZone[z]
        local open
        if d.currentZoneOnly and z ~= here then
            open = expanded[z] == true
        else
            open = not d.foldedZones[z]
        end
        if zi > 1 then y = y + 6 end
        local r = nextRow()
        local label = open and z or (z .. " (" .. #quests .. ")")
        y = PlaceRow(r, y, 0, width, label, titleSize, ZONE_R, ZONE_G, ZONE_B)
        r.zone = z
        r:EnableMouse(true)
        r:SetScript("OnClick", OnZoneClick)
        if open then
            for _, q in ipairs(quests) do
                y = y + qGap
                r = nextRow()
                local x, w = 0, width
                local inGuide = guide and guide[q.id]
                -- The quest's item button: its rows leave room at the right,
                -- and its placement is noted for LayoutItems. Shown while
                -- complete only if Blizzard says so (showWhenComplete, as
                -- Blizzard's tracker).
                local bw, blockTop = 0, y
                if d.itemButtons and q.item and (not q.complete or q.showWhenComplete) then
                    bw = itemSize + 6
                    itemPlan[#itemPlan + 1] = { y = y, item = q.item, tex = q.itemTexture,
                        charges = q.charges, logIndex = q.logIndex }
                end
                if d.rxpDot and inGuide then
                    -- The dot sits in a gutter of its own, so titles with and
                    -- without one line up after it.
                    r.dot:SetSize(dotSize, dotSize)
                    r.dot:ClearAllPoints()
                    r.dot:SetPoint("RIGHT", r, "TOPLEFT", -3, -math.floor(titleSize / 2))
                    r.dot:Show()
                    r.dotEdge:SetSize(dotSize + 2 * u, dotSize + 2 * u)
                    r.dotEdge:ClearAllPoints()
                    r.dotEdge:SetPoint("CENTER", r.dot, "CENTER")
                    r.dotEdge:Show()
                end
                -- The minimize click area fills the dot's slot on every
                -- quest: with the dot it is invisible and the dot itself
                -- takes the click; without it it shows "-" open, "+" folded.
                local f = r.fold
                -- Font first, also for the empty text: SetText on a
                -- FontString without a font is an error (DEVNOTES, dev13;
                -- his report on dev26 hit it right here).
                Font(f.txt, titleSize)
                if d.rxpDot and inGuide then
                    f.txt:SetText("")
                else
                    f.txt:SetTextColor(OBJ_R, OBJ_G, OBJ_B)
                    f.txt:SetText(d.folded[q.id] and "+" or "-")
                end
                f:SetSize(dotSize + 6, titleSize + 4)
                f:ClearAllPoints()
                f:SetPoint("RIGHT", r, "TOPLEFT", -1, -math.floor(titleSize / 2))
                f:Show()
                if d.rxpHighlight and inGuide then
                    -- A box across the whole width of the list, from its left
                    -- edge (the row itself starts after the gutter), its
                    -- 1 px edge inside that width.
                    r.hl.bg:SetColorTexture(hr, hg, hb, ha)
                    r.hl:ClearAllPoints()
                    r.hl:SetPoint("TOPLEFT", r, "TOPLEFT", -gutter, 1)
                    r.hl:SetPoint("BOTTOMRIGHT", r, "BOTTOMRIGHT", 0, -1)
                    r.hl:Show()
                    ns.Border.Apply(r.hl, hlBorder)
                end
                local c = GetQuestDifficultyColor(q.level or 0)
                y = PlaceRow(r, y, x + gutter, w - gutter - bw, TitleText(q), titleSize, c.r, c.g, c.b)
                if bw > 0 then
                    -- The button is taller than the text row: the title (and
                    -- the highlight, dot and icon on it) is centred against
                    -- the button instead of hanging at its top (his ask
                    -- 2026-10-09, screenshot).
                    local pre = math.floor((itemSize - (y - blockTop)) / 2)
                    if pre > 0 then
                        r:ClearAllPoints()
                        r:SetPoint("TOPLEFT", child, "TOPLEFT", x + gutter, -(blockTop + pre))
                        y = y + pre
                    end
                end
                r.questID = q.id
                local entry = { id = q.id, row = r, last = r, title = r.text, r = c.r, g = c.g, b = c.b, gutter = gutter }
                drawn[#drawn + 1] = entry
                r:EnableMouse(true)
                r:SetScript("OnClick", OnQuestClick)
                -- not folded: a folded quest shows only its title, and a
                -- right-click opens it again.
                if not d.folded[q.id] then
                    if q.timerEnds then
                        -- The ticker rewrites this text once a second;
                        -- timerRows keeps its FontString and end time.
                        local tr = nextRow()
                        y = PlaceRow(tr, y + 1, gutter + INDENT, width - gutter - INDENT - bw,
                            "Time left: " .. TimeText(q.timerEnds - GetTime()), objSize, OBJ_R, OBJ_G, OBJ_B)
                        timerRows[#timerRows + 1] = { fs = tr.text, ends = q.timerEnds }
                    end
                    if q.failed then
                        y = PlaceRow(nextRow(), y + 1, gutter + INDENT, width - gutter - INDENT - bw, "Failed", objSize, FAIL_R, FAIL_G, FAIL_B)
                    elseif q.complete then
                        y = PlaceRow(nextRow(), y + 1, gutter + INDENT, width - gutter - INDENT - bw, "Ready to turn in", objSize, DONE_R, DONE_G, DONE_B)
                    else
                        for _, o in ipairs(q.objectives) do
                            local cr, cg, cb = OBJ_R, OBJ_G, OBJ_B
                            if o.finished then cr, cg, cb = DONE_R, DONE_G, DONE_B end
                            y = PlaceRow(nextRow(), y + 1, gutter + INDENT, width - gutter - INDENT - bw, o.text, objSize, cr, cg, cb)
                        end
                    end
                end
                -- A short quest block must not end above its button's bottom,
                -- or the button lies over the next quest's full-width rows.
                if bw > 0 and y < blockTop + itemSize then y = blockTop + itemSize end
                entry.last = rows[n]
            end
        end
    end
    -- The highlight box is not a child of its row, so it is hidden with it here.
    for i = n + 1, #rows do rows[i]:Hide(); rows[i].hl:Hide() end
    return y, shown
end

-- The progress row under the header: guide name, percent, a thin bar.
-- Returns its height, 0 when hidden.
local function DrawProgress(width, top)
    local d = DB()
    local name, step, total
    if d.rxpProgress then name, step, total = ns.RXP.GuideProgress() end
    if not name then
        progress:Hide()
        return 0
    end
    local size = num(d.objectiveSize, 10)
    Font(progress.name, size)
    Font(progress.pct, size)
    progress.name:SetTextColor(OBJ_R, OBJ_G, OBJ_B)
    progress.pct:SetTextColor(OBJ_R, OBJ_G, OBJ_B)
    local pct = math.floor(step / total * 100 + 0.5)
    progress.pct:SetText(pct .. "%")
    progress.name:SetText(name)
    progress.name:SetPoint("RIGHT", progress.pct, "LEFT", -6, 0)
    local textH = math.ceil(math.max(progress.name:GetStringHeight(), progress.pct:GetStringHeight()))
    local u = ns.Ellesmere.PixelUnit(frame)
    local barH = 3 * u
    local barW = width - 2 * u      -- inside the 1 px edge
    progress.track:ClearAllPoints()
    progress.track:SetPoint("TOPLEFT", progress, "TOPLEFT", u, -(textH + 3 + u))
    progress.track:SetSize(barW, barH)
    progress.fill:ClearAllPoints()
    progress.fill:SetPoint("TOPLEFT", progress.track, "TOPLEFT")
    progress.fill:SetSize(math.max(u, barW * step / total), barH)
    -- Ellesmere's solid border lies inside its frame: the box is the track
    -- grown by one pixel all round.
    progress.box:ClearAllPoints()
    progress.box:SetPoint("TOPLEFT", progress.track, "TOPLEFT", -u, u)
    progress.box:SetPoint("BOTTOMRIGHT", progress.track, "BOTTOMRIGHT", u, -u)
    ns.Border.Apply(progress.box, { style = "solid", size = 1,
        color = d.progressBorderColor, alpha = num(d.progressBorderAlpha, 1) })
    local h = textH + 3 + barH + 2 * u
    progress:ClearAllPoints()
    progress:SetPoint("TOPLEFT", frame, "TOPLEFT", num(d.padding, 8), -top)
    progress:SetSize(width, h)
    progress:Show()
    return h
end

function M.Draw()
    if not ns.IsModuleEnabled("questTracker") then return end
    -- With a secure item button in the pool the whole tracker is frozen in
    -- combat: the buttons cannot be moved or hidden then, and the frames
    -- they hang on (child, scroll, frame) are protected with them. The data
    -- half queues a forced redraw on PLAYER_REGEN_ENABLED, which lands here
    -- after the lockdown has lifted. Without buttons (Quest Item Buttons
    -- never on, no quest item) the tracker keeps updating in combat as in 6b.
    if buttons[1] and InCombatLockdown() then return end
    EnsureFrame()
    local d = DB()
    local pad = num(d.padding, 8)
    local W = math.max(120, num(d.width, 260))
    local inner = W - pad * 2
    local unlocked = d.unlocked == true

    -- Header.
    local hs = num(d.headerSize, 13)
    Font(header.title, hs)
    Font(header.count, hs)
    header.title:SetTextColor(1, 1, 1)
    header.title:SetText("Quests")      -- after SetFont: SetText without a font is an error
    header.count:SetTextColor(OBJ_R, OBJ_G, OBJ_B)
    local inLog = #M.Quests()
    if unlocked then
        header.count:SetText("Drag to move")
    else
        header.count:SetText(inLog .. "/" .. C_QuestLog.GetMaxNumQuestsCanAccept())
    end
    -- Header Height: 0 follows the text; a set height never cuts the text.
    local textH = math.ceil(header.title:GetStringHeight())
    local hh = num(d.headerHeight, 0)
    if hh <= 0 then hh = textH + 6 end
    hh = math.max(hh, textH)
    header:ClearAllPoints()
    header:SetPoint("TOPLEFT", frame, "TOPLEFT", pad, -pad)
    header:SetSize(inner, hh)

    -- The guide decides the order whether or not its dot is shown.
    local guide = ns.RXP.GuideQuests()
    local top = pad + hh
    local height, shown
    -- Header Seam, only while open: the line sits 3 px under the header
    -- and the content moves down by as much again.
    -- The gap is added only when Seam drew a line (border size 0 or a
    -- texture without seam art draws none).
    local seamDrawn = false
    local seamAt = ns.Border.Snap(top + 3, ns.Ellesmere.PixelUnit(frame))
    -- Seam runs folded too (its frame then hidden), so the folded height and
    -- the header background know whether a line would be drawn.
    if d.headerSeam then
        frame.seam:ClearAllPoints()
        frame.seam:SetPoint("TOPLEFT", frame, "TOPLEFT", 0, -seamAt)
        frame.seam:SetPoint("TOPRIGHT", frame, "TOPRIGHT", 0, -seamAt)
        frame.seam:SetHeight(1)
        frame.seam:Show()
        seamDrawn = ns.Border.Seam(frame.seam.tex, frame.seam, d.border) == true
        if seamDrawn and not d.collapsed then top = seamAt + 3 end
    end
    if not seamDrawn or d.collapsed then frame.seam:Hide() end
    -- With the seam the header is the box from the frame's top edge to the
    -- seam line, so its text is centred in that box, not in the header row.
    -- The whole box, not the box minus the border: the top border and the
    -- seam are the same style and size, so the middle is the same, and a
    -- textured border's Size is not its drawn thickness (FIELD RESULT
    -- 2026-10-09 (build 70291): subtracting Size shrank the header to almost
    -- nothing at a 16 px textured border, so it could not be clicked).
    if seamDrawn then
        header:ClearAllPoints()
        header:SetPoint("TOPLEFT", frame, "TOPLEFT", pad, 0)
        header:SetSize(inner, seamAt)
    end
    if d.collapsed then
        progress:Hide()
        scroll:Hide()       -- hides the item buttons with the scroll child
        for _, r in ipairs(rows) do r:Hide(); r.hl:Hide() end
        wipe(timerRows)
        wipe(drawn)     -- no visible rows for the ticker to write to
        shown = select(3, Ordered(guide))
        -- With Header Seam the folded frame's bottom edge lies where the
        -- seam line lies when open (a solid seam sits just above seamAt,
        -- the frame's own border just inside its bottom), so the header
        -- box looks the same folded and open.
        height = seamDrawn and seamAt or (top + pad)
    else
        local ph = DrawProgress(inner, top + 4)
        if ph > 0 then top = top + 4 + ph end
        child:SetWidth(inner)
        local contentH
        contentH, shown = DrawRows(inner, guide)
        child:SetHeight(math.max(1, contentH))
        LayoutItems()
        local room = math.max(40, num(d.maxHeight, 520) - top - 6 - pad)
        local visible = math.min(contentH, room)
        scroll:ClearAllPoints()
        scroll:SetPoint("TOPLEFT", frame, "TOPLEFT", pad, -(top + 6))
        scroll:SetSize(inner, math.max(1, visible))
        scroll:EnableMouseWheel(contentH > visible)
        scroll:SetVerticalScroll(math.min(scroll:GetVerticalScroll(), math.max(0, contentH - visible)))
        scroll:SetShown(contentH > 0)
        if d.fixedHeight then
            height = top + 6 + room + pad       -- Max Height, or more if the 40 floor for the list applies
        else
            height = top + (contentH > 0 and (6 + visible) or 0) + pad
        end
    end

    -- Background and border on whole pixels (an edge on half a pixel draws
    -- the border blurred, DEVNOTES "Kärnan").
    ns.Ellesmere.PixelSize(frame, W, height)
    frame:ClearAllPoints()
    ns.Ellesmere.PixelPoint(frame, "TOPRIGHT", UIParent, "TOPRIGHT", num(d.x, -40), num(d.y, -260))
    local r, g, b = ns.HexToRGB(d.bgColor)
    frame.bg:SetColorTexture(r, g, b, num(d.bgAlpha, 0.75))
    -- Header Background: only with Header Seam, from the top to the seam
    -- line; the frame's background then starts at the line. Without the
    -- seam the frame's background covers the header too.
    frame.bg:ClearAllPoints()
    frame.bg:SetPoint("BOTTOMLEFT")
    frame.bg:SetPoint("BOTTOMRIGHT")
    if seamDrawn then
        -- Unset: the tracker's Background, so turning Header Seam on alone
        -- changes no colour.
        local hr, hg, hb = ns.HexToRGB(d.headerColor or d.bgColor)
        frame.headerBg:SetColorTexture(hr, hg, hb, num(d.headerAlpha, num(d.bgAlpha, 0.75)))
        frame.headerBg:ClearAllPoints()
        frame.headerBg:SetPoint("TOPLEFT")
        frame.headerBg:SetPoint("TOPRIGHT")
        frame.headerBg:SetHeight(math.min(seamAt, height))
        frame.headerBg:Show()
        frame.bg:SetPoint("TOP", frame, "TOP", 0, -math.min(seamAt, height))
    else
        frame.headerBg:Hide()
        frame.bg:SetPoint("TOP")
    end
    ns.Border.Apply(frame, d.border)
    frame:EnableMouse(unlocked)
    -- Nothing watched: no frame, unless it is being placed.
    frame:SetShown(shown > 0 or unlocked or unlockActive)
    SetTicker()
    FireDrawn()
end

function M.HideFrame()
    if not frame then return end
    if buttons[1] and InCombatLockdown() then
        -- The module was switched off in combat: hiding the frame would
        -- hide its secure buttons, a protected operation. One shot at
        -- regen; a draw queued by a re-enable runs on the frame after it
        -- (C_Timer.After in QuestTracker.lua), so it shows again last.
        frame:RegisterEvent("PLAYER_REGEN_ENABLED")
        frame:SetScript("OnEvent", function(f)
            f:UnregisterEvent("PLAYER_REGEN_ENABLED")
            f:SetScript("OnEvent", nil)
            M.HideFrame()
        end)
        return
    end
    wipe(timerRows)
    SetTicker()
    frame:Hide()
    frame:EnableMouse(false)
    wipe(drawn)
    FireDrawn()
end

-- ---------------------------------------------------------------------------
-- "Quest Completed" in the middle of the screen
-- ---------------------------------------------------------------------------

local done

local function BuildCompleted()
    if not done then
        done = CreateFrame("Frame", "WarUIQuestCompletedFrame", UIParent)
        done:SetFrameStrata("HIGH")
        done:SetSize(600, 80)
        M.PlaceCompleted()
        done.big = done:CreateFontString(nil, "OVERLAY")
        done.big:SetPoint("TOP")
        done.small = done:CreateFontString(nil, "OVERLAY")
        done.small:SetPoint("TOP", done.big, "BOTTOM", 0, -4)
        done.anim = done:CreateAnimationGroup()
        local fade = done.anim:CreateAnimation("Alpha")
        fade:SetFromAlpha(1)
        fade:SetToAlpha(0)
        fade:SetStartDelay(2.5)
        fade:SetDuration(1.5)
        done.anim:SetScript("OnFinished", function() done:Hide() end)
        done:Hide()
    end
    return done
end

function M.ShowCompleted(title)
    if not DB().completedText then return end
    BuildCompleted()
    Font(done.big, 28)
    Font(done.small, 16)
    done.big:SetTextColor(1, 0.82, 0)
    done.small:SetTextColor(1, 1, 1)
    done.big:SetText("Quest Completed")
    done.small:SetText(title or "")
    done.anim:Stop()
    done:SetAlpha(1)
    done:Show()
    done.anim:Play()
end

-- ---------------------------------------------------------------------------
-- EllesmereUI Unlock Mode (War UI v1.1.0): the tracker and the "Quest
-- Completed" text get a mover each, folder "WarUI_General".
-- ---------------------------------------------------------------------------
-- Unlock Mode stores CENTER/CENTER offsets (EUI_UnlockMode_Positions.lua
-- UM.SaveBarPosition -> ConvertToCenterPos). The tracker keeps its own
-- TOPRIGHT offsets (d.x, d.y) so it still grows downward from its top edge
-- when quests come and go; the conversion goes both ways here.
-- ownsPosition: EUI never places the frame itself, it calls applyPosition.

-- v1.1.1: EllesmereUI calls these callbacks at PLAYER_LOGIN, possibly before
-- WarUI_General has loaded its profile (ns.db nil). An error in getFrame is
-- not pcall'd there and aborted Ellesmere's whole position pass (Unit Frames
-- among the victims), so every callback works without ns.db.
local function Ready() return ns.db ~= nil and ns.db.modules ~= nil and ns.db.modules.questTracker ~= nil end
local function Off() return not Ready() or not ns.IsModuleEnabled("questTracker") end

function M.PlaceCompleted()
    if not done then return end
    local p = Ready() and DB().completedPos or nil
    done:ClearAllPoints()
    if p and p.point then
        done:SetPoint(p.point, UIParent, p.relPoint or p.point, p.x or 0, p.y or 0)
    else
        done:SetPoint("CENTER", UIParent, "CENTER", 0, 220)
    end
end

local function EnsureCompleted()
    if not done then
        BuildCompleted()
        M.PlaceCompleted()
    end
    return done
end

local function TrackerCenter()
    if not Ready() then return nil end
    EnsureFrame()
    local d = DB()
    local w, h = frame:GetWidth() or 0, frame:GetHeight() or 0
    return {
        point = "CENTER", relPoint = "CENTER",
        x = num(d.x, -40) - w / 2 + UIParent:GetWidth() / 2,
        y = num(d.y, -260) - h / 2 + UIParent:GetHeight() / 2,
    }
end

local function SaveTracker(_, point, relPoint, x, y)
    if not Ready() then return end
    EnsureFrame()
    local d = DB()
    local w, h = frame:GetWidth() or 0, frame:GetHeight() or 0
    if point == "CENTER" and (relPoint or "CENTER") == "CENTER" then
        d.x = math.floor(x + w / 2 - UIParent:GetWidth() / 2 + 0.5)
        d.y = math.floor(y + h / 2 - UIParent:GetHeight() / 2 + 0.5)
    elseif frame:GetRight() then
        -- Not converted by EUI: read where the mover left the frame.
        local s = frame:GetEffectiveScale() / UIParent:GetEffectiveScale()
        d.x = math.floor(frame:GetRight() * s - UIParent:GetWidth() + 0.5)
        d.y = math.floor(frame:GetTop() * s - UIParent:GetHeight() + 0.5)
    end
    pcall(ns.Ellesmere.RefreshPage)
end

local function ShowCompletedPreview(on)
    if on then
        if Off() or not DB().completedText then return end
        EnsureCompleted()
        Font(done.big, 28)
        Font(done.small, 16)
        done.big:SetTextColor(1, 0.82, 0)
        done.small:SetTextColor(1, 1, 1)
        done.anim:Stop()
        done.big:SetText("Quest Completed")
        done.small:SetText("Example Quest")
        done:SetAlpha(1)
        M.PlaceCompleted()
        done:Show()
    elseif done then
        done.anim:Stop()
        done:Hide()
    end
end

local unlockRegistered = false
function M.RegisterUnlock()
    if unlockRegistered or not (EllesmereUI and EllesmereUI.RegisterUnlockElements) then return end
    unlockRegistered = true
    local off = Off
    EllesmereUI:RegisterUnlockElements({
        {
            key = "WarUI_QuestTracker", label = "Quest Tracker",
            ownsPosition = true,
            getFrame = function() EnsureFrame(); return frame end,
            getSize = function() EnsureFrame(); return frame:GetWidth(), frame:GetHeight() end,
            isHidden = off,
            savePosition = SaveTracker,
            loadPosition = function() return TrackerCenter() end,
            clearPosition = function() if Ready() then DB().x, DB().y = -40, -260 end end,
            applyPosition = function() if not off() then M.Draw() end end,
        },
        {
            key = "WarUI_QuestCompleted", label = "Quest Completed Text",
            getFrame = function() return EnsureCompleted() end,
            getSize = function() local f = EnsureCompleted(); return f:GetWidth(), f:GetHeight() end,
            isHidden = function() return off() or not DB().completedText end,
            savePosition = function(_, point, relPoint, x, y)
                if not Ready() then return end
                DB().completedPos = { point = point, relPoint = relPoint or point, x = x, y = y }
            end,
            loadPosition = function() return Ready() and DB().completedPos or nil end,
            clearPosition = function() if Ready() then DB().completedPos = nil end end,
            applyPosition = function() M.PlaceCompleted() end,
        },
    }, "WarUI_General")
    if EllesmereUI.RegisterUnlockModeListener then
        EllesmereUI:RegisterUnlockModeListener("WarUI_QuestTracker", function(active)
            unlockActive = active and true or false
            if not off() then M.Draw() end
            ShowCompletedPreview(unlockActive)
        end)
    end
end

function M.OpenUnlock()
    if InCombatLockdown() then ns.Print("Quest Tracker: not in combat.") return end
    if EllesmereUI and EllesmereUI.OpenUnlockMode then
        if EllesmereUI.IsShown and EllesmereUI:IsShown() then pcall(EllesmereUI.Hide, EllesmereUI) end
        pcall(EllesmereUI.OpenUnlockMode, EllesmereUI)
    end
end

-- ---------------------------------------------------------------------------
-- Settings page
-- ---------------------------------------------------------------------------

local function SliderCell(text, tip, key, minV, maxV, fallback, changed)
    return { type = "slider", text = text, min = minV, max = maxV, step = 1, tooltip = tip,
        getValue = function() return num(DB()[key], fallback) end,
        setValue = function(v) DB()[key] = v; changed() end }
end

local function ColorCell(text, tip, colorKey, alphaKey, fallbackAlpha, changed)
    return { type = "colorpicker", text = text, tooltip = tip, hasAlpha = true,
        getValue = function()
            local r, g, b = ns.HexToRGB(DB()[colorKey])
            return r, g, b, num(DB()[alphaKey], fallbackAlpha)
        end,
        setValue = function(r, g, b, a)
            DB()[colorKey] = ns.RGBToHex(r, g, b)
            DB()[alphaKey] = a or 1
            changed()
        end }
end

local OUTLINE_VALUES = { ellesmere = "Ellesmere's outline", none = "None", OUTLINE = "Outline", THICKOUTLINE = "Thick Outline" }
local OUTLINE_ORDER = { "ellesmere", "none", "OUTLINE", "THICKOUTLINE" }

local function ToggleCell(text, tip, key, changed)
    return { type = "toggle", text = text, tooltip = tip,
        getValue = function() return DB()[key] == true end,
        setValue = function(v) DB()[key] = v and true or false; changed() end }
end

function M:BuildPage(_, parent, y, W)
    local _, h
    local function changed() ns.Apply() end
    local E = ns.Ellesmere

    if not E.QuestTrackerLoaded() then
        _, h = W:DualRow(parent, y,
            { type = "label", text = "Ellesmere's Quest Tracker is not loaded, so Blizzard's tracker is still shown. Turn Ellesmere's Quest Tracker on, or another addon has to hide Blizzard's tracker: War UI does not, since hiding it from addon code can taint it." }); y = y - h
    end

    _, h = W:SectionHeader(parent, "TRACKER", y); y = y - h
    _, h = W:DualRow(parent, y,
        ToggleCell("Unlock (drag with the mouse)", "While unlocked the tracker can be dragged by its header, and is shown even with nothing tracked.", "unlocked", changed),
        SliderCell("Width", "Width of the tracker.", "width", 160, 480, 260, changed)); y = y - h
    _, h = W:DualRow(parent, y,
        { type = "button", text = "Move (Unlock Mode)", width = 180,
          disabled = function() return not ns.IsModuleEnabled("questTracker") end,
          disabledTooltip = "Turn Quest Tracker on first",
          onClick = function() M.OpenUnlock() end },
        { type = "label", text = "Moves the tracker and the Quest Completed text in Ellesmere's Unlock Mode (folder War UI General)." }); y = y - h
    _, h = W:DualRow(parent, y,
        SliderCell("Max Height", "The tracker grows with its quests up to this height; past it, scroll with the mouse wheel.", "maxHeight", 150, 1000, 520, changed),
        SliderCell("Padding", "Pixels between the tracker's edge and its text.", "padding", 0, 24, 8, changed)); y = y - h
    _, h = W:DualRow(parent, y,
        ToggleCell("Always Max Height", "The tracker is always Max Height tall, however few quests it holds. Collapsing it with a header click still folds it to the header.", "fixedHeight", changed),
        SliderCell("Header Height", "Height of the \"Quests\" header; its text stays centred. 0 follows the text size.", "headerHeight", 0, 60, 0, changed)); y = y - h
    local headerBg = ColorCell("Header Background", "Background of the header above the Header Seam line. Without Header Seam the header has the tracker's Background.", "headerColor", "headerAlpha", 0.75, changed)
    local getHeaderBg = headerBg.getValue
    headerBg.getValue = function()
        if DB().headerColor then return getHeaderBg() end
        local r, g, b = ns.HexToRGB(DB().bgColor)
        return r, g, b, num(DB().bgAlpha, 0.75)
    end
    headerBg.disabled = function() return not DB().headerSeam end
    headerBg.disabledTooltip = "Turn Header Seam on first"
    _, h = W:DualRow(parent, y,
        ToggleCell("Alt-Click Abandons", "Alt-click a quest title to abandon the quest.", "altAbandon", function()
            changed()
            ns.Ellesmere.RefreshPage()      -- grey Abandon Warning in or out
        end),
        headerBg); y = y - h
    local warn = ToggleCell("Abandon Warning", "Ask before an alt-click abandons a quest. Off: the quest is abandoned at once.", "abandonConfirm", changed)
    warn.disabled = function() return not DB().altAbandon end
    warn.disabledTooltip = "Turn Alt-Click Abandons on first"
    _, h = W:DualRow(parent, y,
        warn,
        SliderCell("Quest Spacing", "Pixels between the quests in the list.", "questSpacing", 0, 20, 3, changed)); y = y - h
    local itemSize = SliderCell("Item Button Size", "Size of the quest item buttons.", "itemSize", 18, 40, 26, changed)
    itemSize.disabled = function() return not DB().itemButtons end
    itemSize.disabledTooltip = "Turn Quest Item Buttons on first"
    _, h = W:DualRow(parent, y,
        ToggleCell("Quest Item Buttons", "The quest's usable item as a clickable button at the quest's right edge. While any quest has one, the tracker waits out combat before it redraws.", "itemButtons", function()
            changed()
            ns.Ellesmere.RefreshPage()      -- grey Item Button Size in or out
        end),
        itemSize); y = y - h
    _, h = W:DualRow(parent, y,
        { type = "colorpicker", text = "Background", hasAlpha = true,
          getValue = function()
              local r, g, b = ns.HexToRGB(DB().bgColor)
              return r, g, b, num(DB().bgAlpha, 0.75)
          end,
          setValue = function(r, g, b, a)
              DB().bgColor = ns.RGBToHex(r, g, b)
              DB().bgAlpha = a or 1
              changed()
          end },
        ToggleCell("Header Seam", "A line of the tracker's border under the header, edge to edge. The header above it gets Header Background.", "headerSeam", function()
            changed()
            ns.Ellesmere.RefreshPage()      -- grey Header Background in or out
        end)); y = y - h

    _, h = W:SectionHeader(parent, "TEXT", y); y = y - h
    local fonts, fontOrder = ns.Media.FontList()
    _, h = W:DualRow(parent, y,
        { type = "dropdown", text = "Font", values = fonts, order = fontOrder,
          tooltip = "Every text in the tracker and the Quest Completed text.",
          getValue = function() return DB().font end,
          setValue = function(v) DB().font = v; changed() end },
        { type = "dropdown", text = "Outline", values = OUTLINE_VALUES, order = OUTLINE_ORDER,
          tooltip = "Every text in the tracker and the Quest Completed text.",
          getValue = function() return DB().outline end,
          setValue = function(v) DB().outline = v; changed() end }); y = y - h
    _, h = W:DualRow(parent, y,
        SliderCell("Header Size", "Font size of the \"Quests\" header.", "headerSize", 8, 24, 13, changed),
        SliderCell("Title Size", "Font size of zone names and quest titles.", "titleSize", 8, 20, 12, changed)); y = y - h
    _, h = W:DualRow(parent, y,
        SliderCell("Objective Size", "Font size of objectives and the guide progress.", "objectiveSize", 8, 18, 10, changed),
        ToggleCell("Text Shadow", "A black shadow under every text in the tracker.", "shadow", changed)); y = y - h

    _, h = W:SectionHeader(parent, "ORDER", y); y = y - h
    _, h = W:DualRow(parent, y,
        { type = "dropdown", text = "Completed Quests",
          values = { top = "Top of the zone", bottom = "Bottom of the zone", inorder = "In order" },
          order = { "top", "bottom", "inorder" },
          tooltip = "Where quests that are ready to turn in go within their zone.",
          getValue = function() return DB().completed end,
          setValue = function(v) DB().completed = v; changed() end },
        ToggleCell("Current Zone Only", "Other zones are folded to one line with their number of quests; click one to open it.", "currentZoneOnly", changed)); y = y - h

    _, h = W:SectionHeader(parent, "RESTEDXP", y); y = y - h
    _, h = W:DualRow(parent, y,
        ToggleCell("Guide Dot", "A small blue dot before quests the loaded RestedXP guide names.", "rxpDot", changed),
        ToggleCell("Guide Progress", "The loaded guide's name and progress (current step of all steps) under the header.", "rxpProgress", changed)); y = y - h
    _, h = W:DualRow(parent, y,
        ToggleCell("Guide Highlight", "A box across the tracker behind the titles of quests the loaded guide names. Works together with the dot.", "rxpHighlight", changed),
        ColorCell("Progress Bar Border", "Colour of the progress bar's 1 px border.", "progressBorderColor", "progressBorderAlpha", 1, changed)); y = y - h
    _, h = W:DualRow(parent, y,
        ColorCell("Highlight", "Colour and opacity of the Guide Highlight box.", "highlightColor", "highlightAlpha", 0.25, changed),
        ColorCell("Highlight Border", "Colour of the Guide Highlight box's 1 px border.", "highlightBorderColor", "highlightBorderAlpha", 1, changed)); y = y - h
    if not ns.RXP.IsLoaded() then
        _, h = W:DualRow(parent, y,
            { type = "label", text = "RestedXP Guides is not loaded: the tracker keeps Blizzard's order and shows no dot, highlight or progress." }); y = y - h
    end

    _, h = W:SectionHeader(parent, "QUEST COMPLETED", y); y = y - h
    _, h = W:DualRow(parent, y,
        ToggleCell("Quest Completed Text", "\"Quest Completed\" in large text in the middle of the screen when a quest's objectives are all done. Fades out after a few seconds.", "completedText", changed),
        { type = "button", text = "Show Example", width = 160,
          disabled = function() return not ns.IsModuleEnabled("questTracker") or not DB().completedText end,
          disabledTooltip = "Turn Quest Tracker and Quest Completed Text on first",
          onClick = function() M.ShowCompleted("Example Quest") end }); y = y - h

    _, h = W:SectionHeader(parent, "BORDER", y); y = y - h
    y = ns.Border.Rows(W, parent, y, function() return DB().border end, changed)

    _, h = W:SectionHeader(parent, "OTHER TRACKERS", y); y = y - h
    local names = {}
    for _, o in ipairs(M.OWNED) do names[#names + 1] = o.label end
    _, h = W:DualRow(parent, y,
        { type = "button", text = "Set Values Again", width = 180,
          disabled = function() return not ns.IsModuleEnabled("questTracker") end,
          disabledTooltip = "Turn Quest Tracker on first",
          onClick = function()
              E.Confirm({
                  title = "Quest Tracker: hide the other trackers",
                  message = "Set these again, so only War UI's tracker shows?\n- " .. table.concat(names, "\n- "),
                  confirmText = "Set and reload",
                  reload = true,
                  onConfirm = M.WriteOwned,
              })
          end },
        { type = "label", text = "Use it if you changed them in Ellesmere's or Questie's options." }); y = y - h

    if not ns.IsModuleEnabled("questTracker") then
        _, h = W:DualRow(parent, y,
            { type = "label", text = "Quest Tracker is off: turn it on at the top of this page." }); y = y - h
    end
    return y
end

-- Movers in EllesmereUI Unlock Mode (EllesmereUI is a dependency, so it is loaded).
M.RegisterUnlock()
