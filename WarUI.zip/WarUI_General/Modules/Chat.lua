-- ProseccoUI / Modules / Chat.lua
-- Presentation around Ellesmere's chat (design §11 decision 1, step A): a
-- panel of ours around the chat text and one around the tab row, each with
-- its own background and our border, and an adjustable gap between them.
-- Ellesmere keeps every chat function: its message frame, tabs, edit box,
-- sidebar and fade are not touched.
--
-- Placement. Every frame Ellesmere draws for the chat is anonymous (Known:
-- EllesmereUIChat.lua:4465 panel, EllesmereUIChat_Tabs.lua:122 tab strip), so
-- our panels are placed by Blizzard's named frames: ChatFrame1 is the chat's
-- text rect, and GeneralDockManager is Blizzard's (invisible) tab row, which
-- Ellesmere's tab strip mirrors and its tabs stand on (Tabs.lua:596-608,
-- :729-731). Blizzard pins the tab row above ChatFrame1 once, when
-- ChatFrame1 loads (Known: wow-ui-source FloatingChatFrame.lua:199, :1898-1901
-- FCFDock_SetPrimary; on Forever off ChatFrame1Background, see DockAnchor),
-- and nothing in Ellesmere moves it (Known: no SetPoint on it in
-- EllesmereUIChat 9.4). Tab Gap writes the same two anchors with another
-- offset; the anchor target stays Blizzard's, so the row stays in
-- Blizzard's own anchor chain. Never in combat: a docked whisper tab is
-- protected then (Known: EllesmereUIChat_Tabs.lua:843-846), and moving its
-- parent row would be blocked.
--
-- Rules from ProseccoTools (DEVNOTES "Chatten"): nothing is written to
-- ChatFrame1's position or size, no Ellesmere function is replaced or
-- hooked, and nothing of ours is put on a Blizzard chat frame.
--
-- Owned Ellesmere settings (decision 4, design §8 "Chatten äger tre
-- nycklar"): Background Opacity 0 and Hide Borders on, because our panels
-- replace them, tab backgrounds at opacity 0 and no line under the selected
-- tab (Alexander's choice: the tabs stand on our tab panel), and Tabs Inside
-- Chat Panel off, because with it on the tabs
-- sit in Ellesmere's panel and do not follow the tab row (ProseccoTools
-- Failed-approach dev137). Written when the module is switched on (after the
-- popup) or with "Set Ellesmere Values"; the values from before are given
-- back when it goes off. Never rewritten at login.
--
-- Typing (decision 1, alternative a): while an edit box is shown it is put
-- over the tab panel, on a cover of ours that hides the tabs, and the cover
-- goes when the box hides. Blizzard says when, through EventRegistry's
-- ChatFrame.OnEditBoxShow/Hide: never a script hook on the edit box, which
-- taints the chat type every send reads back (Known: EllesmereUIChat.lua:
-- 4088-4116, the reason Ellesmere uses the same callbacks). A session ends
-- only when the box hides (ProseccoTools lesson). Made for Blizzard's Chat
-- Style "Classic", where the box hides when you stop typing; with "IM
-- Style" the box is always shown, so the tabs stay covered.
--
-- Off: no frames, no events. Turning it off hides our panels and puts the
-- tab row and the edit boxes back without a reload; Ellesmere's own background and borders come
-- back after the /reload the popup asks for.

-- War UI: this module runs on the shared core in WarUI_General.
local ns = WarUIGeneral

local OWNED = {
    { target = "chat", key = "bgAlpha",            value = 0,     label = "Chat: Background Opacity" },
    { target = "chat", key = "hideBorders",        value = true,  label = "Chat: Hide Borders" },
    { target = "chat", key = "extendBgBehindTabs", value = false, label = "Chat: Tabs Inside Chat Panel" },
    -- Alexander 2026-10-08: the tabs stand on our tab panel with no background
    -- or line of their own (Known: read by Tabs.lua:429-457 StyleGhost).
    { target = "chat", key = "tabBackgroundColor.a",       value = 0,     label = "Chat: Tab Background opacity" },
    { target = "chat", key = "tabBackgroundColorActive.a", value = 0,     label = "Chat: Active Tab Background opacity" },
    { target = "chat", key = "activeUnderline",            value = false, label = "Chat: Active Tab Underline" },
}

local M = ns.RegisterModule("chat", {
    title       = "Chat",
    description = "Panels around Ellesmere's chat and its tabs, with an adjustable gap between them.",
    pages       = { "Chat" },
    defaults    = {
        enabled = true,     -- War UI 2.4: on by default
        -- Ellesmere's own chat background (bgR/G/B 0.03/0.045/0.05, bgAlpha 0.65,
        -- EllesmereUIChat.lua:66-69), so the chat looks as dark as before.
        chatColor = "080B0D", chatAlpha = 0.65,
        tabsColor = "080B0D", tabsAlpha = 0.65,
        editColor = "080B0D",                    -- the cover over the tabs while typing; always opaque
        -- Ellesmere stretches the first tab 10 UI units left of the text
        -- (Tabs.lua:629-653); 11 px holds it inside the tab panel
        -- (Alexander, 2026-10-08, build 70245).
        padding = 11,               -- px our chat panel reaches past the text on the sides and below
        topPadding = 0,             -- px it reaches above the text
        tabGap = 8,                 -- px between the chat panel and the tab panel
        seam = false,               -- one border round both panels, a seam line where they meet
        border = { useGlobal = true, style = "solid", size = 1, color = "000000", alpha = 1 },
    },
    affects     = {
        "Ellesmere's chat Background Opacity and both tab background opacities are set to 0, Hide Borders is turned on, and Tabs Inside Chat Panel and the active tab underline are turned off; War UI draws its own panels.",
        "Blizzard's tab row above the chat is moved by the Tab Gap setting.",
        "While you type, the chat's edit box is shown over the tabs instead of under the chat.",
        "The values from before are put back when Chat is turned off.",
        "Confirming reloads the UI.",
    },
    reload      = true,
})

local function DB() return ns.db.modules.chat end

local function WriteOwned() ns.TakeOwned("chat", OWNED, "CHAT") end
local function RestoreOwned() ns.GiveBackOwned("chat", "CHAT") end

-- ---------------------------------------------------------------------------
-- Blizzard's tab row
-- ---------------------------------------------------------------------------

local dockY0                -- the row's offset before our first write (runtime only)
local dockPending = false   -- a write waits for the end of combat
local host                  -- event frame while the module is on

-- Blizzard's two anchors, read back: rel and the offset when the row hangs
-- by its bottom corners off the top corners of one region, the shape
-- FCFDock_SetPrimary gives it; nil otherwise (then it is left alone, so a row
-- someone else placed is never fought over). Only the offset is ever
-- rewritten; the region stays Blizzard's choice.
-- FIELD RESULT 2026-10-08 (build 70245): on Forever the row hangs off
-- ChatFrame1Background (a region of ChatFrame1) with offset 0, not off
-- ChatFrame1 with 3 as in retail's FloatingChatFrame.lua:1900.
local function DockAnchor(gdm)
    if gdm:GetNumPoints() ~= 2 then return nil end
    local anchor, y
    for i = 1, 2 do
        local point, rel, relPoint, x, py = gdm:GetPoint(i)
        -- Anchors can read back secret in restricted content (Ellesmere guards
        -- the chat frames' anchors for that, EllesmereUIChat.lua:1150-1156);
        -- then the row is left as it is.
        if issecretvalue(x) or issecretvalue(py) then return nil end
        if not rel or x ~= 0 then return nil end
        if not ((point == "BOTTOMLEFT" and relPoint == "TOPLEFT") or (point == "BOTTOMRIGHT" and relPoint == "TOPRIGHT")) then
            return nil
        end
        if anchor and (rel ~= anchor or py ~= y) then return nil end
        anchor, y = rel, py
    end
    return anchor, y
end

-- Puts the row's bottom edge at `bottom` (UI units, screen coordinates), or
-- back where Blizzard had it (nil). Out of combat only; in combat the write
-- waits for PLAYER_REGEN_ENABLED, which places it from the settings at that
-- time.
local function PlaceDock(bottom)
    local gdm = _G.GeneralDockManager
    if not gdm then return end
    if InCombatLockdown() then
        dockPending = true
        if host then host:RegisterEvent("PLAYER_REGEN_ENABLED") end
        return
    end
    local rel, now = DockAnchor(gdm)
    if rel == nil then
        ns.Log("CHAT", "tab row not anchored as Blizzard leaves it; left alone")
        return
    end
    dockY0 = dockY0 or now
    local y = dockY0
    if bottom then
        local relTop = rel:GetTop()
        if not relTop or issecretvalue(relTop) then return end      -- see DockAnchor
        y = bottom - relTop
    end
    if math.abs(now - y) < 0.001 then return end
    gdm:SetPoint("BOTTOMLEFT", rel, "TOPLEFT", 0, y)
    gdm:SetPoint("BOTTOMRIGHT", rel, "TOPRIGHT", 0, y)
end

-- ---------------------------------------------------------------------------
-- Our panels
-- ---------------------------------------------------------------------------

local chatPanel, tabsPanel, cover
local joined, seamLine      -- with the seam: the border round both panels, and the line between
local active                -- the edit box over the tabs now (runtime)
local Seat                  -- defined with the edit box code below
local seat                  -- where an edit box goes: offsets off ChatFrame1, set by Draw (runtime)

-- BACKGROUND strata: below the chat frame and Ellesmere's panel (LOW, Known:
-- wow-ui-source ChatFrame.xml:3, EllesmereUIChat.lua:4472) and its tab strip
-- (MEDIUM, Tabs.lua:123), so text and tabs always draw on top. Not parented to
-- ChatFrame1: it is hidden whenever another docked tab is selected.
local function NewPanel()
    local f = CreateFrame("Frame", nil, UIParent)
    f:SetFrameStrata("BACKGROUND")
    f:SetFrameLevel(1)
    f:EnableMouse(false)
    f.tex = f:CreateTexture(nil, "BACKGROUND")
    f.tex:SetAllPoints(f)
    return f
end

local function Paint(f, hex, alpha)
    local r, g, b = ns.HexToRGB(hex)
    f.tex:SetColorTexture(r, g, b, tonumber(alpha) or 0.65)
end

local function px(v) return tonumber(v) or 0 end

-- Size 0: ns.Border.Apply hides the panel's own border (Ellesmere's
-- ApplyBorderStyle hides at size 0, Core/Border.lua).
local NO_BORDER = { style = "solid", size = 0, color = "000000", alpha = 1 }

-- Assumed: ChatFrame1 has UIParent's scale (Blizzard and Ellesmere set none
-- on it), so its units, UIParent's and those of our panels and the tab row
-- are the same.
local function Draw()
    local cf = _G.ChatFrame1
    if not (cf and chatPanel) then return end
    local left, right, top, bottom = cf:GetLeft(), cf:GetRight(), cf:GetTop(), cf:GetBottom()
    if not (left and right and top and bottom) then return end      -- not laid out yet: PLAYER_ENTERING_WORLD draws
    -- The chat frame's rect can read back secret in restricted content
    -- (Ellesmere guards the same reads, EllesmereUIChat.lua:4416-4417); then
    -- everything stays where it is until the next draw.
    if issecretvalue(left) or issecretvalue(right) or issecretvalue(top) or issecretvalue(bottom) then return end
    local d = DB()
    local u = ns.Ellesmere.PixelUnit(cf)
    local Snap = ns.Border.Snap
    -- With the seam the panels meet: no gap, the seam line is the join.
    local pad, topPad, gap = px(d.padding) * u, px(d.topPadding) * u, d.seam and 0 or px(d.tabGap) * u
    -- Snapped to whole pixels: ChatFrame1 is wherever Edit Mode or Ellesmere put
    -- it, and a panel edge between two pixels draws a blurred border.
    ns.Border.Outside(chatPanel, cf, 0, -pad, -pad, -topPad, -pad)
    -- The tab panel hangs off ChatFrame1's top edge only, like the tab row, so
    -- the two stay together when the chat is resized. Its height is
    -- Ellesmere's tab height (the EllesmereUI style; the stock styles use their
    -- own, and the page warns about them).
    local tabsBottom = Snap(top + topPad + gap, u)
    local tabsTop = Snap(tabsBottom + (ns.Ellesmere.ChatTabHeight() or 24), u)
    local dx1, dx2 = Snap(left - pad, u) - left, Snap(right + pad, u) - right
    tabsPanel:ClearAllPoints()
    tabsPanel:SetPoint("BOTTOMLEFT", cf, "TOPLEFT", dx1, tabsBottom - top)
    tabsPanel:SetPoint("BOTTOMRIGHT", cf, "TOPRIGHT", dx2, tabsBottom - top)
    tabsPanel:SetHeight(tabsTop - tabsBottom)
    Paint(chatPanel, d.chatColor, d.chatAlpha)
    Paint(tabsPanel, d.tabsColor, d.tabsAlpha)
    if d.seam then
        -- One border round both, like the Damage Meter's Header Seam: the
        -- panels lose their own and the seam line lies over the joined
        -- border's sides.
        ns.Border.Apply(chatPanel, NO_BORDER)
        ns.Border.Apply(tabsPanel, NO_BORDER)
        joined:ClearAllPoints()
        joined:SetPoint("TOPLEFT", tabsPanel, "TOPLEFT")
        joined:SetPoint("BOTTOMRIGHT", chatPanel, "BOTTOMRIGHT")
        ns.Border.Apply(joined, d.border)
        joined:Show()
        seamLine:ClearAllPoints()
        seamLine:SetPoint("TOPLEFT", chatPanel, "TOPLEFT")
        seamLine:SetPoint("TOPRIGHT", chatPanel, "TOPRIGHT")
        seamLine:SetHeight(1)
        seamLine:Show()
        ns.Border.Seam(seamLine.tex, seamLine, d.border)
    else
        ns.Border.Apply(chatPanel, d.border)
        ns.Border.Apply(tabsPanel, d.border)
        joined:Hide()
        seamLine:Hide()
    end
    chatPanel:Show()
    tabsPanel:Show()
    -- The tabs stand on the row's bottom edge: put it on our tab panel's.
    PlaceDock(tabsBottom)
    seat = seat or {}
    seat.x1, seat.x2, seat.y, seat.h = dx1, dx2, tabsTop - top, tabsTop - tabsBottom
    Paint(cover, d.editColor, 1)        -- opaque: the tabs must not show through the edit box
    ns.Border.Apply(cover, d.border)
    if active then Seat(active) end         -- a setting changed while typing
end

-- ---------------------------------------------------------------------------
-- The edit box over the tabs
-- ---------------------------------------------------------------------------

local before = setmetatable({}, { __mode = "k" })   -- edit box -> its points and strata before ours

-- The docked windows' boxes only: ChatFrame1-10. Temporary whisper windows
-- (11+) are never touched (Ellesmere: their state is secret, Known:
-- EllesmereUIChat.lua:4118-4128), and an undocked window keeps its box.
local function OurBox(eb)
    if not eb or type(eb.GetName) ~= "function" then return false end
    local n = eb:GetName()
    local i = n and tonumber(n:match("^ChatFrame(%d+)EditBox$"))
    if not (i and i <= 10) then return false end
    local cf = _G["ChatFrame" .. i]
    return cf == _G.ChatFrame1 or (cf and cf.isDocked) and true or false
end

-- Anchored to ChatFrame1 (Ellesmere anchors each box to its own chat frame,
-- EllesmereUIChat.lua:3020-3033; docked frames share ChatFrame1's rect), not
-- to our frame, so the box stays in Blizzard's anchor chain.
-- Ellesmere's full chat pass puts the box back under the chat; boxWatch
-- below seats it again after that pass.
-- HIGH strata: above Ellesmere's tab strip (MEDIUM 100, Tabs.lua:123-126) and
-- our cover over it (MEDIUM 110).
function Seat(eb)
    local cf = _G.ChatFrame1
    if not before[eb] then
        local pts = {}
        for i = 1, eb:GetNumPoints() do pts[i] = { eb:GetPoint(i) } end
        before[eb] = { points = pts, strata = eb:GetFrameStrata(), h = eb:GetHeight() }
    end
    eb:ClearAllPoints()
    eb:SetPoint("TOPLEFT", cf, "TOPLEFT", seat.x1, seat.y)
    eb:SetPoint("TOPRIGHT", cf, "TOPRIGHT", seat.x2, seat.y)
    eb:SetHeight(seat.h)
    eb:SetFrameStrata("HIGH")
end

local function Unseat(eb)
    local b = before[eb]
    if not b then return end
    before[eb] = nil
    eb:ClearAllPoints()
    for _, p in ipairs(b.points) do eb:SetPoint(unpack(p)) end
    eb:SetHeight(b.h)
    eb:SetFrameStrata(b.strata)
end

-- Ellesmere's full chat pass runs ApplyInputPosition, which anchors every box
-- under its chat again, one tick after these events (Known: EllesmereUIChat
-- .lua:5453-5487 and 5546-5552; FIELD RESULT 2026-10-08 (build 70245): a
-- whisper while typing dropped the box under the chat). We seat it again
-- two ticks later, so our pass runs after Ellesmere's whichever event handler
-- ran first. Not a hook on the box's SetPoint: Blizzard's whisper code moves
-- and reads the box inside secure execution, and Ellesmere measured that a
-- hook in that chain taints it (EllesmereUIChat.lua:5533-5545). Registered
-- only while a box is seated; the box can stand under the chat for those two
-- ticks.
local BOX_EVENTS = {
    "CHAT_MSG_WHISPER", "CHAT_MSG_WHISPER_INFORM", "CHAT_MSG_BN_WHISPER", "CHAT_MSG_BN_WHISPER_INFORM",
    "UPDATE_CHAT_WINDOWS", "UPDATE_FLOATING_CHAT_WINDOWS", "UI_SCALE_CHANGED", "DISPLAY_SIZE_CHANGED",
    "PLAYER_ENTERING_WORLD",
}
local boxWatch, reseatQueued

local function Reseat()
    xpcall(function()
        if active and seat and active:IsShown() then Seat(active) end
    end, ns.ErrorHandler("chat:reseat"))
end
-- The flag clears here, one tick in: an event from now on starts a new
-- chain, so it still lands after the Ellesmere pass that event queues.
local function ReseatNextTick()
    reseatQueued = false
    C_Timer.After(0, Reseat)
end

local function WatchBox(on)
    if on and not boxWatch then
        boxWatch = CreateFrame("Frame")
        boxWatch:SetScript("OnEvent", function()
            if reseatQueued then return end
            reseatQueued = true
            C_Timer.After(0, ReseatNextTick)
        end)
    end
    if not boxWatch then return end
    for _, e in ipairs(BOX_EVENTS) do
        if on then boxWatch:RegisterEvent(e) else boxWatch:UnregisterEvent(e) end
    end
end

local function OnBoxShow(eb)
    if not (seat and OurBox(eb)) then return end
    active = eb
    Seat(eb)
    cover:Show()
    WatchBox(true)
end

local function OnBoxHide(eb)
    if eb ~= active then return end
    active = nil
    cover:Hide()
    WatchBox(false)
end

local OWNER = "WarUI_Chat"

local function Listen(on)
    if on then
        EventRegistry:RegisterCallback("ChatFrame.OnEditBoxShow", function(_, eb)
            xpcall(function() OnBoxShow(eb) end, ns.ErrorHandler("chat:boxShow"))
        end, OWNER)
        EventRegistry:RegisterCallback("ChatFrame.OnEditBoxHide", function(_, eb)
            xpcall(function() OnBoxHide(eb) end, ns.ErrorHandler("chat:boxHide"))
        end, OWNER)
    else
        EventRegistry:UnregisterCallback("ChatFrame.OnEditBoxShow", OWNER)
        EventRegistry:UnregisterCallback("ChatFrame.OnEditBoxHide", OWNER)
    end
end

-- ---------------------------------------------------------------------------
-- Module
-- ---------------------------------------------------------------------------

local function OnEvent(_, event)
    if event == "PLAYER_REGEN_ENABLED" then
        host:UnregisterEvent("PLAYER_REGEN_ENABLED")
        if not dockPending then return end
        dockPending = false
        if ns.IsModuleEnabled("chat") then Draw() else PlaceDock(nil) end
    else
        -- Entering the world (login, reload, zoning): Ellesmere lays its chat
        -- out after our login pass (EllesmereUIChat.lua:5277 initFrame), so the
        -- snapped offsets are taken again from ChatFrame1's settled rect.
        Draw()
    end
end

function M:Enable()
    if not chatPanel then
        chatPanel = NewPanel()
        tabsPanel = NewPanel()
        -- The seam's frames: above the panels' own border holders (level 2).
        joined = NewPanel()
        joined.tex:Hide()
        joined:SetFrameLevel(2)
        joined:Hide()
        seamLine = NewPanel()
        seamLine.tex:SetTexture(nil)
        seamLine:SetFrameLevel(4)
        seamLine:Hide()
        -- Over Ellesmere's tab strip (MEDIUM 100) while a box is shown.
        cover = NewPanel()
        cover:SetFrameStrata("MEDIUM")
        cover:SetFrameLevel(110)
        cover:SetAllPoints(tabsPanel)
        -- Takes the clicks over the tabs while typing, so a click there does
        -- not select a tab or open its menu under the edit box.
        cover:EnableMouse(true)
        cover:Hide()
    end
    if not host then
        host = CreateFrame("Frame")
        host:SetScript("OnEvent", function(_, event)
            xpcall(function() OnEvent(_, event) end, ns.ErrorHandler("chat:" .. event))
        end)
    end
    host:RegisterEvent("PLAYER_ENTERING_WORLD")
    Listen(true)
end

function M:Apply()
    Draw()
end

function M:Disable()
    RestoreOwned()
    if not chatPanel then return end
    chatPanel:Hide()
    tabsPanel:Hide()
    joined:Hide()
    seamLine:Hide()
    cover:Hide()
    Listen(false)
    WatchBox(false)
    active = nil
    for eb in pairs(before) do Unseat(eb) end
    host:UnregisterEvent("PLAYER_ENTERING_WORLD")
    PlaceDock(nil)          -- keeps PLAYER_REGEN_ENABLED registered if it has to wait
end

-- Blizzard's Chat Style (Options > Social) Classic: the edit box over the
-- tabs is made for it (with IM it is always shown and covers the tabs).
local function EnsureClassic()
    if GetCVar("chatStyle") ~= "classic" then
        SetCVar("chatStyle", "classic")
        return true
    end
    return false
end

function M:SwitchedOn() WriteOwned(); EnsureClassic() end

-- At login (War UI 2.4): Ellesmere values and Classic chat style, always.
function M.Ensure()
    local a = ns.EnsureOwned("chat", OWNED, "CHAT")
    local b = EnsureClassic()
    return a or b
end

-- ---------------------------------------------------------------------------
-- Settings page
-- ---------------------------------------------------------------------------

-- alphaKey nil: colour only, no alpha slider.
local function ColorCell(text, tip, colorKey, alphaKey, changed)
    return { type = "colorpicker", text = text, hasAlpha = alphaKey ~= nil, tooltip = tip,
        getValue = function()
            local r, g, b = ns.HexToRGB(DB()[colorKey])
            if not alphaKey then return r, g, b end
            return r, g, b, tonumber(DB()[alphaKey]) or 0.65
        end,
        setValue = function(r, g, b, a)
            DB()[colorKey] = ns.RGBToHex(r, g, b)
            if alphaKey then DB()[alphaKey] = a or 1 end
            changed()
        end }
end

local function SliderCell(text, tip, key, maxV, changed)
    return { type = "slider", text = text, min = 0, max = maxV, step = 1, tooltip = tip,
        getValue = function() return px(DB()[key]) end,
        setValue = function(v) DB()[key] = v; changed() end }
end

-- Ellesmere's own Tab Height (Chat > Tabs), shown here so the tab panel's
-- height can be set from this page. It is Ellesmere's value, not ours: it is
-- not restored when Chat is turned off. Ellesmere's slider applies it live
-- through its internal ApplyTabLayout (EUI_Chat_Options.lua:741-746), which
-- we may not call, so a change asks for a reload; Cancel puts the old value
-- back.
local tabHeightPending, tabHeightBefore      -- value from before an unanswered change
local releaseWaiter                          -- frame whose OnUpdate waits for the mouse button

local function AskTabHeightReload()
    local E = ns.Ellesmere
    local profile = E.OwnedProfile("chat")
    -- Dragged back to where it started: nothing to reload.
    if E.ChatTabHeight() == (tonumber(tabHeightBefore) or 24) then
        E.WriteOwned("chat", profile, "tabHeight", tabHeightBefore)
        tabHeightPending, tabHeightBefore = nil, nil
        return
    end
    E.Confirm({
        title = "Chat: Tab Height",
        message = "Ellesmere's tabs and War UI's tab panel change height after a reload.",
        confirmText = "Reload",
        reload = true,
        onConfirm = function() tabHeightPending = nil end,
        onCancel = function()
            E.WriteOwned("chat", profile, "tabHeight", tabHeightBefore)
            tabHeightPending, tabHeightBefore = nil, nil
            E.RefreshPage()
        end,
    })
end

-- Ellesmere's slider has no release callback: it calls setValue at every step
-- while dragging (EllesmereUI_Widgets.lua:1460-1495). So the popup waits
-- until the left button is up; the OnUpdate runs only while it waits. A typed
-- value in the number box arrives with the button up and asks at once.
local function AskOnRelease()
    if not IsMouseButtonDown("LeftButton") then
        AskTabHeightReload()
        return
    end
    if not releaseWaiter then releaseWaiter = CreateFrame("Frame") end
    releaseWaiter:SetScript("OnUpdate", function(self)
        if IsMouseButtonDown("LeftButton") then return end
        self:SetScript("OnUpdate", nil)
        AskTabHeightReload()
    end)
end

local function TabHeightCell()
    local E = ns.Ellesmere
    return { type = "slider", text = "Tab Height", min = 18, max = 40, step = 1,
        tooltip = "Ellesmere's Tab Height (Chat > Tabs). The tab panel takes this height. Applies after a reload.",
        disabled = function() return E.ChatTabHeight() == nil or E.ChatStockStyle() end,
        disabledTooltip = "Ellesmere's chat in the EllesmereUI style",
        getValue = function() return E.ChatTabHeight() or 24 end,
        setValue = function(v)
            -- The slider also commits on a click without a move and when its
            -- number box loses focus: no change, no popup.
            if not tabHeightPending and v == E.ChatTabHeight() then return end
            local profile = E.OwnedProfile("chat")
            if not tabHeightPending then
                local _, old = E.ReadOwned("chat", profile, "tabHeight")
                tabHeightPending, tabHeightBefore = true, old
            end
            E.WriteOwned("chat", profile, "tabHeight", v)
            AskOnRelease()
        end }
end

local function TabGapCell(changed)
    local c = SliderCell("Tab Gap", "Pixels between the chat panel and the tab panel. The tabs move with it. Waits for the end of combat.", "tabGap", 32, changed)
    c.disabled = function() return DB().seam == true end
    c.disabledTooltip = "Tab Seam is on: the panels meet at the seam."
    c.rawTooltip = true
    return c
end

function M:BuildPage(_, parent, y, W)
    local _, h
    local function changed() ns.Apply() end
    if ns.Ellesmere.ChatStockStyle() then
        _, h = W:DualRow(parent, y,
            { type = "label", text = "Ellesmere's chat uses Blizzard Style or Classic WoW UI, which draw their own chat art over War UI's panels. This module is made for the EllesmereUI style." }); y = y - h
    end

    _, h = W:SectionHeader(parent, "CHAT PANEL", y); y = y - h
    _, h = W:DualRow(parent, y,
        ColorCell("Background", "The panel behind the chat text. Replaces Ellesmere's chat background, which this module sets to 0.", "chatColor", "chatAlpha", changed),
        SliderCell("Padding", "Pixels the panel reaches past the chat text on the left, right and bottom.", "padding", 32, changed)); y = y - h
    _, h = W:DualRow(parent, y,
        SliderCell("Top Padding", "Pixels the panel reaches above the chat text.", "topPadding", 32, changed),
        { type = "spacer" }); y = y - h

    _, h = W:SectionHeader(parent, "TABS", y); y = y - h
    _, h = W:DualRow(parent, y,
        ColorCell("Background", "The panel behind the tabs. Ellesmere's own tab backgrounds are drawn on top of it.", "tabsColor", "tabsAlpha", changed),
        TabGapCell(changed)); y = y - h
    _, h = W:DualRow(parent, y,
        { type = "toggle", text = "Tab Seam",
          tooltip = "One border round the tab panel and the chat panel, with a line of the border where they meet, like Ellesmere's Power Bar Seam. The Pixels styles draw their seam art; Solid a plain line; other textured styles have none. Tab Gap is not used while it is on; in combat the tabs follow when combat ends.",
          getValue = function() return DB().seam == true end,
          setValue = function(v)
              DB().seam = v and true or false
              changed()
              ns.Ellesmere.RefreshPage()      -- Tab Gap greys in or out
          end },
        { type = "spacer" }); y = y - h
    _, h = W:DualRow(parent, y,
        TabHeightCell(),
        ColorCell("Edit Box Background", "Covers the tabs while you type; the edit box is shown on it.", "editColor", nil, changed)); y = y - h
    -- Blizzard's Chat Style (Options > Social). The edit box over the tabs is
    -- made for Classic, where the box is shown only while typing; with IM it
    -- is always shown and covers the tabs. A reload lets Blizzard's chat
    -- start in the new style.
    _, h = W:DualRow(parent, y,
        { type = "button", text = "Use Classic Chat Style", width = 180,
          disabled = function() return GetCVar("chatStyle") == "classic" end,
          disabledTooltip = "Blizzard's Chat Style is already Classic.", rawTooltip = true,
          onClick = function()
              ns.Ellesmere.Confirm({
                  title = "Chat: Classic Chat Style",
                  message = "Set Blizzard's Chat Style (Options > Social) to Classic, so the edit box is shown only while you type?",
                  confirmText = "Set and reload",
                  reload = true,
                  onConfirm = function() SetCVar("chatStyle", "classic") end,
              })
          end },
        { type = "label", text = "The edit box over the tabs is made for Classic. With IM Style it is always shown and covers the tabs." }); y = y - h

    _, h = W:SectionHeader(parent, "BORDER", y); y = y - h
    y = ns.Border.Rows(W, parent, y, function() return DB().border end, changed)

    _, h = W:SectionHeader(parent, "ELLESMERE SETTINGS", y); y = y - h
    local names = {}
    for _, o in ipairs(OWNED) do names[#names + 1] = o.label end
    _, h = W:DualRow(parent, y,
        { type = "button", text = "Set Ellesmere Values", width = 180,
          disabled = function() return not ns.IsModuleEnabled("chat") end,
          disabledTooltip = "Turn Chat on first",
          onClick = function()
              ns.Ellesmere.Confirm({
                  title = "Chat: set Ellesmere values",
                  message = "Set these again, so only War UI's panels and border show?\n- "
                      .. table.concat(names, "\n- "),
                  confirmText = "Set and reload",
                  reload = true,
                  onConfirm = WriteOwned,
              })
          end },
        { type = "label", text = "Use it if you changed them in Ellesmere's menu." }); y = y - h

    if not ns.IsModuleEnabled("chat") then
        _, h = W:DualRow(parent, y,
            { type = "label", text = "Chat is off: turn it on at the top of this page." }); y = y - h
    end
    return y
end
