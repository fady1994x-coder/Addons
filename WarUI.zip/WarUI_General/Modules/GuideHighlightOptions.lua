-------------------------------------------------------------------------------
--  WarUI_General / Modules / GuideHighlightOptions.lua
--  Guide Highlight's rows, drawn on the Quest Tracker tab under its own
--  header and on/off toggle (Core/Options.lua, hostPage).
-------------------------------------------------------------------------------
local G  = WarUIGeneral
local ns = G.GuideHighlight
local M  = ns.M

local function DB() return ns.DB() end
local function Refresh() G.Options.Refresh() end

local function Pad() return EllesmereUI.CONTENT_PAD or 20 end

local function Paragraph(parent, text, y, alpha, r, g, b)
    local w = parent:GetWidth() - Pad() * 2
    local fs = EllesmereUI.MakeFont(parent, 12, nil, r or 1, g or 1, b or 1, alpha or 0.7)
    fs:SetJustifyH("LEFT")
    fs:SetText(text)
    fs:SetWidth(w - 20)
    fs:SetSpacing(4)
    fs:SetPoint("TOPLEFT", parent, "TOPLEFT", Pad() + 10, y - 6)
    return y - (fs:GetStringHeight() or 40) - 16
end

-- Small live preview of the highlight, drawn with the current settings.
local function Preview(parent, y)
    local d = DB()
    local w = math.min(320, parent:GetWidth() - Pad() * 2 - 20)
    local box = CreateFrame("Frame", nil, parent)
    box:SetSize(w, 44)
    box:SetPoint("TOPLEFT", parent, "TOPLEFT", Pad() + 10, y - 6)
    local bg = box:CreateTexture(nil, "BACKGROUND", nil, -8)
    bg:SetAllPoints()
    bg:SetColorTexture(0.035, 0.035, 0.035, 0.85)

    local r, g, b = ns.GetColor()
    local a = d.bgAlpha or 0.2
    local tint = box:CreateTexture(nil, "BACKGROUND", nil, -6)
    tint:SetTexture("Interface\\Buttons\\WHITE8X8")
    tint:SetAllPoints()
    if d.gradient and tint.SetGradient and CreateColor then
        tint:SetGradient("HORIZONTAL", CreateColor(r, g, b, a), CreateColor(r, g, b, a * 0.15))
    else
        tint:SetVertexColor(r, g, b, a)
    end
    if d.showBar then
        local bar = box:CreateTexture(nil, "BORDER")
        bar:SetColorTexture(r, g, b, 0.95)
        bar:SetPoint("TOPLEFT"); bar:SetPoint("BOTTOMLEFT"); bar:SetWidth(d.barWidth or 3)
    end
    if d.showBorder then
        local ba = d.borderAlpha or 0.55
        local function edge(p1, p2, horiz)
            local t = box:CreateTexture(nil, "BORDER", nil, 1)
            t:SetColorTexture(r, g, b, ba)
            t:SetPoint(p1); t:SetPoint(p2)
            if horiz then t:SetHeight(1) else t:SetWidth(1) end
        end
        edge("TOPLEFT", "TOPRIGHT", true); edge("BOTTOMLEFT", "BOTTOMRIGHT", true)
        edge("TOPLEFT", "BOTTOMLEFT"); edge("TOPRIGHT", "BOTTOMRIGHT")
    end
    local title = EllesmereUI.MakeFont(box, 12, nil, 1, 0.91, 0.47, 1)
    if d.titleColor then title:SetTextColor(r + (1 - r) * 0.35, g + (1 - g) * 0.35, b + (1 - b) * 0.35) end
    title:SetPoint("TOPLEFT", box, "TOPLEFT", 12, -7)
    title:SetText("[8] A Favor for Evershine")
    local obj = EllesmereUI.MakeFont(box, 10, nil, 0.72, 0.72, 0.72, 1)
    obj:SetPoint("TOPLEFT", title, "BOTTOMLEFT", 6, -4)
    obj:SetText("- 4/6 Ice Claw Bear slain")
    return y - 60
end

local MODE_VALUES = { _noLoc = true, current = "Current step only", all = "Current step + sticky steps" }
local MODE_ORDER  = { "current", "all" }

local function ColorValues()
    local v = { _noLoc = true }
    for k, p in pairs(ns.COLOR_PRESETS) do v[k] = p.label end
    return v
end

local function AskHex()
    EllesmereUI:ShowInputPopup({
        title       = "Highlight Color",
        message     = "Hex color, for example 66CCFF (light blue).",
        initialText = DB().customHex or "66CCFF",
        placeholder = "RRGGBB",
        confirmText = "Save",
        maxLetters  = 7,
        onConfirm   = function(text)
            text = tostring(text or ""):gsub("[#%s]", ""):upper()
            if text:match("^%x%x%x%x%x%x$") then
                DB().customHex = text
                DB().color = "custom"
                ns.Apply()
                Refresh()
            else
                print("|cff66ccffGuide Highlight:|r '" .. text .. "' is not a 6-digit hex color.")
            end
        end,
    })
end

-- Cells. `redraw` rebuilds the tab (for the preview); sliders do not, so a
-- drag is not interrupted (the preview catches up on the next visit).
local function Toggle(text, key, tip, redraw)
    return { type = "toggle", text = text, tooltip = tip,
        getValue = function() return DB()[key] == true end,
        setValue = function(v) DB()[key] = v and true or false; ns.Apply(); if redraw then Refresh() end end }
end
local function Slider(text, key, minV, maxV, step, tip)
    return { type = "slider", text = text, min = minV, max = maxV, step = step, tooltip = tip,
        getValue = function() return tonumber(DB()[key]) or minV end,
        setValue = function(v) DB()[key] = v; ns.Apply() end }
end
local function Pct(text, key, minV, maxV, step, default)
    return { type = "slider", text = text, min = minV, max = maxV, step = step,
        getValue = function() return math.floor((tonumber(DB()[key]) or default) * 100 + 0.5) end,
        setValue = function(v) DB()[key] = v / 100; ns.Apply() end }
end

function M:BuildPage(_, parent, y, W)
    local _, h
    local prebuild = EllesmereUI.IsSearchPrebuild()

    if not prebuild and G.IsModuleEnabled("guideHighlight") then
        ns.Refresh()
        if not ns.HasRXP() then
            y = Paragraph(parent, "RestedXP Guides is not loaded - nothing to highlight.", y, 0.95, 1, 0.55, 0.3)
        elseif #ns.current == 0 then
            y = Paragraph(parent, "The current guide step has no quest from your quest log.", y, 0.6)
        else
            local names = {}
            for i, id in ipairs(ns.current) do names[i] = ns.QuestName(id) end
            local r, g, b = ns.GetColor()
            y = Paragraph(parent, "Highlighting now: " .. table.concat(names, ", ") ..
                (ns.matched < #ns.current and "  (not all are shown in the tracker)" or ""), y, 0.95, r, g, b)
        end
    end

    _, h = W:DualRow(parent, y,
        { type = "dropdown", text = "Which Steps", values = MODE_VALUES, order = MODE_ORDER,
          tooltip = "Current step only: the step(s) RestedXP shows right now.\n" ..
                    "Current + sticky: also quests from steps that stay open in the background.",
          getValue = function() return DB().mode end,
          setValue = function(v) DB().mode = v; ns.Apply() end },
        Toggle("Include Turn-In Steps", "includeTurnin", "Also highlight a quest when the step tells you to hand it in.")); y = y - h
    _, h = W:DualRow(parent, y,
        Slider("Max Quests", "maxQuests", 1, 5, 1, "How many quests can be highlighted at once (a step can name several)."),
        Toggle("Dim Extra Quests", "dimSecondary", "The first quest gets the full color, the rest a weaker one.")); y = y - h
    _, h = W:DualRow(parent, y,
        Toggle("Highlight in War UI Quest Tracker", "questTracker",
            "When War UI's Quest Tracker is on, draw the highlight in its list too. Its own Guide Dot / Guide Highlight options work on their own."),
        Toggle("Auto-Track Guide Quests", "autoTrack",
            "If the guide quest is not in the tracker, add it (once per session, so un-tracking it by hand sticks).")); y = y - h

    if not prebuild then y = Preview(parent, y) end
    _, h = W:DualRow(parent, y,
        { type = "dropdown", text = "Highlight Color", values = ColorValues(), order = ns.COLOR_ORDER,
          tooltip = "Light Blue is the default. Custom asks for a hex color.",
          getValue = function() return DB().color end,
          setValue = function(v)
              DB().color = v; ns.Apply(); Refresh()
              if v == "custom" then AskHex() end
          end },
        { type = "button", text = "Custom Hex (" .. (DB().customHex or "66CCFF") .. ")", width = 170, onClick = AskHex }); y = y - h
    _, h = W:DualRow(parent, y,
        Pct("Background Opacity", "bgAlpha", 0, 60, 1, 0.2),
        Toggle("Fade to the Right", "gradient", "The tint fades out towards the right side instead of a flat color.", true)); y = y - h
    _, h = W:DualRow(parent, y,
        Toggle("Accent Bar on the Left", "showBar", nil, true),
        Slider("Accent Bar Width", "barWidth", 1, 8, 1)); y = y - h
    _, h = W:DualRow(parent, y,
        Toggle("Thin Border", "showBorder", nil, true),
        Pct("Border Opacity", "borderAlpha", 5, 100, 5, 0.55)); y = y - h
    _, h = W:DualRow(parent, y,
        Toggle("Color the Quest Title", "titleColor", "Paint the quest title in a lighter version of the highlight color.", true),
        Toggle("Pulse", "pulse", "The highlight slowly fades in and out.")); y = y - h
    _, h = W:DualRow(parent, y,
        Slider("Side Padding", "padX", 0, 12, 1, "How far the highlight reaches past the quest on the left and right."),
        Slider("Top / Bottom Padding", "padY", 0, 8, 1)); y = y - h
    _, h = W:DualRow(parent, y,
        { type = "button", text = "Print Debug Info", width = 170,
          onClick = function() SlashCmdList.WARUIGUIDEHL("debug") end },
        { type = "label", text = "/guidehl debug: what the guide step names and what is highlighted." }); y = y - h
    return y
end
