-- WarUI_General / Modules / Loot.lua
-- v2.1.0: ElvUI-style roll bars, replacing Blizzard's Need/Greed popups.
--
--   [icon] [Need 3][Greed 1][DE][Pass 2]  BoE  Item Name ..............
--          \______ timer bar in the item's quality colour ___________/
--
-- Every button carries a number: how many players chose it. Hover a button
-- and the tooltip lists who (class coloured, with their roll once rolled).
-- Hover the bar for the whole roll (and who is still waiting); hover the
-- icon for the item. v2.1: the bar goes the moment you click (Hide After
-- Rolling, on by default; off = it stays, your choice lit, and keeps
-- counting). When the roll ends the bar comes back as "Player won - Item"
-- for Show Winner For seconds (2) and fades.
--
-- Blizzard's roll popups are opened from UIParent's START_LOOT_ROLL handler.
-- With the module on, UIParent's START_LOOT_ROLL / CANCEL_LOOT_ROLL are
-- unregistered (as ElvUI does), and GroupLootContainer / GroupLootFrame1-4
-- are hidden if they show anyway. Only a /reload undoes that, so the module
-- is `reload = true`. Blizzard keeps the confirm popups (LOOT_BIND_CONFIRM,
-- CONFIRM_LOOT_ROLL).
--
-- Who chose what: the client says so only in chat (CHAT_MSG_LOOT). Lines are
-- matched against the client's own format strings (LOOT_ROLL_NEED,
-- LOOT_ROLL_ROLLED_GREED, LOOT_ROLL_WON ...), so it works in every language.
-- A line is matched to a roll by item (item ID, else item name); with two
-- copies of one item it goes to the oldest roll that player has not answered.
--
-- Nothing here is protected: RollOnLoot works in combat.

local ns = WarUIGeneral

local issecretvalue = issecretvalue or function() return false end

local M = ns.RegisterModule("loot", {
    title       = "Loot",
    description = "ElvUI-style Need/Greed roll bars: a count on every button, hover it to see who chose it, roll numbers and the winner.",
    pages       = { "Loot" },
    reload      = true,
    affects     = { "Hides Blizzard's Need/Greed popups (War UI draws its own roll bars). The loot window stays Blizzard's." },
    defaults    = {
        enabled = true,     -- War UI 2.4: on by default
        rolls        = true,    -- replace the Need/Greed popups
        barWidth     = 328,     -- the bar, without the icon
        barHeight    = 28,
        spacing      = 4,
        growUp       = false,
        barTexture   = "none",  -- EllesmereUI / SharedMedia bar texture key, "none" = flat
        barAlpha     = 0.75,
        fontSize     = 12,
        showNumbers  = true,    -- roll numbers in the button tooltips
        showWaiting  = true,    -- "Waiting" in the bar tooltip
        hideAfterRoll = true,   -- the bar goes the moment you click
        showWinner   = true,    -- "Player won - Item" on the bar when the roll ends
        keep         = 2,       -- seconds the winner shows before the bar goes
        minQuality   = 2,       -- rolls you can't roll on: shown from Uncommon (green) up
        bgColor      = "080B0D", bgAlpha = 0.85,
        border       = { useGlobal = true, style = "solid", size = 1, color = "000000", alpha = 1 },
        -- rollPos (EllesmereUI Unlock Mode): { point, relPoint, x, y } from UIParent, nil = default.
    },
})

local function DB() return ns.db.modules.loot end

-- ---------------------------------------------------------------------------
-- Helpers
-- ---------------------------------------------------------------------------

local function Plain(v)
    if v == nil or issecretvalue(v) then return nil end
    return v
end

local function FontPath()
    local ok, path, flags = pcall(ns.Ellesmere.Font)
    if ok and path then return path, flags or "" end
    return STANDARD_TEXT_FONT or "Fonts\\FRIZQT__.TTF", ""
end

local function SetFont(fs, size)
    local path, flags = FontPath()
    if not fs:SetFont(path, size, flags) then
        fs:SetFont(STANDARD_TEXT_FONT or "Fonts\\FRIZQT__.TTF", size, "")
    end
end

local function QualityColor(q)
    local c = q and ITEM_QUALITY_COLORS and ITEM_QUALITY_COLORS[q]
    if c then return c.r, c.g, c.b end
    return 1, 1, 1
end

-- Quality from a link's colour code (|cff1eff00 = Uncommon), for items not in
-- the client's cache yet.
local function QualityFromLink(text)
    local hex = type(text) == "string" and text:match("|c%x%x(%x%x%x%x%x%x)")
    if hex and ITEM_QUALITY_COLORS then
        hex = hex:lower()
        for q, c in pairs(ITEM_QUALITY_COLORS) do
            local r, g, b = c.r, c.g, c.b
            if r and ns.RGBToHex(r, g, b):lower() == hex then return q end
            if c.hex and c.hex:lower():find(hex, 1, true) then return q end
        end
    end
end

local function ItemQuality(text)
    local id = type(text) == "string" and tonumber(text:match("item:(%d+)"))
    local q = id and C_Item and C_Item.GetItemQualityByID and C_Item.GetItemQualityByID(id)
    return Plain(q) or QualityFromLink(text)
end

-- Rolls below the chosen quality (grey, white) get no tracker.
local function Tracked(quality)
    return (tonumber(quality) or 0) >= (tonumber(DB().minQuality) or 2)
end

local function ClassHex(token)
    if token then
        local ok, r, g, b = pcall(ns.Ellesmere.ClassColor, token)
        if ok and r then return ns.RGBToHex(r, g, b) end
        local c = RAID_CLASS_COLORS and RAID_CLASS_COLORS[token]
        if c then return ns.RGBToHex(c.r, c.g, c.b) end
    end
    return "BFBFBF"
end

-- "Name-Realm", a player link, or plain: the short name.
local function ShortName(s)
    if type(s) ~= "string" then return nil end
    local linked = s:match("|Hplayer:([^:|]+)")
    if linked then s = linked end
    s = s:gsub("|c%x%x%x%x%x%x%x%x", ""):gsub("|r", ""):gsub("|H.-|h", ""):gsub("|h", "")
    s = s:gsub("^%[", ""):gsub("%]$", "")
    return (s:match("^([^%-]+)") or s)
end

local function ItemKey(s)
    if type(s) ~= "string" then return nil end
    local id = s:match("item:(%d+)")
    if id then return "i" .. id end
    local name = s:match("%[(.-)%]") or s
    return "n" .. name:lower()
end

local function ItemNameKey(s)
    if type(s) ~= "string" then return nil end
    local name = s:match("%[(.-)%]") or s
    return "n" .. name:lower()
end

-- ---------------------------------------------------------------------------
-- Group roster: short name -> class token
-- ---------------------------------------------------------------------------

local roster = {}

local function AddUnit(unit)
    if not UnitExists(unit) then return end
    local name = Plain(UnitName(unit))
    local _, token = UnitClass(unit)
    token = Plain(token)
    if name then roster[name] = token or roster[name] or false end
end

local function ScanRoster()
    wipe(roster)
    AddUnit("player")
    if IsInRaid() then
        for i = 1, 40 do AddUnit("raid" .. i) end
    else
        for i = 1, 4 do AddUnit("party" .. i) end
    end
end

local function NameHex(name)
    return ClassHex(roster[name] or nil)
end

local function SnapshotGroup()
    ScanRoster()
    local out = {}
    for name in pairs(roster) do out[#out + 1] = name end
    table.sort(out)
    return out
end

-- ---------------------------------------------------------------------------
-- Chat line matching against the client's own format strings
-- ---------------------------------------------------------------------------

-- A Blizzard format string as a Lua pattern; `order` maps each capture to the
-- argument it fills (for "%2$s" style formats).
local function Compile(fmt)
    local parts, order, i, seq = {}, {}, 1, 0
    while true do
        local s, e, pos, kind = fmt:find("%%(%d*)%$?([sd])", i)
        local lit = fmt:sub(i, s and s - 1 or nil)
        parts[#parts + 1] = (lit:gsub("[%^%$%(%)%.%[%]%*%+%-%?%%]", "%%%0"))
        if not s then break end
        seq = seq + 1
        order[#order + 1] = tonumber(pos) or seq
        parts[#parts + 1] = kind == "d" and "(%d+)" or "(.-)"
        i = e + 1
    end
    return { pat = "^" .. table.concat(parts) .. "$", order = order }
end

local compiled = {}
local function Match(key, text)
    local c = compiled[key]
    if c == nil then
        local fmt = _G[key]
        c = (type(fmt) == "string" and fmt ~= "") and Compile(fmt) or false
        compiled[key] = c
    end
    if not c then return nil end
    local caps = { text:match(c.pat) }
    if #caps == 0 then return nil end
    local args = {}
    for n, argIndex in ipairs(c.order) do args[argIndex] = caps[n] end
    return args
end

-- { key, kind, args = names of the arguments in order }
-- kind: choice (need/greed/de/pass), roll (number), won, allpass.
local PATTERNS = {
    { "LOOT_ROLL_ALL_PASSED",        "allpass", nil,    { "item" } },
    { "LOOT_ROLL_NEED_SELF",         "choice", "need",  { "item" }, self = true },
    { "LOOT_ROLL_GREED_SELF",        "choice", "greed", { "item" }, self = true },
    { "LOOT_ROLL_DISENCHANT_SELF",   "choice", "de",    { "item" }, self = true },
    { "LOOT_ROLL_PASSED_SELF_AUTO",  "choice", "pass",  { "item" }, self = true },
    { "LOOT_ROLL_PASSED_SELF",       "choice", "pass",  { "item" }, self = true },
    { "LOOT_ROLL_NEED",              "choice", "need",  { "name", "item" } },
    { "LOOT_ROLL_GREED",             "choice", "greed", { "name", "item" } },
    { "LOOT_ROLL_DISENCHANT",        "choice", "de",    { "name", "item" } },
    { "LOOT_ROLL_PASSED_AUTO",       "choice", "pass",  { "name", "item" } },
    { "LOOT_ROLL_PASSED_AUTO_FEMALE","choice", "pass",  { "name", "item" } },
    { "LOOT_ROLL_PASSED",            "choice", "pass",  { "name", "item" } },
    { "LOOT_ROLL_ROLLED_NEED_ROLE_BONUS", "roll", "need",  { "roll", "item", "name" } },
    { "LOOT_ROLL_ROLLED_NEED",       "roll",   "need",  { "roll", "item", "name" } },
    { "LOOT_ROLL_ROLLED_GREED",      "roll",   "greed", { "roll", "item", "name" } },
    { "LOOT_ROLL_ROLLED_DE",         "roll",   "de",    { "roll", "item", "name" } },
    { "LOOT_ROLL_YOU_WON_NO_SPAM_NEED",  "won", "need",  { "roll", "item" }, self = true },
    { "LOOT_ROLL_YOU_WON_NO_SPAM_GREED", "won", "greed", { "roll", "item" }, self = true },
    { "LOOT_ROLL_YOU_WON_NO_SPAM_DE",    "won", "de",    { "roll", "item" }, self = true },
    { "LOOT_ROLL_WON_NO_SPAM_NEED",  "won",    "need",  { "name", "roll", "item" } },
    { "LOOT_ROLL_WON_NO_SPAM_GREED", "won",    "greed", { "name", "roll", "item" } },
    { "LOOT_ROLL_WON_NO_SPAM_DE",    "won",    "de",    { "name", "roll", "item" } },
    { "LOOT_ROLL_YOU_WON",           "won",    nil,     { "item" }, self = true },
    { "LOOT_ROLL_WON",               "won",    nil,     { "name", "item" } },
}

local function ParseLine(text)
    for _, p in ipairs(PATTERNS) do
        local args = Match(p[1], text)
        if args then
            local out = { kind = p[2], choice = p[3] }
            for n, field in ipairs(p[4]) do out[field] = args[n] end
            if p.self then out.name = Plain(UnitName("player")) end
            out.name = ShortName(out.name)
            out.roll = tonumber(out.roll)
            return out
        end
    end
end

-- ---------------------------------------------------------------------------
-- Host (the stack's anchor and the Unlock Mode mover)
-- ---------------------------------------------------------------------------

local rollHost              -- where the roll bars stack
local unlockActive = false  -- EllesmereUI Unlock Mode is open
local rows = {}             -- active roll bars, oldest first
local rowPool = {}
local testMode = false

local ICON_GAP = 3

local function W_() return tonumber(DB().barWidth) or 328 end
local function H_() return tonumber(DB().barHeight) or 28 end

local function Backdrop(f)
    if not f.bg then
        f.bg = f:CreateTexture(nil, "BACKGROUND")
        f.bg:SetAllPoints()
    end
    local r, g, b = ns.HexToRGB(DB().bgColor)
    f.bg:SetColorTexture(r, g, b, tonumber(DB().bgAlpha) or 0.85)
    ns.Border.Apply(f, DB().border)
end

local function BarTexture()
    local key = DB().barTexture
    if key and key ~= "none" then
        local ok, path = pcall(ns.Ellesmere.BarTexturePath, key)
        if ok and path then return path end
    end
    return "Interface\\Buttons\\WHITE8X8"
end

-- Where Blizzard's roll popups sit: above the action bars, left of centre.
local DEFAULT_ROLLS = { point = "TOPLEFT", relPoint = "CENTER", x = -200, y = -120 }

local function SavedPos(key)
    if not ns.db then return nil end
    local p = DB()[key]
    if type(p) ~= "table" then return nil end
    if p.point then return p end
    if p.x and p.y then return { point = "TOPLEFT", relPoint = "TOPLEFT", x = p.x, y = p.y } end
end

local function PlaceAt(frame, p)
    frame:ClearAllPoints()
    frame:SetPoint(p.point, UIParent, p.relPoint or p.point, tonumber(p.x) or 0, tonumber(p.y) or 0)
end

local function ApplyPositions()
    if not rollHost then return end
    PlaceAt(rollHost, SavedPos("rollPos") or DEFAULT_ROLLS)
end

-- One bar's size (icon included), so the mover has something to grab.
local function SizeHost()
    if not rollHost or not ns.db then return end
    rollHost:SetSize(W_() + H_() + ICON_GAP, H_())
end

local function BuildHost()
    if rollHost then return end
    local h = CreateFrame("Frame", "WarUILootRolls", UIParent)
    h:SetFrameStrata("HIGH")
    h:SetSize(359, 28)
    h.ph = h:CreateTexture(nil, "BACKGROUND")
    h.ph:SetAllPoints()
    h.ph:SetColorTexture(0.2, 0.6, 1, 0.25)
    h.phText = h:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    h.phText:SetPoint("CENTER")
    h.phText:SetText("War UI: Loot Rolls")
    h.ph:Hide(); h.phText:Hide()
    rollHost = h
    SizeHost()
    ApplyPositions()
end

-- ---------------------------------------------------------------------------
-- Roll bars
-- ---------------------------------------------------------------------------

local CHOICES = {
    { key = "need",  type = 1, label = NEED or "Need",   color = "40FF40",
      tex = "Interface\\Buttons\\UI-GroupLoot-Dice-Up" },
    { key = "greed", type = 2, label = GREED or "Greed", color = "FFD100",
      tex = "Interface\\Buttons\\UI-GroupLoot-Coin-Up" },
    { key = "de",    type = 3, label = ROLL_DISENCHANT or "Disenchant", color = "B070FF",
      tex = "Interface\\Buttons\\UI-GroupLoot-DE-Up" },
    { key = "pass",  type = 0, label = PASS or "Pass",   color = "A0A0A0",
      tex = "Interface\\Buttons\\UI-GroupLoot-Pass-Up" },
}
local CHOICE_BY_KEY = {}
for _, c in ipairs(CHOICES) do CHOICE_BY_KEY[c.key] = c end

local LayoutRolls               -- forward
local Finished                  -- forward

local function PlayerName() return Plain(UnitName("player")) or "You" end

-- Entries of one choice, best roll first, then by name.
local function ListOf(row, key)
    local list = {}
    for name, e in pairs(row.entries) do
        if e.choice == key then list[#list + 1] = { name = name, roll = e.roll } end
    end
    table.sort(list, function(a, b)
        if (a.roll or -1) ~= (b.roll or -1) then return (a.roll or -1) > (b.roll or -1) end
        return a.name < b.name
    end)
    return list
end

local function AddNames(list, row, withRoll)
    for _, e in ipairs(list) do
        local r, g, b = ns.HexToRGB(NameHex(e.name))
        local left = e.name .. ((row.winner == e.name) and " |cffffd100(won)|r" or "")
        if withRoll and e.roll then
            GameTooltip:AddDoubleLine(left, tostring(e.roll), r, g, b, 1, 1, 1)
        else
            GameTooltip:AddLine(left, r, g, b)
        end
    end
end

local function Waiting(row)
    local out = {}
    for _, name in ipairs(row.group or {}) do
        local e = row.entries[name]
        if not (e and e.choice) then out[#out + 1] = { name = name } end
    end
    return out
end

-- Tooltip on a button: who chose it.
local function ButtonTooltip(btn)
    local row, c = btn.row, btn.choice
    GameTooltip:SetOwner(btn, "ANCHOR_TOP")
    local list = ListOf(row, c.key)
    local r, g, b = ns.HexToRGB(c.color)
    GameTooltip:AddDoubleLine(c.label, tostring(#list), r, g, b, 1, 1, 1)
    if btn.reason then GameTooltip:AddLine(btn.reason, 1, 0.3, 0.3, true) end
    if #list == 0 then
        GameTooltip:AddLine("Nobody yet", 0.6, 0.6, 0.6)
    else
        AddNames(list, row, DB().showNumbers and c.key ~= "pass")
    end
    GameTooltip:Show()
end

-- Tooltip on the bar: the whole roll.
local function BarTooltip(row)
    GameTooltip:SetOwner(row, "ANCHOR_TOP")
    local qr, qg, qb = QualityColor(row.quality)
    GameTooltip:AddLine(row.itemName or "?", qr, qg, qb)
    if row.winner then
        GameTooltip:AddLine("Won by " .. row.winner .. (row.winRoll and (" (" .. row.winRoll .. ")") or ""), 1, 0.82, 0)
    elseif row.allPassed then
        GameTooltip:AddLine("Everyone passed", 0.6, 0.6, 0.6)
    end
    local any = false
    for _, c in ipairs(CHOICES) do
        local list = ListOf(row, c.key)
        if #list > 0 then
            any = true
            local r, g, b = ns.HexToRGB(c.color)
            GameTooltip:AddLine(" ")
            GameTooltip:AddDoubleLine(c.label, tostring(#list), r, g, b, 1, 1, 1)
            AddNames(list, row, DB().showNumbers and c.key ~= "pass")
        end
    end
    if DB().showWaiting and not Finished(row) then
        local waiting = Waiting(row)
        if #waiting > 0 then
            GameTooltip:AddLine(" ")
            GameTooltip:AddDoubleLine("Waiting", tostring(#waiting), 0.5, 0.5, 0.5, 1, 1, 1)
            AddNames(waiting, row, false)
        end
    end
    if not any then GameTooltip:AddLine("Nobody has chosen yet", 0.6, 0.6, 0.6) end
    GameTooltip:Show()
end

local function RollButton(row, c)
    local b = CreateFrame("Button", nil, row.status)
    b:SetNormalTexture(c.tex)
    b:SetHighlightTexture((c.tex:gsub("%-Up$", "-Highlight")), "ADD")
    b:SetPushedTexture((c.tex:gsub("%-Up$", "-Down")))
    b:SetMotionScriptsWhileDisabled(true)
    b.choice, b.row = c, row
    b.count = b:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    b.count:SetPoint("BOTTOMRIGHT", b, "BOTTOMRIGHT", 3, -2)
    b:SetScript("OnClick", function(self)
        if not self.can or row.myChoice or row.done or not row.rollID then return end
        if not row.fake then RollOnLoot(row.rollID, c.type) end
        -- Counted at once; the chat line that follows lands on the same entry.
        row.myChoice = c.key
        local me = PlayerName()
        row.entries[me] = row.entries[me] or {}
        row.entries[me].choice = c.key
        M.RefreshRow(row)
        if GameTooltip:IsOwned(self) then ButtonTooltip(self) end
    end)
    b:SetScript("OnEnter", ButtonTooltip)
    b:SetScript("OnLeave", function() GameTooltip:Hide() end)
    return b
end

local function NewRow()
    local row = table.remove(rowPool)
    if row then return row end
    row = CreateFrame("Frame", nil, UIParent)
    row:SetFrameStrata("HIGH")
    row:EnableMouse(true)

    -- Icon, outside the bar on the left.
    local icon = CreateFrame("Button", nil, row)
    icon:SetPoint("RIGHT", row, "LEFT", -ICON_GAP, 0)
    icon.tex = icon:CreateTexture(nil, "ARTWORK")
    icon.tex:SetPoint("TOPLEFT", 1, -1); icon.tex:SetPoint("BOTTOMRIGHT", -1, 1)
    icon.tex:SetTexCoord(0.08, 0.92, 0.08, 0.92)
    icon.edge = icon:CreateTexture(nil, "BACKGROUND")
    icon.edge:SetAllPoints()
    icon.count = icon:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    icon.count:SetPoint("BOTTOMRIGHT", -1, 2)
    icon:SetScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_LEFT")
        if row.rollID and not row.fake and not row.done then
            pcall(GameTooltip.SetLootRollItem, GameTooltip, row.rollID)
        elseif row.link then
            pcall(GameTooltip.SetHyperlink, GameTooltip, row.link)
        end
        GameTooltip:Show()
    end)
    icon:SetScript("OnLeave", function() GameTooltip:Hide() end)
    icon:SetScript("OnClick", function()
        if row.link and IsModifierKeyDown() then HandleModifiedItemClick(row.link) end
    end)
    row.icon = icon

    -- The timer bar fills the frame, in the item's quality colour.
    local status = CreateFrame("StatusBar", nil, row)
    status:SetPoint("TOPLEFT", 1, -1); status:SetPoint("BOTTOMRIGHT", -1, 1)
    status:SetMinMaxValues(0, 1)
    status:SetValue(1)
    status.spark = status:CreateTexture(nil, "OVERLAY")
    status.spark:SetTexture("Interface\\CastingBar\\UI-CastingBar-Spark")
    status.spark:SetBlendMode("ADD")
    status.spark:SetWidth(14)
    row.status = status

    row.buttons = {}
    for _, c in ipairs(CHOICES) do row.buttons[c.key] = RollButton(row, c) end

    row.bind = status:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    row.bind:SetJustifyH("LEFT")
    row.name = status:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    row.name:SetJustifyH("LEFT")
    row.name:SetWordWrap(false)

    row:SetScript("OnEnter", BarTooltip)
    row:SetScript("OnLeave", function() GameTooltip:Hide() end)
    row:SetScript("OnMouseUp", function()
        if row.link and IsModifierKeyDown() then HandleModifiedItemClick(row.link) end
    end)
    row:SetScript("OnUpdate", function(self, elapsed)
        self.tick = (self.tick or 0) + elapsed
        if self.tick < 0.03 then return end
        self.tick = 0
        M.UpdateTimer(self)
    end)
    return row
end

-- Sizes, fonts and the button row, from the settings.
local function StyleRow(row)
    local w, h = W_(), H_()
    local size = tonumber(DB().fontSize) or 12
    row:SetSize(w, h)
    Backdrop(row)
    row.icon:SetSize(h, h)
    row.status:SetStatusBarTexture(BarTexture())
    row.status.spark:SetHeight(h * 1.8)
    SetFont(row.name, size)
    SetFont(row.bind, size)
    SetFont(row.icon.count, size - 1)

    local bs = h - 6
    local x = 4
    for _, c in ipairs(CHOICES) do
        local b = row.buttons[c.key]
        b:ClearAllPoints()
        if b:IsShown() then
            b:SetSize(bs, bs)
            b:SetPoint("LEFT", row.status, "LEFT", x, 0)
            -- The count sits on the button in an outline font, like ElvUI.
            local path = FontPath()
            if not b.count:SetFont(path, math.max(9, size - 1), "OUTLINE") then
                b.count:SetFont(STANDARD_TEXT_FONT or "Fonts\\FRIZQT__.TTF", math.max(9, size - 1), "OUTLINE")
            end
            x = x + bs + 4
        end
    end
    row.bind:ClearAllPoints()
    row.bind:SetPoint("LEFT", row.status, "LEFT", x + 2, 0)
    row.name:ClearAllPoints()
    if row.bind:GetText() and row.bind:GetText() ~= "" then
        row.name:SetPoint("LEFT", row.bind, "RIGHT", 4, 0)
    else
        row.name:SetPoint("LEFT", row.status, "LEFT", x + 2, 0)
    end
    row.name:SetPoint("RIGHT", row.status, "RIGHT", -4, 0)
end

-- Bind text: BoP red, BoE green (from the item's bind type when known).
local function BindText(row)
    if row.bop_ then return "|cffff4040BoP|r" end
    local id = row.link and tonumber(tostring(row.link):match("item:(%d+)"))
    if id and C_Item and C_Item.GetItemInfo then
        local ok, _, _, _, _, _, _, _, _, _, _, _, _, bindType = pcall(C_Item.GetItemInfo, id)
        bindType = ok and Plain(bindType)
        if bindType == 2 then return "|cff1eff00BoE|r" end
        if bindType == 1 then return "|cffff4040BoP|r" end
    end
    return ""
end

function M.RefreshRow(row)
    local db = DB()
    -- Hide After Rolling: the bar goes when you choose, but it is still
    -- followed (hidden) until the roll ends, so later chat lines do not bring
    -- it back as a new bar.
    local finished = Finished(row)
    -- Grey and white items you can't roll on, or that are done: nothing to show.
    if not Tracked(row.quality) and (row.rollID == nil or finished) then
        M.RemoveRow(row)
        return
    end
    -- The roll is over: the bar comes back (if hidden) as "Player won - Item"
    -- for Show Winner For seconds, or goes at once.
    if finished then
        if not db.showWinner or (tonumber(db.keep) or 2) <= 0 then M.RemoveRow(row) return end
        row.gone = nil
    -- Hide After Rolling: the bar goes when you choose, but it is still
    -- followed (hidden) until the roll ends, so later chat lines do not bring
    -- it back as a new bar.
    elseif row.myChoice and db.hideAfterRoll then
        row.gone = true
        row:Hide()
        if GameTooltip:IsOwned(row) then GameTooltip:Hide() end
        LayoutRolls()
        return
    end

    local r, g, b = QualityColor(row.quality)
    row.icon.tex:SetTexture(row.texture or 134400)
    row.icon.edge:SetColorTexture(r, g, b, 1)
    row.icon.count:SetText((row.count and row.count > 1) and row.count or "")
    row.bind:SetText(finished and "" or BindText(row))

    -- Name, or the result once there is one.
    if row.winner then
        row.name:SetText("|cff" .. NameHex(row.winner) .. row.winner .. "|r |cffffd100won|r"
            .. (row.winRoll and (" |cffffffff(" .. row.winRoll .. ")|r") or "")
            .. " - |cff" .. ns.RGBToHex(r, g, b) .. (row.itemName or "?") .. "|r")
        row.name:SetTextColor(1, 1, 1)
    elseif row.allPassed then
        row.name:SetText("|cffa0a0a0Everyone passed -|r |cff" .. ns.RGBToHex(r, g, b) .. (row.itemName or "?") .. "|r")
        row.name:SetTextColor(1, 1, 1)
    else
        row.name:SetText(row.itemName or "?")
        row.name:SetTextColor(r, g, b)
    end
    row.status:SetStatusBarColor(r, g, b, tonumber(db.barAlpha) or 0.75)

    -- Buttons: always shown (they carry the counts); clickable while the roll
    -- is yours to answer. DE only when it can be chosen or someone chose it.
    local open = row.rollID ~= nil and not row.done and not row.myChoice
    local counts = { need = 0, greed = 0, de = 0, pass = 0 }
    for _, e in pairs(row.entries) do
        if e.choice and counts[e.choice] then counts[e.choice] = counts[e.choice] + 1 end
    end
    for _, c in ipairs(CHOICES) do
        local btn = row.buttons[c.key]
        local can, reason = true, nil
        if c.key == "need" then can, reason = row.canNeed ~= false, row.reasonNeed
        elseif c.key == "greed" then can, reason = row.canGreed ~= false, row.reasonGreed
        elseif c.key == "de" then can, reason = row.canDE == true, row.reasonDE end
        if row.rollID == nil then can = false end
        btn:SetShown(not finished and (c.key ~= "de" or row.canDE == true or counts.de > 0))
        local lit
        if row.myChoice then lit = (row.myChoice == c.key)
        elseif row.done then lit = false
        else lit = can end
        btn:GetNormalTexture():SetDesaturated(not lit)
        btn:SetAlpha(lit and 1 or 0.55)
        btn.reason = (not can and row.rollID ~= nil and not row.myChoice)
            and (reason or "You can't choose this for this item.") or nil
        btn.can = open and can
        local n = counts[c.key]
        btn.count:SetText(n > 0 and n or "")
        btn.count:SetTextColor(ns.HexToRGB(c.color))
    end

    StyleRow(row)
    LayoutRolls()
end

function M.UpdateTimer(row)
    local now = GetTime()
    if row.expire then
        if now >= row.expire then M.RemoveRow(row) return end
        local left = row.expire - now
        row:SetAlpha(left < 0.5 and (left / 0.5) or 1)
    end
    local v
    if row.done then
        v = 0
    elseif row.fake and row.fakeEnd then
        v = math.max(0, (row.fakeEnd - now) / (row.fakeLen or 30))
        if v <= 0 and row.onFakeEnd then local f = row.onFakeEnd; row.onFakeEnd = nil; f() end
    elseif row.rollID then
        local left = Plain(GetLootRollTimeLeft(row.rollID))
        if left and row.rollTime and row.rollTime > 0 then
            v = math.max(0, math.min(1, left / row.rollTime))
        end
    end
    if v then
        row.status:SetValue(v)
        local w = row.status:GetWidth() or 0
        row.status.spark:ClearAllPoints()
        row.status.spark:SetPoint("CENTER", row.status, "LEFT", w * v, 0)
        row.status.spark:SetShown(v > 0 and v < 1)
    end
    if row.done then
        row.status:SetValue(1)
        row.status.spark:Hide()
        local r, g, b = QualityColor(row.quality)
        row.status:SetStatusBarColor(r * 0.35, g * 0.35, b * 0.35, tonumber(DB().barAlpha) or 0.75)
    end
end

function LayoutRolls()
    if not rollHost then return end
    local h, sp = H_(), tonumber(DB().spacing) or 4
    local up = DB().growUp
    local y = 0
    for _, row in ipairs(rows) do
        row:ClearAllPoints()
        if row.gone then
            row:Hide()
        else
            row:Show()
            if up then
                row:SetPoint("BOTTOMLEFT", rollHost, "BOTTOMLEFT", h + ICON_GAP, y)
            else
                row:SetPoint("TOPLEFT", rollHost, "TOPLEFT", h + ICON_GAP, -y)
            end
            y = y + h + sp
        end
    end
end

function M.RemoveRow(row)
    for i, r in ipairs(rows) do
        if r == row then table.remove(rows, i) break end
    end
    row:Hide()
    if GameTooltip:IsOwned(row) then GameTooltip:Hide() end
    row.rollID, row.fake, row.expire, row.done, row.winner = nil, nil, nil, nil, nil
    row.finishedAt, row.gone, row.onFakeEnd = nil, nil, nil
    rowPool[#rowPool + 1] = row
    LayoutRolls()
end

function Finished(row) return row.winner ~= nil or row.allPassed == true end

-- The roll is over. awarded = the item went to its winner (or everyone
-- passed): the bar shows the winner for Show Winner For seconds, then goes.
-- Not awarded (timer ran out, CANCEL_LOOT_ROLL): the winner line usually
-- follows in a moment; if it never comes the bar goes after a minute.
local function Finish(row, awarded)
    row.done = true
    local now = GetTime()
    if awarded then
        if not row.finishedAt then row.finishedAt = now end
        row.expire = now + math.max(0, tonumber(DB().keep) or 2)
    elseif not row.expire then
        row.expire = now + 60
    end
end

-- Hidden bars have no OnUpdate: their expire is checked here, once a second.
-- Safety: a roll we never saw end goes 10 minutes after it appeared.
local SAFETY = 600
local function Sweep()
    local now = GetTime()
    -- Test rolls whose bar is hidden (you rolled) still get their winner.
    for i = #rows, 1, -1 do
        local row = rows[i]
        if row and row.fake and row.onFakeEnd and row.fakeEnd and now >= row.fakeEnd then
            local f = row.onFakeEnd; row.onFakeEnd = nil; f()
        end
    end
    for i = #rows, 1, -1 do
        local row = rows[i]
        if row and ((row.expire and now >= row.expire)
                or (not row.fake and row.started and now - row.started >= SAFETY)) then
            M.RemoveRow(row)
        end
    end
end

local function AddRow(fields)
    BuildHost()
    local row = NewRow()
    for k in pairs(row) do
        if type(k) == "string" and k:sub(1, 1) ~= "_" and type(row[k]) ~= "table" and type(row[k]) ~= "userdata"
           and type(row[k]) ~= "function" then row[k] = nil end
    end
    row.entries, row.group = {}, nil
    row.myChoice, row.winner, row.winRoll, row.allPassed, row.onFakeEnd = nil, nil, nil, nil, nil
    for k, v in pairs(fields) do row[k] = v end
    row.started = GetTime()
    row:SetAlpha(1)
    rows[#rows + 1] = row
    row:Show()
    M.RefreshRow(row)
    return row
end

-- ---------------------------------------------------------------------------
-- Roll events
-- ---------------------------------------------------------------------------

local function Reason(n)
    n = Plain(n)
    if not n or n == 0 then return nil end
    return _G["LOOT_ROLL_INELIGIBLE_REASON" .. n]
end

local function StartRoll(rollID, rollTime)
    local texture, name, count, quality, bop, canNeed, canGreed, canDE, rNeed, rGreed, rDE = GetLootRollItemInfo(rollID)
    if not texture and not name then return end
    local link = GetLootRollItemLink(rollID)
    rollTime = Plain(rollTime) or Plain(GetLootRollTimeLeft(rollID)) or 60000
    AddRow({
        rollID = rollID, rollTime = rollTime, texture = texture, itemName = name, count = count,
        quality = quality, bop_ = bop, canNeed = canNeed, canGreed = canGreed, canDE = canDE,
        reasonNeed = Reason(rNeed), reasonGreed = Reason(rGreed), reasonDE = Reason(rDE),
        link = link, key = ItemKey(link) or ItemNameKey(name), nameKey = ItemNameKey(name),
        group = SnapshotGroup(),
    })
end

local function RowFor(rollID)
    for _, row in ipairs(rows) do
        if row.rollID == rollID and not row.fake then return row end
    end
end

-- The roll a chat line is about: same item, and (for a choice) the oldest one
-- this player has not answered yet; else the newest with that item.
local function FindRow(itemText, name, want)
    local key, nameKey = ItemKey(itemText), ItemNameKey(itemText)
    local matches = {}
    for _, row in ipairs(rows) do
        if not row.fake and (row.key == key or row.nameKey == nameKey) then matches[#matches + 1] = row end
    end
    for _, row in ipairs(matches) do
        local e = name and row.entries[name]
        if want == "choice" and not (e and e.choice) and not row.winner then return row end
        if want == "choice" and e and e.choice and row.myChoice and name == PlayerName() and not row.winner then return row end
        if want == "roll" and e and not e.roll then return row end
        if want == "won" and not row.winner and not row.allPassed then return row end
    end
    return matches[#matches]
end

-- A roll we got no START_LOOT_ROLL for (we could not roll on it): a bar
-- with counts but no clickable buttons.
local function OrphanRow(itemText)
    local name = itemText:match("%[(.-)%]") or itemText
    local id = tonumber(itemText:match("item:(%d+)"))
    local texture
    if id and C_Item and C_Item.GetItemIconByID then texture = Plain(C_Item.GetItemIconByID(id)) end
    return AddRow({
        itemName = name, texture = texture, quality = ItemQuality(itemText), link = itemText:match("|H.-|h.-|h"),
        key = ItemKey(itemText), nameKey = ItemNameKey(itemText), group = SnapshotGroup(),
    })
end

local function OnLootChat(text)
    text = Plain(text)
    if type(text) ~= "string" or not text:find("[%[|]") then return end
    local info = ParseLine(text)
    if not info or not info.item then return end
    local row = FindRow(info.item, info.name, info.kind)
    if not row then
        if info.kind == "allpass" then return end
        local q = ItemQuality(info.item)
        if q == nil or not Tracked(q) then return end
        row = OrphanRow(info.item)
    end
    if info.kind == "choice" and info.name then
        local e = row.entries[info.name] or {}
        e.choice = info.choice
        row.entries[info.name] = e
        if info.name == PlayerName() then row.myChoice = info.choice end
    elseif info.kind == "roll" and info.name then
        local e = row.entries[info.name] or {}
        e.choice = e.choice or info.choice
        e.roll = info.roll
        row.entries[info.name] = e
    elseif info.kind == "won" then
        row.winner = info.name
        local e = info.name and row.entries[info.name]
        row.winRoll = info.roll or (e and e.roll)
        Finish(row, true)
    elseif info.kind == "allpass" then
        row.allPassed = true
        Finish(row, true)
    end
    M.RefreshRow(row)
end

-- ---------------------------------------------------------------------------
-- Blizzard's roll popups
-- ---------------------------------------------------------------------------

local tookRolls = false

local function HideBlizzRollFrames()
    if not (M.active and tookRolls) then return end
    for i = 1, 4 do
        local f = _G["GroupLootFrame" .. i]
        if f and f:IsShown() then f:Hide() end
    end
end

local function TakeBlizzard()
    if DB().rolls and not tookRolls then
        UIParent:UnregisterEvent("START_LOOT_ROLL")
        UIParent:UnregisterEvent("CANCEL_LOOT_ROLL")
        tookRolls = true
        for i = 1, 4 do
            local f = _G["GroupLootFrame" .. i]
            if f then f:HookScript("OnShow", HideBlizzRollFrames) end
        end
        if GroupLootContainer then
            GroupLootContainer:HookScript("OnShow", function(self)
                if M.active and tookRolls then self:Hide() end
            end)
        end
    end
end

-- ---------------------------------------------------------------------------
-- Events
-- ---------------------------------------------------------------------------

local events = CreateFrame("Frame")
events:SetScript("OnEvent", function(_, event, ...)
    if not M.active then return end
    local db = DB()
    if event == "START_LOOT_ROLL" then
        if not (db.rolls and tookRolls) then return end
        local rollID, rollTime = ...
        StartRoll(rollID, rollTime)
        HideBlizzRollFrames()
    elseif event == "CANCEL_LOOT_ROLL" then
        local row = RowFor((...))
        if row and not row.done then
            Finish(row)
            M.RefreshRow(row)
        end
    elseif event == "CHAT_MSG_LOOT" then
        if db.rolls and tookRolls then OnLootChat((...)) end
    elseif event == "GROUP_ROSTER_UPDATE" then
        ScanRoster()
    end
end)

local EVENTS = { "START_LOOT_ROLL", "CANCEL_LOOT_ROLL", "CHAT_MSG_LOOT", "GROUP_ROSTER_UPDATE" }

-- ---------------------------------------------------------------------------
-- Test mode (no group needed): three fake rolls. Fake players choose over a
-- few seconds and the counts go up; hover a button to see who. Click a button
-- to roll yourself. Each roll is won when its 30 s timer runs out (the first
-- one after 12 s).
-- ---------------------------------------------------------------------------

local FAKE_GROUP = {
    { "Thrall", "SHAMAN" }, { "Uther", "PALADIN" }, { "Valeera", "ROGUE" },
    { "Rexxar", "HUNTER" }, { "Anduin", "PRIEST" }, { "Garrosh", "WARRIOR" }, { "Malfurion", "DRUID" },
    { "Guldan", "WARLOCK" }, { "Jaina", "MAGE" },
}

local function StopTest()
    testMode = false
    for i = #rows, 1, -1 do
        if rows[i].fake then M.RemoveRow(rows[i]) end
    end
end

local function FakeWinner(row)
    if not row.fake or row.done then return end
    -- Highest roll among Need, else Greed/DE.
    local best, bestRoll
    for _, key in ipairs({ "need", "greed", "de" }) do
        for name, e in pairs(row.entries) do
            if e.choice == key then
                e.roll = e.roll or math.random(1, 100)
                if (not best or best.tier == key) and (not bestRoll or e.roll > bestRoll) then
                    best, bestRoll = { tier = key, name = name }, e.roll
                end
            end
        end
        if best then break end
    end
    -- Rolls of the lower tiers too, for the tooltips.
    for _, e in pairs(row.entries) do
        if e.choice ~= "pass" and not e.roll then e.roll = math.random(1, 100) end
    end
    if best then row.winner, row.winRoll = best.name, bestRoll else row.allPassed = true end
    Finish(row, true)
    M.RefreshRow(row)
end

function M.Test()
    if not M.active then
        if ns.IsModuleEnabled("loot") then
            ns.Print("Loot: the module is on but failed to start. Type /reload; if it repeats, see /pui log.")
        else
            ns.Print("Loot: turn the module on first.")
        end
        return
    end
    if testMode then StopTest() ns.Print("Loot: test hidden.") return end
    testMode = true
    BuildHost()
    for _, p in ipairs(FAKE_GROUP) do roster[p[1]] = p[2] end
    roster[PlayerName()] = select(2, UnitClass("player"))
    local group = { PlayerName() }
    for _, p in ipairs(FAKE_GROUP) do group[#group + 1] = p[1] end

    local items = {
        { tex = 135274, name = "Fiery War Axe", q = 3, bop = false, link = "item:870", len = 12 },
        { tex = 133070, name = "Robe of the Archmage", q = 4, bop = true, link = "item:14152", de = true, len = 30 },
        { tex = 132622, name = "Lion's Mane Choker", q = 2, bop = false, link = "item:12047", len = 30 },
    }
    local now = GetTime()
    for n, it in ipairs(items) do
        local row = AddRow({
            fake = true, rollID = -n, texture = it.tex, itemName = it.name, quality = it.q,
            bop_ = it.bop, canNeed = true, canGreed = true, canDE = it.de == true, link = it.link,
            key = "test" .. n, group = group, fakeEnd = now + it.len, fakeLen = it.len,
        })
        row.onFakeEnd = function() FakeWinner(row) end
        local picks = it.de and { "need", "de", "greed", "pass" } or { "need", "greed", "pass" }
        for i, p in ipairs(FAKE_GROUP) do
            if i <= #FAKE_GROUP - n then          -- leave some waiting
                local choice = picks[((i * 7 + n * 3) % #picks) + 1]
                C_Timer.After(0.5 + 0.6 * i + n * 0.25, function()
                    if not row.fake or not testMode or row.done then return end
                    row.entries[p[1]] = { choice = choice }
                    M.RefreshRow(row)
                    for _, b in pairs(row.buttons) do
                        if GameTooltip:IsOwned(b) then ButtonTooltip(b) end
                    end
                end)
            end
        end
    end
    ns.Print("Loot: test shown. Hover Need/Greed/Pass to see who chose it; click one and the bar goes, then shows who won. Press Test again (or /waruiloot test) to hide.")
end

-- ---------------------------------------------------------------------------
-- Module
-- ---------------------------------------------------------------------------

-- EllesmereUI Unlock Mode: one mover, the roll stack. Every callback works
-- without ns.db (EUI may call them early at PLAYER_LOGIN).
local function ShowUnlockPreview(active)
    unlockActive = active and true or false
    if not rollHost then return end
    rollHost.ph:SetShown(unlockActive)
    rollHost.phText:SetShown(unlockActive)
    if unlockActive and ns.db then
        SetFont(rollHost.phText, tonumber(DB().fontSize) or 12)
        SizeHost()
    end
end

local unlockRegistered = false
local function RegisterUnlock()
    if unlockRegistered or not (EllesmereUI and EllesmereUI.RegisterUnlockElements) then return end
    unlockRegistered = true
    local function off() return not ns.db or not ns.IsModuleEnabled("loot") or not DB().rolls end
    if EllesmereUI.UnregisterUnlockElement then
        pcall(EllesmereUI.UnregisterUnlockElement, EllesmereUI, "WarUI_LootWindow")
        pcall(EllesmereUI.UnregisterUnlockElement, EllesmereUI, "WarUI_LootInfo")
    end
    EllesmereUI:RegisterUnlockElements({
        {
            key = "WarUI_LootRolls", label = "Loot Rolls",
            getFrame = function() BuildHost(); return rollHost end,
            getSize = function() BuildHost(); return rollHost:GetWidth(), rollHost:GetHeight() end,
            isHidden = off,
            savePosition = function(_, point, relPoint, x, y)
                if ns.db then DB().rollPos = { point = point, relPoint = relPoint or point, x = x, y = y } end
            end,
            loadPosition = function() return SavedPos("rollPos") end,
            clearPosition = function() if ns.db then DB().rollPos = nil end end,
            applyPosition = function() ApplyPositions() end,
        },
    }, "WarUI_General")
    if EllesmereUI.RegisterUnlockModeListener then
        EllesmereUI:RegisterUnlockModeListener("WarUI_Loot", function(active)
            if M.active then ShowUnlockPreview(active) end
        end)
    end
end

function M.OpenUnlock()
    if InCombatLockdown() then ns.Print("Loot: not in combat.") return end
    if EllesmereUI and EllesmereUI.OpenUnlockMode then
        pcall(EllesmereUI.OpenUnlockMode, EllesmereUI)
    end
end

function M:Enable()
    -- v2.1: rolls go when you click and the winner shows for 2 s (new defaults
    -- for everyone who had the v2.0 ones).
    local db = DB()
    if (tonumber(db.lootVersion) or 0) < 2 then
        db.hideAfterRoll, db.keep, db.showWinner, db.lootVersion = true, 2, true, 2
    end
    BuildHost()
    RegisterUnlock()
    TakeBlizzard()
    for _, e in ipairs(EVENTS) do pcall(events.RegisterEvent, events, e) end
    ScanRoster()
    if not M.sweeper then M.sweeper = C_Timer.NewTicker(1, function() if M.active then Sweep() end end) end
    M.active = true
end

function M:Apply()
    if not rollHost then return end
    SizeHost()
    ApplyPositions()
    for i = #rows, 1, -1 do if rows[i] then M.RefreshRow(rows[i]) end end
end

function M:Disable()
    M.active = false
    events:UnregisterAllEvents()
    StopTest()
    ShowUnlockPreview(false)
    for i = #rows, 1, -1 do M.RemoveRow(rows[i]) end
end

-- ---------------------------------------------------------------------------
-- Settings page
-- ---------------------------------------------------------------------------

function M:BuildPage(_, parent, y, W)
    local _, h
    local function changed() ns.Apply() end
    local off = function() return not ns.IsModuleEnabled("loot") end
    local offTip = "Turn Loot on first"
    local function Toggle(text, key, tip, reload)
        return { type = "toggle", text = text, tooltip = tip,
            getValue = function() return DB()[key] == true end,
            setValue = function(v)
                DB()[key] = v and true or false
                changed()
                if reload and ns.IsModuleEnabled("loot") then ns.Print("Loot: type /reload to finish.") end
                ns.Ellesmere.RefreshPage()
            end }
    end
    local function Slider(text, key, minV, maxV, step, tip)
        return { type = "slider", text = text, min = minV, max = maxV, step = step, tooltip = tip,
            getValue = function() return tonumber(DB()[key]) or minV end,
            setValue = function(v) DB()[key] = v; changed() end }
    end

    _, h = W:DualRow(parent, y,
        { type = "button", text = "Test Rolls", width = 140,
          disabled = off, disabledTooltip = offTip,
          onClick = function() M.Test() end },
        { type = "label", text = "Three fake rolls. Hover a button to see who chose it; click one to roll yourself. Press again to hide." }); y = y - h
    _, h = W:DualRow(parent, y,
        { type = "button", text = "Move (Unlock Mode)", width = 170,
          disabled = off, disabledTooltip = offTip,
          onClick = function() M.OpenUnlock() end },
        { type = "button", text = "Reset Position", width = 130,
          onClick = function() DB().rollPos = nil; changed() end }); y = y - h

    _, h = W:SectionHeader(parent, "ROLL BARS", y); y = y - h
    _, h = W:DualRow(parent, y,
        Toggle("Use War UI Roll Bars", "rolls", "ElvUI-style roll bars instead of Blizzard's Need/Greed popups. Off = Blizzard's popups. Needs a /reload.", true),
        Toggle("Hide After Rolling", "hideAfterRoll", "The bar goes the moment you click (it comes back for a moment to show who won). Off: it stays (your choice lit) and keeps counting until the item has a winner.")); y = y - h
    _, h = W:DualRow(parent, y,
        Toggle("Roll Numbers In Tooltips", "showNumbers", "The number each player rolled, beside their name, once rolled."),
        Toggle("Show Who Is Waiting", "showWaiting", "In the bar's tooltip: group members who have not chosen yet.")); y = y - h
    _, h = W:DualRow(parent, y,
        Slider("Show Winner For (sec)", "keep", 0, 10, 1, "When the roll ends the bar shows \"Player won - Item\" this long, then fades. 0 = no winner display."),
        { type = "dropdown", text = "Others' Rolls From",
          tooltip = "Rolls you can't roll on yourself (you get no popup) are still shown, with counts, from this quality up.",
          values = { ["2"] = "|cff1eff00Uncommon|r (green)", ["3"] = "|cff0070ddRare|r (blue)", ["4"] = "|cffa335eeEpic|r (purple)" },
          order = { "2", "3", "4" },
          getValue = function() return tostring(tonumber(DB().minQuality) or 2) end,
          setValue = function(v) DB().minQuality = tonumber(v) or 2; changed() end }); y = y - h

    _, h = W:SectionHeader(parent, "LOOK", y); y = y - h
    _, h = W:DualRow(parent, y,
        Slider("Bar Width", "barWidth", 200, 500, 2),
        Slider("Bar Height", "barHeight", 18, 44, 1)); y = y - h
    _, h = W:DualRow(parent, y,
        Slider("Spacing", "spacing", 0, 12, 1),
        Toggle("Grow Upwards", "growUp", "New bars stack above the first one instead of below.")); y = y - h
    local texNames, texOrder = {}, {}
    local okTex, n, o = pcall(ns.Ellesmere.BarTextures)
    if okTex and n and o then texNames, texOrder = n, o else texNames, texOrder = { none = "None (flat colour)" }, { "none" } end
    _, h = W:DualRow(parent, y,
        { type = "dropdown", text = "Bar Texture", values = texNames, order = texOrder,
          getValue = function() return DB().barTexture or "none" end,
          setValue = function(v) DB().barTexture = v; changed() end },
        { type = "slider", text = "Bar Opacity", min = 0.1, max = 1, step = 0.05,
          getValue = function() return tonumber(DB().barAlpha) or 0.75 end,
          setValue = function(v) DB().barAlpha = v; changed() end }); y = y - h
    _, h = W:DualRow(parent, y,
        Slider("Font Size", "fontSize", 9, 18, 1),
        { type = "colorpicker", text = "Background", hasAlpha = true,
          getValue = function()
              local r, g, b = ns.HexToRGB(DB().bgColor)
              return r, g, b, tonumber(DB().bgAlpha) or 0.85
          end,
          setValue = function(r, g, b, a)
              DB().bgColor = ns.RGBToHex(r, g, b)
              DB().bgAlpha = a or 1
              changed()
          end }); y = y - h
    y = ns.Border.Rows(W, parent, y, function() return DB().border end, changed)

    if off() then
        _, h = W:DualRow(parent, y,
            { type = "label", text = "Loot is off: turn it on at the top of this page." }); y = y - h
    end
    return y
end

SLASH_WARUILOOT1 = "/waruiloot"
SlashCmdList.WARUILOOT = function(msg)
    msg = tostring(msg or ""):lower()
    if msg == "test" then M.Test()
    elseif msg == "reset" then DB().rollPos = nil; ns.Apply()
    elseif msg == "move" or msg == "unlock" then M.OpenUnlock()
    else ns.Print("Loot: /waruiloot test | move | reset") end
end

ns.Options.AddModule("loot")
