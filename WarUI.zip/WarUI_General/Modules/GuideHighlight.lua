-------------------------------------------------------------------------------
--  WarUI_General / Modules / GuideHighlight.lua  (was WarUI_GuideHighlight)
--  Highlights the quest(s) your current RestedXP guide step refers to in the
--  quest tracker (Blizzard's ObjectiveTrackerFrame, skinned by EllesmereUI).
--
--  Taint rules followed (same as EllesmereUIQuestTracker):
--   * never write fields onto Blizzard frames - all state lives in weak tables
--   * no SetScript on Blizzard frames, only hooksecurefunc / HookScript
--   * all work triggered from Blizzard hooks is deferred one frame
--   * no geometry reads on tracker blocks
-------------------------------------------------------------------------------
local G = WarUIGeneral
local ns = {}
G.GuideHighlight = ns

-------------------------------------------------------------------------------
--  Saved settings
-------------------------------------------------------------------------------
ns.DEFAULTS = {
    enabled       = true,
    mode          = "current",   -- "current" = current step(s) | "all" = also sticky steps
    includeTurnin = true,        -- also highlight quests the step tells you to turn in
    maxQuests     = 3,
    dimSecondary  = true,        -- quest 2/3 a bit weaker than quest 1

    color         = "lightblue", -- preset key or "custom"
    customHex     = "66CCFF",
    bgAlpha       = 0.20,
    gradient      = true,        -- fade the tint out towards the right
    showBar       = true,
    barWidth      = 3,
    showBorder    = true,
    borderAlpha   = 0.55,
    titleColor    = true,
    pulse         = false,
    padX          = 4,
    padY          = 2,

    autoTrack     = false,
    questTracker  = true,        -- also highlight in War UI's own Quest Tracker
}

ns.COLOR_PRESETS = {
    lightblue = { label = "Light Blue",  hex = "66CCFF" },
    ice       = { label = "Ice Blue",    hex = "A6E4FF" },
    sky       = { label = "Sky Blue",    hex = "3FA9FF" },
    teal      = { label = "Teal",        hex = "33E0C8" },
    accent    = { label = "EllesmereUI Accent" },
    custom    = { label = "Custom (hex)" },
}
ns.COLOR_ORDER = { "lightblue", "ice", "sky", "teal", "accent", "custom" }

-- Settings live in the War UI General profile (ns.db.modules.guideHighlight);
-- `enabled` is the module's switch. Before PLAYER_LOGIN (no profile yet) a
-- switched-off copy of the defaults is returned, so nothing is drawn.
local preLogin
function ns.DB()
    local d = G.db and G.db.modules.guideHighlight
    if d then return d end
    if not preLogin then
        preLogin = G.DeepCopy(ns.DEFAULTS)
        preLogin.enabled = false
    end
    return preLogin
end

local function HexToRGB(hex)
    hex = tostring(hex or ""):gsub("#", "")
    if not hex:match("^%x%x%x%x%x%x$") then return 0.4, 0.8, 1 end
    return tonumber(hex:sub(1, 2), 16) / 255, tonumber(hex:sub(3, 4), 16) / 255, tonumber(hex:sub(5, 6), 16) / 255
end
ns.HexToRGB = HexToRGB

function ns.GetColor()
    local d = ns.DB()
    if d.color == "accent" then
        local c = EllesmereUI and EllesmereUI.ELLESMERE_GREEN
        if c then return c.r, c.g, c.b end
        return HexToRGB("66CCFF")
    elseif d.color == "custom" then
        return HexToRGB(d.customHex)
    end
    local p = ns.COLOR_PRESETS[d.color] or ns.COLOR_PRESETS.lightblue
    return HexToRGB(p.hex)
end

-------------------------------------------------------------------------------
--  RestedXP: which quests is the guide talking about right now?
--  RXP (global) = RestedXP's addon table. RXP.RXPFrame.activeSteps holds the
--  steps shown right now; step.elements[] have .tag ("complete", "turnin",
--  "accept", ...), .questId (or .ids) and .completed / .skip.
-------------------------------------------------------------------------------
local function InLog(id)
    if not (id and C_QuestLog and C_QuestLog.GetLogIndexForQuestID) then return false end
    local idx = C_QuestLog.GetLogIndexForQuestID(id)
    return idx and idx > 0
end

local function TagWanted(tag, d)
    if type(tag) ~= "string" then return false end
    if tag == "complete" then return true end
    if d.includeTurnin and tag:find("turnin", 1, true) then return true end
    return false
end

function ns.HasRXP()
    local rxp = _G.RXP
    return type(rxp) == "table" and type(rxp.RXPFrame) == "table"
end

function ns.GetGuideQuests()
    local out, seen = {}, {}
    local d = ns.DB()
    if not ns.HasRXP() then return out end
    local steps = _G.RXP.RXPFrame.activeSteps
    if type(steps) ~= "table" then return out end
    local max = d.maxQuests or 3

    local function add(id)
        id = tonumber(id)
        if id and not seen[id] and #out < max and InLog(id) then
            seen[id] = true
            out[#out + 1] = id
        end
    end

    local function scan(wantSticky)
        for _, step in ipairs(steps) do
            if type(step) == "table" and (step.sticky and true or false) == wantSticky
               and type(step.elements) == "table" then
                for _, el in ipairs(step.elements) do
                    if type(el) == "table" and not el.completed and not el.skip and TagWanted(el.tag, d) then
                        if type(el.ids) == "table" then
                            for _, id in pairs(el.ids) do add(id) end
                        else
                            add(el.questId)
                        end
                    end
                end
            end
        end
    end

    scan(false)
    if d.mode == "all" then scan(true) end
    return out
end

-------------------------------------------------------------------------------
--  Tracker blocks
-------------------------------------------------------------------------------
-- Trackers whose blocks share Blizzard's widget pool: never touch them.
local function SharesWidgetPool(t)
    return t == _G.ScenarioObjectiveTracker or t == _G.UIWidgetObjectiveTracker
end

local QUEST_TRACKERS = { "QuestObjectiveTracker", "CampaignQuestObjectiveTracker" }

local function EachTracker(fn)
    local seen = {}
    for _, name in ipairs(QUEST_TRACKERS) do
        local t = _G[name]
        if t and not seen[t] then seen[t] = true; fn(t) end
    end
    local otf = _G.ObjectiveTrackerFrame
    local mods = otf and (otf.modules or otf.MODULES)
    if type(mods) == "table" then
        for _, t in ipairs(mods) do
            if type(t) == "table" and not seen[t] and not SharesWidgetPool(t) then
                seen[t] = true; fn(t)
            end
        end
    end
end

local function EachBlock(fn)
    EachTracker(function(t)
        if type(t.usedBlocks) ~= "table" then return end
        for _, byTemplate in pairs(t.usedBlocks) do
            if type(byTemplate) == "table" then
                for _, block in pairs(byTemplate) do
                    if type(block) == "table" and block.GetObjectType then fn(block) end
                end
            end
        end
    end)
end

-- Title FontString: Blizzard's HeaderText, otherwise the first FontString region
-- (same lookup EllesmereUI uses).
local _titleCache = setmetatable({}, { __mode = "k" })
local function GetTitleFS(block)
    local fs = _titleCache[block]
    if fs then return fs end
    fs = block.HeaderText
    if not (fs and fs.SetTextColor) and block.GetRegions then
        fs = nil
        for _, rg in ipairs({ block:GetRegions() }) do
            if rg.GetObjectType and rg:GetObjectType() == "FontString" then fs = rg; break end
        end
    end
    _titleCache[block] = fs
    return fs
end

-- EllesmereUI's own title color for a quest (used when we stop highlighting).
local function DefaultTitleRGB(questID)
    local eqt = _G.EllesmereUIQuestTracker
    local c = eqt and eqt.DB and eqt.DB()
    if c then
        local superID = C_SuperTrack and C_SuperTrack.GetSuperTrackedQuestID and C_SuperTrack.GetSuperTrackedQuestID()
        if questID and superID == questID and c.focusR then return c.focusR, c.focusG, c.focusB end
        if questID and C_QuestLog.IsComplete and C_QuestLog.IsComplete(questID) and c.completedR then
            return c.completedR, c.completedG, c.completedB
        end
        if c.titleR then return c.titleR, c.titleG, c.titleB end
    end
    return 1, 0.82, 0
end

-------------------------------------------------------------------------------
--  Overlay (our own frame, child of the block so it follows its visibility,
--  alpha and position; never stored on the block itself)
-------------------------------------------------------------------------------
local _overlay  = setmetatable({}, { __mode = "k" })  -- block -> overlay frame
local _rank     = setmetatable({}, { __mode = "k" })  -- block -> rank (1..n) while highlighted
local _hovered  = setmetatable({}, { __mode = "k" })  -- block -> hover hook installed
local WHITE = "Interface\\Buttons\\WHITE8X8"

local function NewTex(f, layer, sub)
    local t = f:CreateTexture(nil, layer, nil, sub or 0)
    t:SetTexture(WHITE)
    return t
end

local function CreateOverlay(block)
    local f = CreateFrame("Frame", nil, block)
    f:EnableMouse(false)
    f.bg  = NewTex(f, "BACKGROUND", -8)
    f.bar = NewTex(f, "BORDER", 0)
    f.edges = {}
    for i = 1, 4 do f.edges[i] = NewTex(f, "BORDER", 1) end

    local ag = f:CreateAnimationGroup()
    ag:SetLooping("BOUNCE")
    local a = ag:CreateAnimation("Alpha")
    a:SetFromAlpha(1); a:SetToAlpha(0.35); a:SetDuration(0.9); a:SetSmoothing("IN_OUT")
    f.pulse = ag
    _overlay[block] = f
    return f
end

local function StyleOverlay(block, f, rank, place)
    local d = ns.DB()
    local r, g, b = ns.GetColor()
    local k = (rank > 1 and d.dimSecondary) and 0.55 or 1

    local px, py = d.padX or 4, d.padY or 2
    f:ClearAllPoints()
    if place then
        place(f, px, py)
    else
        -- Level just under the block so the tint sits behind the text.
        local lvl = block:GetFrameLevel() or 1
        f:SetFrameLevel(math.max(0, lvl - 1))
        f:SetPoint("TOPLEFT", block, "TOPLEFT", -px, py)
        f:SetPoint("BOTTOMRIGHT", block, "BOTTOMRIGHT", px, -py)
    end

    local a = (d.bgAlpha or 0.2) * k
    f.bg:ClearAllPoints()
    f.bg:SetAllPoints(f)
    if d.gradient and f.bg.SetGradient and CreateColor then
        f.bg:SetVertexColor(1, 1, 1, 1)
        f.bg:SetGradient("HORIZONTAL", CreateColor(r, g, b, a), CreateColor(r, g, b, a * 0.15))
    else
        f.bg:SetVertexColor(r, g, b, a)  -- also clears an earlier gradient
    end

    if d.showBar then
        f.bar:ClearAllPoints()
        f.bar:SetPoint("TOPLEFT", f, "TOPLEFT", 0, 0)
        f.bar:SetPoint("BOTTOMLEFT", f, "BOTTOMLEFT", 0, 0)
        f.bar:SetWidth(d.barWidth or 3)
        f.bar:SetVertexColor(r, g, b, 0.95 * k)
        f.bar:Show()
    else
        f.bar:Hide()
    end

    local e = f.edges
    if d.showBorder then
        local ba = (d.borderAlpha or 0.55) * k
        local px1 = (PixelUtil and PixelUtil.GetNearestPixelSize) and PixelUtil.GetNearestPixelSize(1, f:GetEffectiveScale(), 1) or 1
        e[1]:ClearAllPoints(); e[1]:SetPoint("TOPLEFT"); e[1]:SetPoint("TOPRIGHT"); e[1]:SetHeight(px1)
        e[2]:ClearAllPoints(); e[2]:SetPoint("BOTTOMLEFT"); e[2]:SetPoint("BOTTOMRIGHT"); e[2]:SetHeight(px1)
        e[3]:ClearAllPoints(); e[3]:SetPoint("TOPLEFT"); e[3]:SetPoint("BOTTOMLEFT"); e[3]:SetWidth(px1)
        e[4]:ClearAllPoints(); e[4]:SetPoint("TOPRIGHT"); e[4]:SetPoint("BOTTOMRIGHT"); e[4]:SetWidth(px1)
        for i = 1, 4 do e[i]:SetVertexColor(r, g, b, ba); e[i]:Show() end
    else
        for i = 1, 4 do e[i]:Hide() end
    end

    if d.pulse and rank == 1 then
        if not f.pulse:IsPlaying() then f.pulse:Play() end
    elseif f.pulse:IsPlaying() then
        f.pulse:Stop()
    end
    f:Show()
end

local function ApplyTitle(block)
    local rank = _rank[block]
    local fs = GetTitleFS(block)
    if not fs then return end
    local d = ns.DB()
    if rank and d.titleColor then
        local r, g, b = ns.GetColor()
        -- a little lighter than the tint so it reads well on dark backgrounds
        fs:SetTextColor(r + (1 - r) * 0.35, g + (1 - g) * 0.35, b + (1 - b) * 0.35)
    end
end

local _restoreRGB = setmetatable({}, { __mode = "k" })  -- QT title row -> {r,g,b}

local function RestoreTitle(block)
    local fs = GetTitleFS(block)
    if not fs then return end
    local c = _restoreRGB[block]
    if c then fs:SetTextColor(c[1], c[2], c[3]); return end
    local id = type(block.id) == "number" and block.id or nil
    fs:SetTextColor(DefaultTitleRGB(id))
end

-- EllesmereUI recolors the title on hover; our hook runs after theirs.
local function HookHover(block)
    if _hovered[block] or not block.HookScript then return end
    _hovered[block] = true
    local function re() if _rank[block] then ApplyTitle(block) end end
    block:HookScript("OnEnter", re)
    block:HookScript("OnLeave", re)
    if block.HeaderButton and block.HeaderButton.HookScript then
        block.HeaderButton:HookScript("OnEnter", re)
        block.HeaderButton:HookScript("OnLeave", re)
    end
end

-------------------------------------------------------------------------------
--  Refresh
-------------------------------------------------------------------------------
local _autoTracked = {}

local function AutoTrack(ids)
    if not (C_QuestLog and C_QuestLog.AddQuestWatch and C_QuestLog.GetQuestWatchType) then return end
    for _, id in ipairs(ids) do
        if not _autoTracked[id] then
            _autoTracked[id] = true  -- once per session, so un-tracking by hand sticks
            if C_QuestLog.GetQuestWatchType(id) == nil then pcall(C_QuestLog.AddQuestWatch, id) end
        end
    end
end

ns.current = {}
ns.matched = 0

function ns.Refresh(fromTrackerDraw)
    local d = ns.DB()
    local ids = d.enabled and ns.GetGuideQuests() or {}
    ns.current = ids

    local want = {}
    for i, id in ipairs(ids) do want[id] = i end

    local active = {}
    local matched = 0
    EachBlock(function(block)
        local id = type(block.id) == "number" and block.id or nil
        local rank = id and want[id]
        if rank and block:IsShown() then
            active[block] = true
            matched = matched + 1
            local f = _overlay[block] or CreateOverlay(block)
            _rank[block] = rank
            StyleOverlay(block, f, rank)
            HookHover(block)
            ApplyTitle(block)
        end
    end)

    -- War UI Quest Tracker (WarUI_QuestTracker): its own frame, so its title
    -- rows are "blocks" here. The overlay goes on the tracker's scroll child,
    -- across the list's full width, from the title down to the quest's last row.
    local QT = _G.WarUIQuestTracker
    if d.questTracker ~= false and QT and QT.IsActive and QT.IsActive() then
        for _, q in ipairs(QT.Quests()) do
            local rank = want[q.id]
            local row = q.row
            if rank and row and row:IsShown() then
                active[row] = true
                matched = matched + 1
                _titleCache[row] = q.title
                _restoreRGB[row] = { q.r or 1, q.g or 0.82, q.b or 0 }
                local list = row:GetParent()
                local f = _overlay[row]
                if f and f:GetParent() ~= list then f = nil end
                if not f then
                    f = CreateFrame("Frame", nil, list)
                    f:EnableMouse(false)
                    f.bg  = NewTex(f, "BACKGROUND", -8)
                    f.bar = NewTex(f, "BORDER", 0)
                    f.edges = {}
                    for i = 1, 4 do f.edges[i] = NewTex(f, "BORDER", 1) end
                    local ag = f:CreateAnimationGroup()
                    ag:SetLooping("BOUNCE")
                    local a = ag:CreateAnimation("Alpha")
                    a:SetFromAlpha(1); a:SetToAlpha(0.35); a:SetDuration(0.9); a:SetSmoothing("IN_OUT")
                    f.pulse = ag
                    _overlay[row] = f
                end
                _rank[row] = rank
                local last = q.last or row
                StyleOverlay(row, f, rank, function(o, _, py)
                    o:SetFrameLevel(list:GetFrameLevel())
                    o:SetPoint("LEFT", list, "LEFT", 0, 0)
                    o:SetPoint("RIGHT", list, "RIGHT", 0, 0)
                    o:SetPoint("TOP", row, "TOP", 0, py)
                    o:SetPoint("BOTTOM", last, "BOTTOM", 0, -py)
                end)
                ApplyTitle(row)
            end
        end
    end
    ns.matched = matched

    -- Turn off overlays on blocks that no longer show a guide quest
    -- (pooled blocks get reused for other quests).
    for block, f in pairs(_overlay) do
        if not active[block] then
            if f:IsShown() then
                f:Hide()
                if f.pulse:IsPlaying() then f.pulse:Stop() end
            end
            if _rank[block] then
                _rank[block] = nil
                -- A War UI Quest Tracker row that was just redrawn already has
                -- the tracker's own colour (and may now hold another text).
                local qtRow = _restoreRGB[block] ~= nil
                if d.titleColor and not (qtRow and fromTrackerDraw) then RestoreTitle(block) end
            end
        end
    end

    if d.enabled and d.autoTrack and #ids > 0 then AutoTrack(ids) end
end

-- Debounced, always one frame later (never inside Blizzard's own call stack).
local _queued = false
function ns.RequestRefresh()
    if _queued then return end
    _queued = true
    C_Timer.After(0, function()
        _queued = false
        ns.Refresh()
    end)
end
ns.Apply = ns.RequestRefresh

-------------------------------------------------------------------------------
--  Module (War UI General). No tab of its own: drawn on the Quest Tracker tab.
-------------------------------------------------------------------------------
local M = G.RegisterModule("guideHighlight", {
    title       = "Guide Highlight",
    description = "Marks the quest your RestedXP guide step is about in the quest tracker (War UI's or Ellesmere's).",
    pages       = {},
    hostPage    = "questTracker",
    defaults    = ns.DEFAULTS,         -- enabled = true, as when it was its own addon
})
ns.M = M

function M:Enable() ns.RequestRefresh() end
function M:Apply() ns.RequestRefresh() end
function M:Disable() ns.RequestRefresh() end   -- enabled is false now: Refresh clears every overlay

-------------------------------------------------------------------------------
--  Hooks and events
-------------------------------------------------------------------------------
local _hookedTrackers = setmetatable({}, { __mode = "k" })

local function HookTrackers()
    EachTracker(function(t)
        if _hookedTrackers[t] then return end
        _hookedTrackers[t] = true
        if t.Update then hooksecurefunc(t, "Update", ns.RequestRefresh) end
    end)
end

local _qtHooked = false
local function HookQuestTracker()
    local QT = _G.WarUIQuestTracker
    if _qtHooked or not (QT and QT.OnDraw) then return end
    _qtHooked = true
    -- Right after the tracker redraws (it resets its title colours), same frame.
    QT.OnDraw(function() ns.Refresh(true) end)
end

local _rxpHooked = false
local function HookRXP()
    if _rxpHooked or not ns.HasRXP() then return end
    local rxp = _G.RXP
    if type(rxp.SetStep) == "function" then
        hooksecurefunc(rxp, "SetStep", ns.RequestRefresh)
        _rxpHooked = true
    end
    if type(rxp.UpdateStepCompletion) == "function" then
        hooksecurefunc(rxp, "UpdateStepCompletion", ns.RequestRefresh)
    end
end

local ev = CreateFrame("Frame")
ev:RegisterEvent("PLAYER_LOGIN")
ev:RegisterEvent("PLAYER_ENTERING_WORLD")
ev:RegisterEvent("QUEST_LOG_UPDATE")
ev:RegisterEvent("QUEST_WATCH_LIST_CHANGED")
ev:RegisterEvent("SUPER_TRACKING_CHANGED")
ev:RegisterEvent("QUEST_ACCEPTED")
ev:RegisterEvent("QUEST_REMOVED")
ev:SetScript("OnEvent", function(_, event)
    if event == "PLAYER_LOGIN" then
        ns.DB()
        HookTrackers()
        HookRXP()
        HookQuestTracker()
        -- Safety net: RXP finishes steps from many places; 1 s is cheap.
        C_Timer.NewTicker(1, function()
            if not ns.DB().enabled and not next(_rank) then return end
            ns.Refresh()
        end)
    elseif event == "PLAYER_ENTERING_WORLD" then
        C_Timer.After(1, function() HookTrackers(); HookRXP(); ns.Refresh() end)
    end
    ns.RequestRefresh()
end)

-------------------------------------------------------------------------------
--  Slash
-------------------------------------------------------------------------------
local function QuestName(id)
    local t = C_QuestLog.GetTitleForQuestID and C_QuestLog.GetTitleForQuestID(id)
    return t or ("quest " .. id)
end
ns.QuestName = QuestName

SLASH_WARUIGUIDEHL1 = "/guidehl"
SLASH_WARUIGUIDEHL2 = "/guidehighlight"
SlashCmdList.WARUIGUIDEHL = function(msg)
    msg = (msg or ""):lower():match("^%s*(.-)%s*$")
    local d = ns.DB()
    if msg == "toggle" or msg == "on" or msg == "off" then
        if not G.db then return end
        local on
        if msg == "toggle" then on = not G.IsModuleEnabled("guideHighlight") else on = (msg == "on") end
        G.SetModuleEnabled("guideHighlight", on)
        print("|cff66ccffGuide Highlight:|r " .. (G.IsModuleEnabled("guideHighlight") and "on" or "off"))
    elseif msg == "debug" then
        ns.Refresh()
        print("|cff66ccffGuide Highlight:|r RestedXP " .. (ns.HasRXP() and "found" or "NOT found") ..
              ", " .. #ns.current .. " guide quest(s), " .. ns.matched .. " tracker block(s) highlighted.")
        for i, id in ipairs(ns.current) do print(("  %d. [%d] %s"):format(i, id, QuestName(id))) end
        local n = 0
        EachBlock(function(b) if type(b.id) == "number" then n = n + 1 end end)
        print("  Quest blocks in the tracker: " .. n)
        local QT = _G.WarUIQuestTracker
        if QT and QT.IsActive() then print("  War UI Quest Tracker: on, " .. #QT.Quests() .. " quest(s) shown") end
    else
        G.Options.Open("guideHighlight")
    end
end
