-------------------------------------------------------------------------------
--  WarUI_General / Modules / RareScannerMap.lua
--  Skulls on the world map where rares can spawn (QuestieDB_Forever spawn
--  points). Hover: name, level, type, last seen / last killed and the
--  respawn time learned from your own sightings. Click: point the Rare
--  Scanner arrow at that spawn point.
--  Same MapCanvas data provider pattern as WarUI_ProfessionMap.
-------------------------------------------------------------------------------
local G  = WarUIGeneral
local ns = G.RareScanner
local RARES = ns.RARES or {}

local TEMPLATE  = "WarUIRareScannerPinTemplate"
local SKULL_TEX = "Interface\\TargetingFrame\\UI-TargetingFrame-Skull"
local RING_TEX  = "Interface\\AddOns\\WarUI_General\\Media\\RareScanner\\glow.png"

local function DB() return ns.DB() end

local function Ago(sec)
    if sec < 60 then return "just now" end
    if sec < 3600 then return string.format("%d min ago", math.floor(sec / 60)) end
    if sec < 86400 then return string.format("%dh %dm ago", math.floor(sec / 3600), math.floor(sec % 3600 / 60)) end
    return string.format("%d days ago", math.floor(sec / 86400))
end

local function Span(sec)
    sec = math.max(0, math.floor(sec))
    if sec < 3600 then return string.format("%d min", math.max(1, math.floor(sec / 60 + 0.5))) end
    return string.format("%dh %02dm", math.floor(sec / 3600), math.floor(sec % 3600 / 60))
end

-- Level colour like the game's difficulty colours (GetQuestDifficultyColor).
local function LevelColor(level)
    if GetQuestDifficultyColor and level and level > 0 then
        local ok, c = pcall(GetQuestDifficultyColor, level)
        if ok and c then return c.r, c.g, c.b end
    end
    return 1, 1, 1
end

-------------------------------------------------------------------------------
--  Pin
-------------------------------------------------------------------------------
WarUIRareScannerPinMixin = CreateFromMixins(MapCanvasPinMixin)

function WarUIRareScannerPinMixin:Build()
    if self._built then return end
    self._built = true
    self.glow = self:CreateTexture(nil, "BACKGROUND")
    self.glow:SetTexture(RING_TEX)
    self.glow:SetPoint("CENTER")
    self.glow:SetBlendMode("ADD")
    self.icon = self:CreateTexture(nil, "ARTWORK")
    self.icon:SetTexture(SKULL_TEX)
    self.icon:SetPoint("CENTER")
    self:SetScript("OnEnter", self.OnMouseEnter)
    self:SetScript("OnLeave", self.OnMouseLeave)
    self:SetScript("OnMouseUp", self.OnClick)
end

function WarUIRareScannerPinMixin:OnAcquired(pin)
    self:Build()
    pcall(self.UseFrameLevelType, self, "PIN_FRAME_LEVEL_AREA_POI")
    pcall(self.SetScalingLimits, self, 1, 1.0, 1.25)
    self.pin = pin
    self:ApplyLook()
    self:SetPosition(pin.x / 100, pin.y / 100)
    self:Show()
end

function WarUIRareScannerPinMixin:OnReleased()
    self.pin = nil
    if GameTooltip:GetOwner() == self then GameTooltip:Hide() end
end

function WarUIRareScannerPinMixin:ApplyLook()
    local d, p = DB(), self.pin
    local size = (d and d.pinSize) or 16
    local rec = RARES[p.id]
    local live = ns.IsActive and ns.IsActive(p.id)
    self:SetSize(size + 4, size + 4)
    self.icon:SetSize(size, size)
    if live then
        self.icon:SetVertexColor(1, 0.25, 0.2)            -- up right now: red
    elseif rec and rec[4] then
        self.icon:SetVertexColor(1, 0.78, 0.2)            -- rare elite: gold
    else
        self.icon:SetVertexColor(0.85, 0.88, 1)           -- rare: silver
    end
    self.glow:SetSize(size * 2.2, size * 2.2)
    if live then self.glow:SetVertexColor(1, 0.2, 0.1); self.glow:SetAlpha(0.9)
    else self.glow:SetVertexColor(0, 0, 0); self.glow:SetAlpha(0) end
end

function WarUIRareScannerPinMixin:OnMouseEnter()
    local p = self.pin
    local rec = p and RARES[p.id]
    if not rec then return end
    GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
    if rec[4] then GameTooltip:AddLine(rec[1], 1, 0.78, 0.2) else GameTooltip:AddLine(rec[1], 0.85, 0.88, 1) end
    local lvl = rec[2] == rec[3] and tostring(rec[2]) or (rec[2] .. "-" .. rec[3])
    local r, g, b = LevelColor(rec[3])
    GameTooltip:AddDoubleLine((rec[4] and "Rare Elite" or "Rare"), "Level " .. lvl, 1, 1, 1, r, g, b)
    if ns.IsActive and ns.IsActive(p.id) then
        GameTooltip:AddLine("UP NOW - on your Rare Scanner alert", 1, 0.3, 0.2)
    end
    if p.total > 1 then
        GameTooltip:AddLine(string.format("Spawn point %d of %d (it can be at any of them)", p.index, p.total), 0.7, 0.7, 0.7)
    end

    -- Timer: the data has no respawn times, so they are learned from sightings.
    local h = ns.History and ns.History(p.id)
    local now = time()
    GameTooltip:AddLine(" ")
    if h and h.seen then GameTooltip:AddDoubleLine("Last seen", Ago(now - h.seen), 0.8, 0.8, 0.8, 1, 1, 1) end
    if h and h.killed then GameTooltip:AddDoubleLine("Last seen dead", Ago(now - h.killed), 0.8, 0.8, 0.8, 1, 1, 1) end
    if h and h.respawn then
        GameTooltip:AddDoubleLine("Respawn (observed)", "about " .. Span(h.respawn), 0.8, 0.8, 0.8, 0.4, 1, 0.4)
        if h.killed and not h.counted then
            local left = h.killed + h.respawn - now
            if left > 0 then
                GameTooltip:AddDoubleLine("Next spawn", "in about " .. Span(left), 0.8, 0.8, 0.8, 1, 0.82, 0.1)
            else
                GameTooltip:AddDoubleLine("Next spawn", "could be up now", 0.8, 0.8, 0.8, 0.4, 1, 0.4)
            end
        end
    else
        GameTooltip:AddDoubleLine("Respawn", "unknown yet", 0.8, 0.8, 0.8, 0.6, 0.6, 0.6)
        GameTooltip:AddLine("Learned when you see it dead and later alive again.", 0.5, 0.5, 0.5, true)
    end
    if h and h.count and h.count > 0 then
        GameTooltip:AddDoubleLine("Times seen dead", tostring(h.count), 0.8, 0.8, 0.8, 1, 1, 1)
    end

    GameTooltip:AddLine(" ")
    GameTooltip:AddLine(string.format("%.1f, %.1f", p.x, p.y), 0.5, 0.5, 0.5)
    GameTooltip:AddLine("Click: point the arrow here", 0.4, 0.8, 1)
    GameTooltip:Show()
    local s = (DB() and DB().pinSize or 16) * 1.25
    self.icon:SetSize(s, s)
end

function WarUIRareScannerPinMixin:OnMouseLeave()
    GameTooltip:Hide()
    local s = DB() and DB().pinSize or 16
    self.icon:SetSize(s, s)
end

function WarUIRareScannerPinMixin:OnClick(button)
    local p = self.pin
    if button == "LeftButton" and p and ns.PointAt then ns.PointAt(p.id, p.map, p.x, p.y) end
end

-------------------------------------------------------------------------------
--  Data provider
-------------------------------------------------------------------------------
local Provider = CreateFromMixins(MapCanvasDataProviderMixin)
ns.Provider = Provider
ns.pinCount = 0

function Provider:RemoveAllData()
    local map = self:GetMap()
    if map then map:RemoveAllPinsByTemplate(TEMPLATE) end
end

function Provider:RefreshAllData()
    self:RemoveAllData()
    ns.pinCount = 0
    local map = self:GetMap()
    local d = DB()
    if not map or not d or not G.IsModuleEnabled("rareScanner") or not d.mapPins then return end
    local mapID = map:GetMapID()
    if not mapID then return end
    for id, rec in pairs(RARES) do
        local pts = rec[6] and rec[6][mapID]
        if pts and (d.mapElites or not rec[4])
           and not (d.mapHideIgnored and ns.IsIgnored and ns.IsIgnored(id, rec[1])) then
            local total = math.floor(#pts / 2)
            for i = 1, #pts - 1, 2 do
                map:AcquirePin(TEMPLATE, { id = id, map = mapID, x = pts[i], y = pts[i + 1],
                    index = (i + 1) / 2, total = total })
                ns.pinCount = ns.pinCount + 1
            end
        end
    end
end

local pending = false
function ns.MapRefresh()
    if pending or not ns.providerAdded then return end
    pending = true
    C_Timer.After(0, function()
        pending = false
        if WorldMapFrame and WorldMapFrame:IsShown() then pcall(Provider.RefreshAllData, Provider) end
    end)
end

function ns.AttachToMap()
    if ns.providerAdded then return end
    if not (WorldMapFrame and WorldMapFrame.AddDataProvider and MapCanvasDataProviderMixin) then return end
    WorldMapFrame:AddDataProvider(Provider)
    ns.providerAdded = true
end

-- Blizzard_WorldMap can load late; attach when it does.
local f = CreateFrame("Frame")
f:RegisterEvent("PLAYER_LOGIN")
f:RegisterEvent("ADDON_LOADED")
f:SetScript("OnEvent", function(self, event, name)
    if event == "ADDON_LOADED" and name ~= "Blizzard_WorldMap" then return end
    if ns.providerAdded then self:UnregisterAllEvents(); return end
    pcall(ns.AttachToMap)
    if ns.providerAdded then self:UnregisterAllEvents() end
end)
