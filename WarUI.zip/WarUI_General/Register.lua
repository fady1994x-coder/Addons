-- WarUI_General / Register.lua - the last file in the toc.
-- Every module file has registered now: hand the sidebar rows (General, then
-- one per module that is on) to the War UI hub, which gives them to
-- Ellesmere at PLAYER_LOGIN.
local _, ns = ...

ns.Options.Finish()

-- War UI 3.0: Menu Bar was replaced by Microbar (from ProseccoAdditions).
-- Runs at PLAYER_LOGIN before the profiles are filled (Core.lua boot): the
-- Microbar takes Menu Bar's on/off once, then Menu Bar's settings go.
function ns.MigrateProfiles()
    for _, prof in pairs(type(WarUIGeneralDB) == "table" and WarUIGeneralDB.profiles or {}) do
        local mods = type(prof) == "table" and prof.modules
        if type(mods) == "table" and type(mods.menuBar) == "table" then
            if type(mods.volume) ~= "table" then mods.volume = {} end
            if mods.volume.enabled == nil then mods.volume.enabled = mods.menuBar.enabled == true end
            mods.menuBar = nil
        end
    end
end

-- Menu Bar had set Ellesmere Action Bars' "Micro Menu Bar" and "Bag Bar" to
-- Visibility Never and kept the old values in WarUIGeneralDB.owned.menuBar.vis.
-- Give them back once (Microbar hides Blizzard's micro menu its own way;
-- the bag bar is Blizzard's/Ellesmere's again), then forget them.
local function GiveBackMenuBar()
    local owned = type(WarUIGeneralDB) == "table" and WarUIGeneralDB.owned
    local store = owned and owned.menuBar
    if type(store) ~= "table" then return end
    if type(store.vis) == "table" then
        local mns = EllesmereUI and EllesmereUI._ModuleNS and EllesmereUI._ModuleNS.EllesmereUIActionBars
        local eab = mns and mns.EAB
        if not (eab and eab.db and eab.db.profile and type(eab.db.profile.bars) == "table"
                and eab.VisibilityCompat and eab.VisibilityCompat.ApplyMode) then
            return      -- Ellesmere Action Bars not loaded: try again next login
        end
        for key, mode in pairs(store.vis) do
            local s = eab.db.profile.bars[key]
            if s then pcall(eab.VisibilityCompat.ApplyMode, s, mode) end
        end
        if eab.RefreshRuntimeVisibility then pcall(eab.RefreshRuntimeVisibility, eab) end
        ns.Print("Menu Bar was replaced by Microbar: Ellesmere's Micro Menu and Bag Bar visibility is back to how it was.")
    end
    owned.menuBar = nil
end

local menuBarCleanup = CreateFrame("Frame")
menuBarCleanup:RegisterEvent("PLAYER_LOGIN")
menuBarCleanup:SetScript("OnEvent", function(self, event)
    if event == "PLAYER_LOGIN" then
        self:UnregisterEvent("PLAYER_LOGIN")
        C_Timer.After(1, function()
            if InCombatLockdown() then
                self:RegisterEvent("PLAYER_REGEN_ENABLED")
            else
                xpcall(GiveBackMenuBar, ns.ErrorHandler("register:menuBar"))
            end
        end)
    else
        self:UnregisterEvent("PLAYER_REGEN_ENABLED")
        xpcall(GiveBackMenuBar, ns.ErrorHandler("register:menuBar"))
    end
end)

-- War UI 2.0 folded these addons into WarUI_General. If one of the old
-- folders still loads, everything it does would run twice.
local OLD = { "WarUI_Campfire", "WarUI_Chat", "WarUI_QuestTracker", "WarUI_RXPTheme",
              "WarUI_GuideHighlight", "WarUI_ClickTweak" }
local f = CreateFrame("Frame")
f:RegisterEvent("PLAYER_LOGIN")
f:SetScript("OnEvent", function(self)
    self:UnregisterAllEvents()
    local found = {}
    for _, name in ipairs(OLD) do
        if C_AddOns.IsAddOnLoaded(name) then found[#found + 1] = name end
    end
    if #found > 0 then
        ns.Print("these old addons are now part of War UI - General and should be deleted from your AddOns folder: "
            .. table.concat(found, ", ") .. ". Disable them and /reload.")
    end
end)

-- War UI 2.2: Campfire and Raid Mana % were removed. Raid Mana % had set
-- Ellesmere Raid Frames' Power Text to "Percent" and kept the old value in
-- WarUIGeneralDB.owned.raidMana: give it back once, then forget it.
local cleanup = CreateFrame("Frame")
cleanup:RegisterEvent("PLAYER_LOGIN")
cleanup:SetScript("OnEvent", function(self)
    self:UnregisterAllEvents()
    local owned = type(WarUIGeneralDB) == "table" and WarUIGeneralDB.owned
    local store = owned and owned.raidMana
    if type(store) == "table" and store.saved then
        local eui = _G.EllesmereUI
        local rf = eui and eui._ModuleNS and eui._ModuleNS.EllesmereUIRaidFrames
        local p = rf and rf.db and rf.db.profile
        if p then
            p.powerTextMode = store.old and store.old.powerTextMode
            p.party_powerTextMode = store.old and store.old.party_powerTextMode
            if not InCombatLockdown() then
                if rf.ReloadFrames then pcall(rf.ReloadFrames) end
                if rf.ReloadPartyFrames then pcall(rf.ReloadPartyFrames) end
            end
            ns.Print("Raid Mana % was removed: Ellesmere's raid frame Power Text is back to how it was.")
        end
    end
    if owned then owned.raidMana = nil end
    -- Old module settings left in the profiles (harmless, just tidied).
    for _, prof in pairs(type(WarUIGeneralDB) == "table" and WarUIGeneralDB.profiles or {}) do
        if type(prof) == "table" and type(prof.modules) == "table" then
            prof.modules.campfire = nil
            prof.modules.raidMana = nil
        end
    end
end)
