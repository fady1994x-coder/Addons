# War UI – General

**Version 3.0.0** · World of Warcraft Classic (Interface 16001) · by Fady

War UI – General puts all the War UI modules into one addon: Chat, Click Cast, Loot, Microbar, Minimap, Quest Tracker (with Guide Highlight), Rare Scanner, an RXP Theme and an XP Bar. Each module is switched on and off on **EllesmereUI → War UI → General**, and every module that is on gets its own row in the sidebar under War UI (after a reload).

> Chat, Quest Tracker, RXP Theme and Click Cast are based on Prosecco UI / ClickTweak by Alexander.
> Microbar (with its volume popup and icons in `Media/MicroMenu`), Minimap and XP Bar come from **ProseccoAdditions 0.7.0-alpha1 by proseccopappa**, licensed CC BY-NC-SA 4.0 (https://creativecommons.org/licenses/by-nc-sa/4.0/): used with credit, non-commercially, and this changed version is shared under the same licence.

## War UI 3.0 (2026-10-16)

- New modules from ProseccoAdditions: **Microbar** (replaces Menu Bar), **Minimap** (zone panel over the map, clock/FPS/latency under it, own minimap buttons), **XP Bar** (XP, quest XP, rested, info panel with XP/hour and time to level). All three are on by default.
- Menu Bar is removed. Its on/off carries over to Microbar once, and Ellesmere's Micro Menu / Bag Bar visibility that Menu Bar had set to Never is given back.
- Settings laid out as ProseccoAdditions: War UI > **General** (General | Global Settings | Profiles), then one sidebar row per module that is on, then Click Cast.
- Global Settings: global border, Global Background, Global Header Background and Global Header Texture.
- War UI icon in the AddOns list for every War UI addon (`WarUI/Media/WarUI-Icon.tga`).

---

## Requirements

| Type | Addon |
|---|---|
| **Required** | EllesmereUI, **WarUI** (the War UI hub addon) |
| Optional | Questie, RestedXP Guides (RXPGuides), EllesmereUI Raid Frames / Chat / Quest Tracker, TomTom |

## Installation

1. Download or clone this repository.
2. Copy the `WarUI_General` folder into  
   `World of Warcraft\_classic_\Interface\AddOns\`
3. Make sure **EllesmereUI** and **WarUI** are installed too.
4. Start the game, or `/reload` if it was already running. Fully restart the game the first time so the fonts load.
5. Open the settings with `/pui` (or `/waruigeneral`), or go to **EllesmereUI → War UI → General**.

> **Upgrading from War UI 1.x?** The old separate addons (`WarUI_Chat`, `WarUI_QuestTracker`, `WarUI_RXPTheme`, `WarUI_GuideHighlight`, `WarUI_ClickTweak`, `WarUI_Campfire`) are now part of this addon. Delete them from your AddOns folder. If any of them still load, the addon warns you at login.

---

## Modules

Every module is **off by default**. Switch on the ones you want on the **General** tab. Some modules need a reload to switch on or off: flip all the switches you want, then press **Reload UI** once.

### 💬 Chat
Adds panels around EllesmereUI's chat and its tabs.
- Separate background and border for the chat text and for the tab row
- Adjustable **Tab Gap**, **Tab Height** and **Tab Seam**
- Optional **Classic Chat Style**
- **Set Ellesmere Values** applies the Ellesmere chat settings these panels need (background opacity 0, borders hidden, transparent tabs). Your own chat settings and frames are left alone.

### 🖱️ Click Cast (ClickTweak)
Click-casting and hover keybinds for **EllesmereUI party and raid frames** (player, target and focus frames are never touched).
- Bind any mouse button, keyboard key or mouse wheel, with Shift/Ctrl/Alt modifiers
- Actions: target, focus, assist, menu, spells, items or custom macros
- Per-binding options: **Only Cast Out of Combat**, **Active In** (Solo / Party / Raid / PvP) and **Dynamic Rez** (resurrects a dead player, otherwise casts the spell)
- Profiles: new, copy, delete, reset, import and export
- Has its own saved data (`ClickTweakProfilesDB`, `ClickTweakDB`), separate from the War UI profiles

### 🎲 Loot
Replaces Blizzard's Need/Greed popups with ElvUI-style roll bars.
- Each button (Need / Greed / Disenchant / Pass) shows how many players picked it
- Hover a button to see who picked it (class coloured, with their roll)
- Timer bar in the item's quality colour, plus a BoE tag
- Shows the winner when the roll ends ("Player won – Item")
- Options: hide the bar after you roll, bar texture and opacity, background, movable position
- Works in every client language and works in combat
- *Needs a reload to switch on or off*

### 📋 Menu Bar
Combines Blizzard's micro menu and bag bar into one flat bar in Ellesmere's style.
- Every micro button works in combat (Character, Spellbook, Talents, Quests, Social, LFG, Map, Menu, Help…)
- One **bag button** that shows your free slots:
  - Left-click: open all bags (Ellesmere Bags, Bagnon or Blizzard's bags)
  - Right-click (or Shift-click): keyring
  - Drop an item on it to put it in your backpack
- Optional: show the four bag slots next to it
- Custom icons with selectable icon style and color
- Can be moved in Ellesmere's **Unlock Mode**

### 📜 Quest Tracker
War UI's own quest tracker, built on Blizzard's quest log. It replaces the Ellesmere and Questie trackers.
- Header with your quest log count and the progress of your current **RestedXP guide**
- Quests grouped by zone. With an RXP guide loaded, the quests the guide uses are shown first
- Clickable quest item buttons (they also work in combat)
- Choose where completed quests go: top, bottom or stay in place
- Font, outline, background, border and a custom "completed" text
- Can be moved in Unlock Mode
- When switched on, it hides the Ellesmere and Questie trackers. Ellesmere's quest features (auto-accept, auto-turn-in) keep working. Use **Set Values Again** if an import changed those settings.

#### ✨ Guide Highlight (inside the Quest Tracker tab)
Highlights the quest that your **current RestedXP guide step** refers to, in War UI's tracker or Ellesmere's.
- Color presets: Ellesmere Accent, Ice Blue, Light Blue, Sky Blue, Teal or a custom hex color
- Choose which steps count, with a live preview

### 💀 Rare Scanner
Alerts you when a rare or rare elite shows up, with an arrow pointing to it.
- Finds rares through nameplates, your target, mouseover and minimap skull icons. Each source can be turned off.
- Built-in database of **~400 rares** (from QuestieDB) with their spawn points
- The arrow points at the most accurate position it has: the skull icon, then the nameplate, then the nearest known spawn point, then where you last saw the rare
- Sound alert (raid warning by default) and screen flash
- **World map skulls** at rare spawn points. Hover for name, level, last seen / last killed and the respawn time learned from your own sightings. Click one to point the arrow there.
- Optional **TomTom waypoint**
- Ignore list for rares you don't care about

### 🧭 RXP Theme
A **"Prosecco"** theme for RestedXP Guides. Pick it in RXP's own theme list.
- Flat custom artwork, colors, font and outline
- Separate backgrounds for the header, step list, footer and step boxes, with the War UI border
- Options: hide logos / version text, centered title, footer only on mouseover, header extend/overlap, paddings, arrow texture (Prosecco / Prosecco Bordered)
- *Needs a reload to switch off*

---

## Shared features

- **Global border:** one border style (style, size, color, opacity) used by every module unless a module sets its own
- **Profiles:** per-character profiles, plus export and import of the active profile as text
- **Prosecco fonts:** 7 weights (ExtraLight → Bold, plus Caps) added to every EllesmereUI / SharedMedia font dropdown
- **Settings auto-repair:** at login, Chat and Quest Tracker re-apply the Ellesmere settings they need (for example after an EllesmereUI profile import), reloading once if needed
- **Error isolation:** if one module breaks, the others keep running. Errors are written to a debug log.

---

## Slash commands

| Command | What it does |
|---|---|
| `/pui` or `/waruigeneral` | Open the settings |
| `/pui profile` | Profile commands |
| `/pui log [n \| clear \| on \| off]` | Show / manage the debug log |
| `/pui mark <text>` | Add a marker to the log (then `/reload`) |
| `/waruiloot test \| move \| reset` | Test roll bars, move them, reset their position |
| `/waruimenu move \| reset \| debug` | Move / reset / debug the Menu Bar |
| `/rare` or `/rarescanner` | `test`, `nearest`, `clear`, `on` / `off` / `toggle`, `move`, `ignore <name>` |
| `/guidehl` or `/guidehighlight` | `on` / `off` / `toggle`, `debug` |
| `/clicktweak` | Click Cast commands |

---

## Folder structure

```
WarUI_General/
├── WarUI_General.toc
├── Register.lua          # Hands the "General" page to the War UI hub; cleanup of old addons
├── Core/                 # Saved data & profiles, module registry, options page, borders, media, log
├── Integrations/         # The only files that touch EllesmereUI, RestedXP and Questie
├── Modules/              # Chat, Loot, MenuBar, QuestTracker, GuideHighlight, RareScanner, RXPTheme, ClickTweak/
└── Media/                # Prosecco fonts, menu bar icons, RXP theme textures, rare scanner art
```

`Modules/Campfire.lua`, `CampfireOptions.lua` and `RaidMana.lua` are leftovers. Those modules were removed in 2.2.0, so the files can be deleted.

## Saved variables

- `WarUIGeneralDB`: War UI profiles, module settings, debug log (account-wide)
- `ClickTweakProfilesDB`: Click Cast profiles (account-wide)
- `ClickTweakDB`: Click Cast per-character data

## Credits

- **Fady**: War UI, Loot, Menu Bar, Rare Scanner, Guide Highlight
- **Alexander**: Prosecco UI and ClickTweak, which Chat, Quest Tracker, RXP Theme and Click Cast are based on
- Rare data generated from **QuestieDB**
- RXP theme artwork is original (RestedXP's art is CC BY-NC-SA and is not copied)
