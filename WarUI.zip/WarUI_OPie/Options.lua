-------------------------------------------------------------------------------
--  War UI - OPie / Options.lua
--  Puts OPie under War UI in the EllesmereUI panel (through WarUI.AddModule).
--
--  OPie itself stays in its own folder (AddOns\OPie) and keeps working exactly
--  as before. This module only uses OPie's public API (_G.OPie):
--    OPie:GetVersion(), OPie:GetCurrentProfile(), OPie:IterateRings(),
--    OPie:GetRingInfo(), and the "hidden" OPie:GetOption()/GetRingBinding()
--  (read-only, wrapped in pcall in case a future OPie removes them).
--  OPie has no public way to CHANGE its options, so the buttons here open
--  OPie's own settings pages (the same as /opie opt, /opie bind, ...).
-------------------------------------------------------------------------------
local ADDON, ns = ...

local PLUGIN_ID  = "WarUI"
local MODULE_KEY = "OPie"
local RING_ICON  = [[Interface\AddOns\OPie\gfx\opie_ring_icon]]

local showInternal = false   -- "Show built-in rings" toggle (session only)

-------------------------------------------------------------------------------
--  OPie access (all protected)
-------------------------------------------------------------------------------
local function OP() return _G.OPie end

-- Returns the results of a pcall without the leading "ok" (nothing on error).
function ns.PassOK(ok, ...)
    if ok then return ... end
end

local function Call(method, ...)
    local api = OP()
    if not (api and api[method]) then return end
    return ns.PassOK(pcall(api[method], api, ...))
end

local function GetOption(option, ring)
    return (Call("GetOption", option, ring))
end

-- Run one of OPie's /opie sub-commands (opens its settings pages).
local function OPieSlash(args)
    if InCombatLockdown() then
        print("|cffc0392bWar UI:|r OPie settings can't be opened in combat.")
        return
    end
    if EllesmereUI and EllesmereUI.IsShown and EllesmereUI:IsShown() then
        EllesmereUI:Hide()
    end
    C_Timer.After(0, function()
        if args == "home" and type(_G.OPie_OpenSettings) == "function" then
            _G.OPie_OpenSettings()
        elseif SlashCmdList and SlashCmdList.OPIE then
            SlashCmdList.OPIE(args or "")
        end
    end)
end
ns.OPieSlash = OPieSlash

-------------------------------------------------------------------------------
--  Page helpers (same look as the other War UI modules)
-------------------------------------------------------------------------------
local function Refresh()
    C_Timer.After(0, function()
        local key = EllesmereUI.GetPluginModuleKey(PLUGIN_ID, MODULE_KEY)
        if not key then return end
        EllesmereUI:InvalidateModulePageCache(key)
        if EllesmereUI:GetActiveModule() == key then
            EllesmereUI:RefreshPage(true)
        end
    end)
end

local function Pad() return EllesmereUI.CONTENT_PAD or 20 end

local function Label(parent, text, size, r, g, b, a)
    local fs = EllesmereUI.MakeFont(parent, size or 12, nil, r or 1, g or 1, b or 1, a or 1)
    fs:SetJustifyH("LEFT")
    fs:SetText(text)
    return fs
end

local function Paragraph(parent, text, y, alpha)
    local w = parent:GetWidth() - Pad() * 2
    local fs = Label(parent, text, 12, 1, 1, 1, alpha or 0.7)
    fs:SetWidth(w - 20)
    fs:SetSpacing(4)
    fs:SetPoint("TOPLEFT", parent, "TOPLEFT", Pad() + 10, y - 6)
    return y - (fs:GetStringHeight() or 40) - 16
end

local function Accent()
    local c = EllesmereUI.ELLESMERE_GREEN or { r = 0.05, g = 0.82, b = 0.62 }
    return c.r, c.g, c.b
end

-- A row: optional icon, name, grey sub text, value on the right or a button.
local function Row(parent, y, icon, text, sub, rightText, btnText, onClick, shade)
    local w = parent:GetWidth() - Pad() * 2
    local row = CreateFrame("Frame", nil, parent)
    row:SetSize(w, 34)
    row:SetPoint("TOPLEFT", parent, "TOPLEFT", Pad(), y)
    local bg = row:CreateTexture(nil, "BACKGROUND")
    bg:SetAllPoints()
    bg:SetColorTexture(1, 1, 1, shade and 0.03 or 0.015)

    local x = 12
    if icon then
        local t = row:CreateTexture(nil, "ARTWORK")
        t:SetSize(22, 22)
        t:SetPoint("LEFT", row, "LEFT", 12, 0)
        t:SetTexture(icon)
        x = 42
    end
    local name = Label(row, text, 13, 1, 1, 1, 1)
    name:SetPoint("LEFT", row, "LEFT", x, 0)
    if sub and sub ~= "" then
        local s = Label(row, sub, 11, 1, 1, 1, 0.5)
        s:SetPoint("LEFT", name, "RIGHT", 10, 0)
    end

    local rightAnchor, rightX = row, -12
    if btnText then
        local r, g, b = Accent()
        local btn = CreateFrame("Button", nil, row)
        btn:SetSize(80, 22)
        btn:SetPoint("RIGHT", row, "RIGHT", -8, 0)
        btn:SetFrameLevel(row:GetFrameLevel() + 2)
        local bbg = btn:CreateTexture(nil, "BACKGROUND")
        bbg:SetAllPoints()
        bbg:SetColorTexture(r, g, b, 0.7)
        local bl = Label(btn, btnText, 12, 1, 1, 1, 1)
        bl:SetPoint("CENTER")
        btn:SetScript("OnEnter", function() bbg:SetColorTexture(r, g, b, 1) end)
        btn:SetScript("OnLeave", function() bbg:SetColorTexture(r, g, b, 0.7) end)
        btn:SetScript("OnClick", onClick)
        rightAnchor, rightX = btn, -96
    end
    if rightText then
        local v = Label(row, rightText, 12, 1, 1, 1, 0.9)
        v:SetJustifyH("RIGHT")
        v:SetPoint("RIGHT", row, "RIGHT", rightX, 0)
    end
    return y - 36
end

local function YesNo(v)
    if v == nil then return "|cff808080-|r" end
    return v and "|cff40ff70On|r" or "|cffff6060Off|r"
end

-------------------------------------------------------------------------------
--  Page: General
-------------------------------------------------------------------------------
local INTERACTION = { "Quick", "Relaxed", "Mouse-less" }

-- Options shown read-only. Ones OPie doesn't know (older/newer OPie) are skipped.
local SUMMARY = {
    { "InteractionMode", "Interaction Mode", function(v) return INTERACTION[v] or tostring(v) end },
    { "RingScale", "Ring Scale", function(v) return ("%.1f"):format(v) end },
    { "RingAtMouse", "Open Rings at the Mouse", YesNo },
    { "QuickActionOnRelease", "Quick Action on Release", YesNo },
    { "ClickPriority", "Block Other UI While a Ring Is Open", YesNo },
    { "UseDefaultBindings", "Use Default Ring Bindings", YesNo },
    { "SliceBinding", "Per-Slice Bindings", YesNo },
    { "ShowCooldowns", "Cooldown Numbers", YesNo },
    { "ShowShortLabels", "Slice Labels", YesNo },
    { "XTAnimation", "Animate Transitions", YesNo },
    { "MIScale", "Enlarge Selected Slice", YesNo },
}

local function BuildGeneralPage(parent, yOffset)
    local W = EllesmereUI.Widgets
    local y = yOffset
    local _, h

    _, h = W:SectionHeader(parent, "OPIE", y); y = y - h
    if not OP() then
        y = Paragraph(parent, "|cffff6060OPie isn't loaded.|r Check that the OPie addon is enabled on the character select screen.", y, 1)
        return math.abs(y)
    end

    local version = Call("GetVersion") or "?"
    local profile = Call("GetCurrentProfile") or "default"
    local rings = 0
    local iter = Call("IterateRings", false)
    if iter then for _ in iter do rings = rings + 1 end end
    y = Paragraph(parent, ("OPie %s  ·  Profile: |cffffffff%s|r  ·  %d rings.\nHold a ring's binding to open it, release (or click) to use the slice under the pointer."):format(version, profile, rings), y)

    _, h = W:WideButton(parent, "Open OPie Settings", y, function() OPieSlash("home") end, 300); y = y - h
    _, h = W:WideButton(parent, "Options (behavior & look)", y, function() OPieSlash("opt") end, 300); y = y - h
    _, h = W:WideButton(parent, "Ring Bindings", y, function() OPieSlash("bind") end, 300); y = y - h
    _, h = W:WideButton(parent, "Custom Rings (create & edit)", y, function() OPieSlash("custom") end, 300); y = y - h
    _, h = W:WideButton(parent, "In-Ring Bindings", y, function() OPieSlash("irbind") end, 300); y = y - h

    _, h = W:SectionHeader(parent, "CURRENT SETTINGS", y); y = y - h
    y = Paragraph(parent, "Read-only: OPie only lets its own Options page change these. Use \"Options\" above, then come back here.", y, 0.5)
    local shade = false
    for _, s in ipairs(SUMMARY) do
        local v = GetOption(s[1])
        if v ~= nil then
            shade = not shade
            y = Row(parent, y, nil, s[2], nil, s[3](v), nil, nil, shade)
        end
    end
    y = y - 8
    _, h = W:WideButton(parent, "Refresh", y, Refresh, 300); y = y - h
    return math.abs(y)
end

-------------------------------------------------------------------------------
--  Page: Rings
-------------------------------------------------------------------------------
local function BindingText(ringKey)
    local bind, curKey, _, isActive = Call("GetRingBinding", ringKey)
    if curKey and curKey ~= "" then
        return GetBindingText and GetBindingText(curKey) or curKey
    end
    if bind and bind ~= "" then
        return "|cffa0a0a0" .. bind .. (isActive == false and " (inactive)" or "") .. "|r"
    end
    return "|cff808080Not bound|r"
end

local function ShowMacro(name, macro)
    EllesmereUI:ShowInputPopup({
        title       = name,
        message     = "Put this line in a macro (or a bar button) to open the ring. Ctrl+C to copy.",
        initialText = macro or "",
        confirmText = "Close",
        maxLetters  = 255,
        onConfirm   = function() end,
    })
end

local function BuildRingsPage(parent, yOffset)
    local W = EllesmereUI.Widgets
    local y = yOffset
    local _, h

    _, h = W:SectionHeader(parent, "RINGS", y); y = y - h
    _, h = W:WideButton(parent, "Edit Ring Bindings", y, function() OPieSlash("bind") end, 300); y = y - h
    _, h = W:WideButton(parent, "Create / Edit Custom Rings", y, function() OPieSlash("custom") end, 300); y = y - h
    _, h = W:Toggle(parent, "Show Built-in Rings", y,
        function() return showInternal end,
        function(v) showInternal = v; Refresh() end,
        "Also list OPie's internal rings (normally hidden in its own binding list too)."); y = y - h

    if EllesmereUI.IsSearchPrebuild() then return math.abs(y) end
    if not OP() then
        y = Paragraph(parent, "|cffff6060OPie isn't loaded.|r", y, 1)
        return math.abs(y)
    end

    _, h = W:SectionHeader(parent, "YOUR RINGS", y); y = y - h
    local iter = Call("IterateRings", showInternal)
    local any, shade = false, false
    if iter then
        for key, name, _, flags in iter do
            any, shade = true, not shade
            local _, _, macro = Call("GetRingInfo", key)
            local sub = (flags == 1) and "built-in" or nil
            y = Row(parent, y, RING_ICON, name or key, sub, BindingText(key), "Macro",
                function() ShowMacro(name or key, macro) end, shade)
        end
    end
    if not any then
        y = Paragraph(parent, "No rings yet. Make one with \"Create / Edit Custom Rings\".", y, 0.5)
    end
    y = y - 8
    _, h = W:WideButton(parent, "Refresh List", y, Refresh, 300); y = y - h
    return math.abs(y)
end

-------------------------------------------------------------------------------
--  Registration
-------------------------------------------------------------------------------
WarUI.AddModule({
    key         = MODULE_KEY,
    title       = "OPie",
    description = "Ring menus for your abilities, items and mounts. Hold a binding to open a ring.",
    pages       = { "General", "Rings" },
    buildPage   = function(pageName, parent, yOffset)
        if pageName == "Rings" then return BuildRingsPage(parent, yOffset) end
        return BuildGeneralPage(parent, yOffset)
    end,
    -- OPie settings may change in OPie's own window: rebuild next time.
    onModuleLeave = function()
        local key = EllesmereUI.GetPluginModuleKey(PLUGIN_ID, MODULE_KEY)
        if key then EllesmereUI:InvalidateModulePageCache(key) end
    end,
})

SLASH_WARUIOPIE1 = "/waruiopie"
SlashCmdList.WARUIOPIE = function()
    if InCombatLockdown() then return end
    if WarUI and WarUI.Open then WarUI.Open(MODULE_KEY) end
end
