-------------------------------------------------------------------------------
--  War UI - hub addon
--  Skapar sektionen "War UI" i EllesmereUI:s sidomeny. Dina egna addons
--  lägger till sig själva som rader under den via WarUI.AddModule({...}).
--
--  EllesmereUI tillåter bara EN registrering per plugin och session, så vi
--  samlar in alla moduler först och registrerar vid PLAYER_LOGIN (då har alla
--  vanliga addons laddats).
-------------------------------------------------------------------------------
local ADDON_ID = "WarUI"          -- måste matcha mappnamnet
local LABEL    = "War UI"         -- rubriken i sidomenyn

WarUI = WarUI or {}
local pending, registered = {}, false

--- Lägg till en modul (rad) under War UI.
--- spec = { key, title, description, pages, buildPage, onReset, ... }
--- (samma fält som modulspecen i EllesmereUI/PLUGINS_API.md)
function WarUI.AddModule(spec)
    if registered then
        print("|cffc0392bWar UI:|r modulen '" .. tostring(spec and spec.key) ..
              "' kom för sent (efter inloggning) och visas inte. Använd ## Dependencies: WarUI och anropa AddModule i huvudfilen.")
        return false
    end
    pending[#pending + 1] = spec
    return true
end

--- Öppna War UI-panelen (valfritt på en viss modul/sida).
function WarUI.Open(moduleKey, pageName)
    if registered then return EllesmereUI.OpenPlugin(ADDON_ID, moduleKey, pageName) end
end

local function Register()
    if registered then return end
    registered = true
    if #pending == 0 then return end  -- inga moduler än: ingen tom sektion
    if not (EllesmereUI and EllesmereUI.RegisterPlugin) then
        print("|cffc0392bWar UI:|r EllesmereUI saknar RegisterPlugin (för gammal version?).")
        return
    end
    -- Sortera på `order` (lägst först, standard 50), sedan alfabetiskt på titel,
    -- så ordningen är stabil oavsett laddordning. War UI 3.0: General (order 0) först.
    table.sort(pending, function(a, b)
        local oa, ob = tonumber(a.order) or 50, tonumber(b.order) or 50
        if oa ~= ob then return oa < ob end
        return tostring(a.title) < tostring(b.title)
    end)
    EllesmereUI.RegisterPlugin(ADDON_ID, {
        label    = LABEL,
        position = "bottom",
        modules  = pending,
    })
end

-- Registreras en frame EFTER PLAYER_LOGIN (War UI 3.0): WarUI_General lägger
-- till en rad per påslagen modul i sin egen PLAYER_LOGIN, när profilen är
-- laddad, och den körs efter vår (vi laddas först).
local f = CreateFrame("Frame")
f:RegisterEvent("PLAYER_LOGIN")
f:SetScript("OnEvent", function(self)
    self:UnregisterAllEvents()
    C_Timer.After(0, Register)
end)

SLASH_WARUI1 = "/warui"
SlashCmdList.WARUI = function() WarUI.Open() end
