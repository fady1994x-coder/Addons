# War UI - Profession Map

A World of Warcraft addon for **WoW Forever** that marks **profession trainers, class trainers and city services** on the world map in the capital cities. Open the map in Ironforge and you can see right away where the Tailoring trainer, the Auction House or your class trainer is.

The addon is part of **War UI**, a set of addons that show up in their own **War UI** section in [EllesmereUI](https://www.curseforge.com/wow/addons/ellesmereui). All settings live there.

---

## Features

### Profession trainers
- All 12 professions: Alchemy, Blacksmithing, Enchanting, Engineering, Herbalism, Leatherworking, Mining, Skinning, Tailoring, Cooking, First Aid and Fishing.
- **By default you only see the professions your character has learned**, including Cooking, First Aid and Fishing. A Hunter with Skinning, Herbalism and Cooking only sees those three.
- Turn on **Show All Professions** to see every trainer. You can also hide single professions.
- Your own professions get a **gold ring** around the icon.

### Class trainers
- **My class only** (default): a Hunter sees the Hunter trainers and a Warrior sees the Warrior trainers.
- **All classes**: every class trainer, and you can switch each class on or off.
- Hunters also get a **Pet Trainer** pin. You can turn it off.

### City services
On by default: Auction House, Bank, Mailbox, Repair, Reagents, Innkeeper, Flight Master.

Off by default: Stable Master, Battlemasters, Weapon Master, Trade Goods, General Goods.

You can switch each service on or off. Merchants that stand together share one pin, so you don't get 20 Repair pins in Ironforge.

### On the map
- **Three styles:** Icon + Text (default), Icon only, Text only.
- **Hover** a pin to see the NPC names and titles, for example *Bengus Deepforge - Artisan Blacksmith*.
- **Click** a pin to set a waypoint. It uses TomTom if you have it, otherwise the game's own map pin.
- **One pin per group:** trainers of the same kind that stand together (Journeyman + Expert + Artisan) share one pin.
- **Spread overlapping pins:** pins that would cover each other are nudged apart. The waypoint still goes to the exact spot.
- **Look:** icon size, text size, text color (profession/class color, white or gold) and round or square icons.

### Learns from you
When you open a trainer window, the addon saves where that trainer really stands. That fixes pins that are off on Forever, and it adds trainers that are missing from the data, also outside the capitals. You can turn this off or clear the saved trainers in the settings.

---

## Cities
| Alliance | Horde |
|---|---|
| Stormwind | Orgrimmar |
| Ironforge | Thunder Bluff |
| Darnassus | Undercity |

You can choose to only show the cities of your own faction.

---

## Requirements
- **WoW Forever** (built against interface 16001)
- **[EllesmereUI](https://www.curseforge.com/wow/addons/ellesmereui)**
- **WarUI**, the hub addon that creates the War UI section in EllesmereUI
- Optional: **TomTom** for waypoints

## Installation
1. Download the repository.
2. Copy the `WarUI_ProfessionMap` folder into
   `World of Warcraft\_classic_beta_\Interface\AddOns\`
   (on the live version later: `World of Warcraft\<Forever folder>\Interface\AddOns\`).
3. Make sure `EllesmereUI` and `WarUI` are installed too.
4. Start the game or type `/reload`.

The folder must be named exactly `WarUI_ProfessionMap`, the same as the `.toc` file.

---

## Settings
Open EllesmereUI → **War UI** → **Profession Map**, or type `/profmap`.

| Tab | What you set there |
|---|---|
| **General** | On/off, style (icon/text/both), size, colors, round icons, gold ring on your professions, one pin per group, spread overlapping pins, only your faction's cities, remember trainers you visit |
| **Professions** | Show All Professions, and a toggle for each profession |
| **Classes** | Show class trainers, My class only / All classes, Pet Trainer, a toggle for each class |
| **Services** | Show city services, and a toggle for each service |

## Slash commands
| Command | What it does |
|---|---|
| `/profmap` | Open the settings |
| `/profmap toggle` · `on` · `off` | Turn the map pins on or off |
| `/profmap icon` · `text` · `both` | Switch style |
| `/profmap learn` | Save the position of the trainer you are talking to right now |
| `/profmap skills` | List the professions the addon found on your character (troubleshooting) |
| `/profmap debug` | Show the map ID, the number of pins and saved trainers |

---

## Troubleshooting
- **No pins at all:** check that EllesmereUI and WarUI are enabled, then run `/profmap debug` while standing in a capital.
- **A profession is missing:** run `/profmap skills`. Opening that profession's window also counts as proof that you have it.
- **A pin is in the wrong place:** talk to the trainer once. Its position is then saved and the pin moves.

---

## Credits
- Trainer and service positions come from **[Questie](https://github.com/Questie/Questie)** / QuestieDB (Forever data) and are used under its GPL-3.0 license. Thanks to the Questie team and everyone who has contributed data.
- Settings UI: **EllesmereUI** plugin API.
- Author: **Fady**
