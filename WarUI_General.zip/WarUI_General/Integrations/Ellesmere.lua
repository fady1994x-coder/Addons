-- ProseccoUI / Integrations / Ellesmere.lua
-- Everything ProseccoUI touches in EllesmereUI goes through this file
-- (design §8). Only public API (PLUGINS_API.md and functions without a
-- leading "_"); no field starting with "_" is read or written here.
-- Checked against EllesmereUI 9.3.9 (a3b97b7).

local ADDON, ns = ...

local E = {}
-- War UI: every page lives in the hub addon WarUI's plugin section.
local PLUGIN = "WarUI"
ns.Ellesmere = E

local function EUI() return _G.EllesmereUI end

-- Border on one of OUR frames. `px` = whole pixels at UIParent scale, the unit
-- of Ellesmere's own Border Size sliders, for every style. Ellesmere's legacy
-- `size` argument is a step 1-4 into EDGE_MAP for textured styles, so the exact
-- size goes in as edgePx (15th argument) with the nearest step beside it, the
-- way Ellesmere's slider writes it (Known: EllesmereUI_PixelPerfect.lua:1380-1405
-- BorderPx/BorderPxStep, :1542 ApplyBorderStyle; EllesmereUIOptions/
-- EllesmereUI_Widgets.lua:1689-1735 BorderPxSliderCfg).
-- offX/offY: Ellesmere's Border Width/Height Offset for a textured style (nil =
-- the texture's own default); a solid border ignores them (Known:
-- EllesmereUI_PixelPerfect.lua:1645-1675).
function E.Border(frame, px, r, g, b, a, style, offX, offY)
    local eui = EUI()
    if px <= 0 then
        eui.ApplyBorderStyle(frame, 0, r, g, b, a, style)          -- 0 hides the border
        return
    end
    local step = eui.BorderPxStep(px, style)
    eui.ApplyBorderStyle(frame, step, r, g, b, a, style, offX, offY, nil, nil, nil, nil, nil, px)
end

-- A border style's horizontal seam art, the strip Ellesmere's unit frames draw
-- along the health/power join ("Power Bar Seam"); nil for a style without it
-- (Known: EllesmereUI_PixelPerfect.lua:1231 GetBorderCompanion, :1210-1217).
function E.BorderSeamArt(style)
    return EUI().GetBorderCompanion(style, "sepH")
end

-- The seam art's thickness for a border of `px` pixels, snapped at effective
-- scale es (Known: EllesmereUI_PixelPerfect.lua:1428 BorderCompanionThickness).
function E.BorderSeamThickness(style, px, es)
    local eui = EUI()
    return eui.BorderCompanionThickness(style, eui.BorderPxStep(px, style), px, es)
end

-- Snap v to whole physical pixels at effective scale es.
function E.SnapForES(v, es)
    return EUI().PP.SnapForES(v, es)
end

-- True for a textured border style (not "solid"), the only kind with offsets.
function E.IsTexturedBorder(style)
    return style ~= nil and style ~= "" and style ~= "solid"
end

-- Ellesmere's own Border Width Offset | Border Height Offset slider pair, as on
-- its power bar and damage meter pages (Known: EllesmereUIOptions/
-- EllesmereUI_Widgets.lua:1753 BorderOffsetRowCfgs). It shows the texture's
-- default until the slider is moved and writes nil when moved back onto it.
-- No addonKey: the global per-texture defaults, the ones E.Border gets.
-- spec: getTex, getPx, getX, setX, getY, setY, apply, plus cell fields
-- (disabled, disabledTooltip). Only called while Ellesmere's options are
-- loaded (our pages are built inside them).
function E.BorderOffsetCells(spec)
    local eui = EUI()
    return eui.BorderOffsetRowCfgs({
        getTex = spec.getTex,
        getStep = function() return eui.BorderPxStep(spec.getPx(), spec.getTex()) end,
        getSizeKey = function() return nil end,
        getPx = spec.getPx,
        getX = spec.getX, setX = spec.setX,
        getY = spec.getY, setY = spec.setY,
        apply = spec.apply,
        disabled = spec.disabled,
        disabledTooltip = spec.disabledTooltip,
        tooltip = "Moves the textured border's art out (higher) or in (lower) from the frame's edge.",
    })
end

-- Size and anchor offsets snapped to whole physical pixels, as Ellesmere does
-- for its own rows (Known: EllesmereUI_PixelPerfect.lua:246-265 PP.Size/PP.Point).
-- An edge that lands on half a pixel is drawn blurred.
function E.PixelSize(frame, w, h)
    EUI().PP.Size(frame, w, h)
end

-- PP.Point snaps the offset, but a frame pinned by its middle on an axis
-- (CENTER, or TOP/BOTTOM for x, LEFT/RIGHT for y) with an odd number of
-- pixels on that axis still gets both edges on half pixels. Ellesmere moves
-- such a centre half a pixel for the same reason (Known:
-- EllesmereUI_PixelPerfect.lua:187-222 SnapCenterForDim). Call after the size
-- is set. Assumes the point it is pinned to sits on a whole pixel, which holds
-- for the screen (Inferred: even screen sizes) but not for every frame.
function E.PixelPoint(frame, point, rel, relPoint, x, y)
    local PP = EUI().PP
    local m = PP.mult
    x, y = PP.Scale(x), PP.Scale(y)
    local function odd(dim) return math.floor(dim / m + 0.5) % 2 == 1 end
    if not point:find("LEFT") and not point:find("RIGHT") and odd(frame:GetWidth()) then x = x + m / 2 end
    if not point:find("TOP") and not point:find("BOTTOM") and odd(frame:GetHeight()) then y = y + m / 2 end
    frame:SetPoint(point, rel, relPoint, x, y)
end

-- Size of one physical pixel in `frame`'s own units: Ellesmere's PP.mult is
-- one pixel in UIParent units (Known: EllesmereUI_PixelPerfect.lua PP.mult),
-- and a frame with its own scale (RXP's Window Scale) has other units.
function E.PixelUnit(frame)
    return EUI().PP.mult * UIParent:GetEffectiveScale() / frame:GetEffectiveScale()
end

-- Ellesmere's widget factory (Toggle, DualRow, SectionHeader ...). Only valid
-- inside buildPage, which Ellesmere runs after its options addon has loaded.
function E.Widgets()
    return EUI().Widgets
end

-- values, order for a border style dropdown: Ellesmere's styles plus every
-- LibSharedMedia border (Known: EllesmereUI_PixelPerfect.lua:1249, 1286).
function E.BorderStyles()
    return EUI().GetBorderTextureDropdown()
end

-- opts: title, message, confirmText, onConfirm, onCancel, reload. With
-- reload = true the confirm button is the secure /reload click on Forever
-- (Known: EllesmereUI_Popups.lua:506-540).
function E.Confirm(opts)
    EUI():ShowConfirmPopup(opts)
end

-- Our section in Ellesmere's options panel (Known: PLUGINS_API.md).
function E.RegisterPlugin(spec)
    return EUI().RegisterPlugin(PLUGIN, spec)
end

function E.OpenPlugin(moduleKey, pageName)
    return EUI().OpenPlugin(PLUGIN, moduleKey, pageName)
end

-- buildPage also runs in the search's hidden pre-build pass with a stub widget
-- factory; side effects (our own preview frames) are skipped then.
function E.IsSearchPrebuild()
    return EUI().IsSearchPrebuild()
end

-- Re-read the values of the visible page (no rebuild).
function E.RefreshPage()
    EUI():RefreshPage()
end

-- Rebuild the visible page, for rows whose layout depends on a value.
function E.RebuildPage()
    EUI():RefreshPage(true)
end

-- After a profile switch, reset or import: the cached pages hold labels built
-- from the old profile, so they are dropped and the visible page rebuilt.
function E.RebuildPages(moduleKeys)
    local eui = EUI()
    local active = eui:GetActiveModule()
    local ours = false
    for _, key in ipairs(moduleKeys) do
        local full = eui.GetPluginModuleKey(PLUGIN, key)
        if full then
            eui:InvalidateModulePageCache(full)
            if full == active then ours = true end
        end
    end
    if ours then eui:RefreshPage(true) end
end

-- Ellesmere's bar textures plus every SharedMedia statusbar texture, for a
-- background dropdown, built once (Known: EllesmereUI.lua:1368
-- BuildBarTextureTables, :2608 AppendSharedMediaTextures, which also appends
-- textures registered later). Returns names, order; "none" = flat colour.
local barTex, barNames, barOrder
function E.BarTextures()
    if not barTex then
        local eui = EUI()
        barTex, barNames, barOrder = eui.BuildBarTextureTables(true)
        eui.AppendSharedMediaTextures(barNames, barOrder, nil, barTex)
        barNames.none = "None (flat colour)"   -- already first in the order (EllesmereUI.lua:1355)
    end
    return barNames, barOrder
end

-- File path of a bar texture key, or nil for "none" or a texture that is gone
-- (Known: EllesmereUI.lua:2568 ResolveTexturePath).
function E.BarTexturePath(key)
    if key == nil or key == "none" then return nil end
    E.BarTextures()
    return EUI().ResolveTexturePath(barTex, key, nil)
end

-- Ellesmere's UI font and outline, so our labels match its look
-- (Known: EllesmereUI_Fonts.lua:311, :351).
function E.Font()
    local eui = EUI()
    return eui.GetFontPath(), eui.GetFontOutlineFlag()
end

-- ---------------------------------------------------------------------------
-- Damage Meters (Modules/DamageMeter.lua). Only named
-- frames and Ellesmere's saved settings (design §8 level 2); nothing in
-- EllesmereUI._ModuleNS or any other "_" field. Checked against 9.3.9 (1424549).
-- ---------------------------------------------------------------------------

local DM_FOLDER = "EllesmereUIDamageMeters"
local DM_MAX_WINDOWS = 5            -- MAX_WINDOWS in EllesmereUIDamageMeters.lua:30

-- Ellesmere's damage meter windows that exist now, EllesmereUIDMFrame1..5
-- (Known: EllesmereUIDamageMeters.lua:3291). On WoW Forever a window can
-- also show the threat list (EllesmereUIDamageMeters_ForeverThreat.lua), so
-- it is the same frame. A window added in Ellesmere's options after login
-- is found on the next E.DMFrames() call.
function E.DMFrames()
    local out = {}
    for i = 1, DM_MAX_WINDOWS do
        local f = _G["EllesmereUIDMFrame" .. i]
        if f then out[#out + 1] = f end
    end
    return out
end

-- Calls fn whenever Ellesmere styles the border of one of its meter windows.
-- Ellesmere builds its damage meter windows one per frame after PLAYER_LOGIN
-- (C_Timer.After(0) chain, EllesmereUIDamageMeters.lua:6551-6572), rebuilds
-- them on an Ellesmere profile switch (:6577-6609) and builds the Threat
-- Meter the first time it is on, and every build ends with a border pass on a
-- child of the window (DamageMeters.lua:5554-5583 ApplyWindowBorder,
-- ThreatMeter.lua:419). A post-hook on the public ApplyBorderStyle is the
-- only signal for "the window exists now" that needs no internal field.
-- FIELD RESULT 2026-10-06 (build unknown): without it the ring was missing
-- after a reload until a ProseccoUI setting changed (cause Inferred: the
-- windows are built after our PLAYER_ENTERING_WORLD redraw).
-- hooksecurefunc cannot be undone: installed once, fn gates on its own state.
local meterHooked = false
function E.OnMeterBorder(fn)
    if meterHooked then return end
    meterHooked = true
    hooksecurefunc(EUI(), "ApplyBorderStyle", function(target)
        local parent = type(target) == "table" and target.GetParent and target:GetParent()
        local name = parent and parent.GetName and parent:GetName()
        if name and name:match("^EllesmereUIDMFrame%d$") then
            fn()
        end
    end)
end

-- The active Ellesmere profile's damage meter settings: the table
-- EllesmereUI_Lite NewDB keeps in EllesmereUIDB.profiles[name].addons[folder]
-- (Known: EllesmereUI_Lite.lua:250-290; EllesmereUIDamageMeters.lua:181
-- keeps everything under .dm). nil when the meter addon is not loaded.
local function DMSettings(profile)
    if not C_AddOns.IsAddOnLoaded(DM_FOLDER) then return nil end
    local db = _G.EllesmereUIDB
    local p = db and db.profiles and db.profiles[profile or EUI().GetActiveProfileName()]
    local addon = p and p.addons and p.addons[DM_FOLDER]
    return addon and type(addon.dm) == "table" and addon.dm or nil
end

-- The same for read-only use from a module (the preview).
function E.DMSettings(profile) return DMSettings(profile) end

-- Forever Essentials' Threat Meter keeps account-wide settings in
-- EllesmereUIDB.threatMeter (Known: EllesmereUIForeverEssentials_ThreatMeter.lua:30-83).
-- ProseccoUI no longer styles it (Alexander 2026-10-09); the target stays so
-- the values once taken from it can be given back.
local function ThreatSettings(create)
    local db = _G.EllesmereUIDB
    if not (db and C_AddOns.IsAddOnLoaded("EllesmereUIForeverEssentials")) then return false end
    if create and type(db.threatMeter) ~= "table" then db.threatMeter = {} end
    return true, db.threatMeter
end

-- The active Ellesmere profile's chat settings (Modules/Chat.lua):
-- EllesmereUIDB.profiles[name].addons.EllesmereUIChat.chat (Known:
-- EllesmereUIChat.lua:62-160 CHAT_DEFAULTS, :164 NewDB("EllesmereUIChatDB"),
-- which keeps them under the folder name, EllesmereUI_Lite.lua:250-271).
-- nil when the chat addon is not loaded. Checked against 9.4 (3926028).
local CHAT_FOLDER = "EllesmereUIChat"
local function ChatSettings(profile)
    if not C_AddOns.IsAddOnLoaded(CHAT_FOLDER) then return nil end
    local db = _G.EllesmereUIDB
    local p = db and db.profiles and db.profiles[profile or EUI().GetActiveProfileName()]
    local addon = p and p.addons and p.addons[CHAT_FOLDER]
    return addon and type(addon.chat) == "table" and addon.chat or nil
end

-- The active Ellesmere profile's Quest Tracker settings (Modules/QuestTracker
-- .lua): EllesmereUIDB.profiles[name].addons.EllesmereUIQuestTracker
-- .questTracker (Known: EllesmereUIQuestTracker.lua:26-87 QT_DEFAULTS under
-- profile.questTracker, NewDB("EllesmereUIQuestTrackerDB"), kept under the
-- folder name as the chat's). nil when Ellesmere's Quest Tracker is not
-- loaded. Checked against 9.4 (c6e5240).
local QT_FOLDER = "EllesmereUIQuestTracker"
local function QTSettings(profile)
    if not C_AddOns.IsAddOnLoaded(QT_FOLDER) then return nil end
    local db = _G.EllesmereUIDB
    local p = db and db.profiles and db.profiles[profile or EUI().GetActiveProfileName()]
    local addon = p and p.addons and p.addons[QT_FOLDER]
    return addon and type(addon.questTracker) == "table" and addon.questTracker or nil
end

-- Whether Ellesmere's Quest Tracker is loaded, which is what hides
-- Blizzard's tracker once its Visibility is "never".
function E.QuestTrackerLoaded()
    return C_AddOns.IsAddOnLoaded(QT_FOLDER)
end

-- An owned setting is { target = "damageMeters" | "threatMeter" | "chat" |
-- "questTracker", key = "a.b.c" }. Damage meter, chat and quest tracker
-- settings belong to one Ellesmere profile, so they carry its name; the
-- Threat Meter's are account-wide (profile = nil).
function E.OwnedProfile(target)
    if target == "damageMeters" or target == "chat" or target == "questTracker" then
        return EUI().GetActiveProfileName()
    end
    return nil
end

-- available, table. available = false when the addon (or the profile) is
-- missing, so there is nothing to read or write.
local function Root(target, profile, create)
    if target == "damageMeters" then
        local t = DMSettings(profile)
        return t ~= nil, t
    elseif target == "chat" then
        local t = ChatSettings(profile)
        return t ~= nil, t
    elseif target == "questTracker" then
        local t = QTSettings(profile)
        return t ~= nil, t
    end
    return ThreatSettings(create)
end

-- Returns available, value (nil = not set, Ellesmere uses its default).
function E.ReadOwned(target, profile, key)
    local ok, t = Root(target, profile, false)
    if not ok then return false end
    for part in key:gmatch("[^%.]+") do
        if type(t) ~= "table" then return true, nil end
        t = t[part]
    end
    return true, t
end

-- Writes value (nil removes it, so Ellesmere's default applies again).
-- Tables on the way are created. Returns false when there is nowhere to write.
-- Ellesmere reads these values when it builds its windows, so a change shows
-- after a /reload.
function E.WriteOwned(target, profile, key, value)
    local ok, t = Root(target, profile, true)
    if not ok then return false end
    local parts = {}
    for part in key:gmatch("[^%.]+") do parts[#parts + 1] = part end
    for i = 1, #parts - 1 do
        if type(t[parts[i]]) ~= "table" then t[parts[i]] = {} end
        t = t[parts[i]]
    end
    t[parts[#parts]] = value
    return true
end

-- Whether Ellesmere's options panel is open (Known: EllesmereUI_Panel.lua:4694
-- IsShown, no "_").
function E.MenuShown()
    return EUI():IsShown() == true
end

-- The fixed header above the page being built (a preview): builder is
-- (headerFrame, width) -> height. Ellesmere's own preview pages call this
-- from their page builder (Known: EllesmereUI_Panel.lua:2611
-- SetContentHeader, no "_"; EUI_ForeverEssentials_Threat_Options.lua:60).
-- Not in PLUGINS_API.md, so Assumed; it exists whenever a page is built
-- (made with the panel), and a renamed one errors visibly in the page build.
function E.SetPageHeader(builder)
    EUI():SetContentHeader(builder)
end

-- New height for that header after a change (Known: EllesmereUI_Panel.lua
-- 2620-2656, no "_"). While the left button is down (a slider being dragged
-- further down the page) the rows are scrolled with the change so the slider
-- stays under the mouse; otherwise (a toggle, the panel opening) the rows
-- just move, as with Ellesmere's own previews, so the top of the page stays
-- in view.
function E.SetContentHeaderHeight(h)
    if IsMouseButtonDown("LeftButton") then
        EUI():UpdateContentHeaderHeight(h)
    else
        EUI():SetContentHeaderHeightSilent(h)
    end
end

-- Calls fn every time Ellesmere's options panel opens (Known:
-- EllesmereUI_Panel.lua:118 RegisterOnShow, no "_"; a registration, not a
-- hook). Registered once per fn; fn gates on its own state.
local menuShownFns = {}
function E.OnMenuShown(fn)
    for _, f in ipairs(menuShownFns) do
        if f == fn then return end
    end
    menuShownFns[#menuShownFns + 1] = fn
    if #menuShownFns == 1 then
        EUI():RegisterOnShow(function()
            for _, f in ipairs(menuShownFns) do xpcall(f, ns.ErrorHandler("ellesmere:menuShown")) end
        end)
    end
end

-- Calls fn every time Ellesmere's options panel closes: Escape, its X, or
-- combat closing it (Known: EllesmereUI_Panel.lua:122-126 RegisterOnHide,
-- :169-180, no "_"; a registration, not a hook). It cannot be undone, so
-- each fn is registered once and gates on its own state.
local menuClosedFns = {}
function E.OnMenuClosed(fn)
    for _, f in ipairs(menuClosedFns) do
        if f == fn then return end
    end
    menuClosedFns[#menuClosedFns + 1] = fn
    if #menuClosedFns == 1 then
        EUI():RegisterOnHide(function()
            -- Ellesmere's loop has no pcall: an error of ours would stop
            -- the other registrants' callbacks.
            for _, f in ipairs(menuClosedFns) do xpcall(f, ns.ErrorHandler("ellesmere:menuClosed")) end
        end)
    end
end

-- Opens Ellesmere's own Damage Meters page at one of its sections (DISPLAY,
-- HEADER, BARS, BAR TEXT), the way Ellesmere's own cross-links do (Known:
-- EllesmereUI_Panel.lua:3311 NavigateToElementSettings, no "_"; module =
-- folder name, page = "Damage Meters", EUI_DamageMeters_Options.lua:1975).
-- Unverified: that it works from a plugin page.
function E.OpenDMSection(section)
    EUI():NavigateToElementSettings(DM_FOLDER, "Damage Meters", section)
end

-- Whole physical pixels in UIParent units (padding is set in pixels, like
-- the border size).
function E.Pixels(n)
    return EUI().PP.Scale((tonumber(n) or 0) * EUI().PP.mult)
end

local BAR_FALLBACK = "Interface\\Buttons\\WHITE8X8"     -- BAR_TEX, EllesmereUIDamageMeters.lua:21
local THIN_LINE = { ["thin-line-top"] = true, ["thin-line-bottom"] = true }

-- What the test bars need to look like Ellesmere's damage meter rows, read
-- from the damage meter settings (defaults as in EllesmereUIDamageMeters.lua
-- DM_DEFAULTS:79-160) and Ellesmere's public font, texture and colour
-- functions. nil when the meter addon is not loaded.
function E.DMBarStyle()
    local c = DMSettings()
    if not c then return nil end
    local eui = EUI()
    local s = {}
    -- Texture: the meter adds "blizzard" to the shared list (DamageMeters.lua:1536-1543);
    -- the thin-line styles draw a 1 px line, here a flat bar (Unverified look).
    local key = c.barTexture or "atrocity"
    if key == "blizzard" then
        s.texture = "Interface\\TargetingFrame\\UI-StatusBar"
    elseif THIN_LINE[key] then
        s.texture = BAR_FALLBACK
    else
        E.BarTextures()
        s.texture = eui.ResolveTexturePath(barTex, key, BAR_FALLBACK)
    end
    -- Bar height and spacing on one pixel grid, as RowMetrics (DamageMeters.lua:1665-1676).
    local es = UIParent:GetEffectiveScale()
    local PP = eui.PP
    s.barH = PP.SnapForES(c.barHeight or 18, es)
    s.barSp = PP.SnapForES(c.barSpacing or 2, es)
    s.leftSize = c.leftFontSize or c.fontSize or 11
    s.rightSize = c.rightFontSize or c.fontSize or 11
    s.headerH = c.hdrHeight or 22
    s.showIcon = (c.iconStyle or "spec") ~= "none"
    s.classColor = c.showClassColor ~= false
    if c.barColorUseAccent ~= false then
        local a = eui.ELLESMERE_GREEN
        s.barR, s.barG, s.barB = a.r, a.g, a.b
    else
        local bc = c.barColor or {}
        s.barR, s.barG, s.barB = bc.r or 0.35, bc.g or 0.55, bc.b or 0.8
    end
    s.fillAlpha = c.barFillAlpha or 1
    s.trackR, s.trackG, s.trackB, s.trackA = c.barBgR or 0, c.barBgG or 0, c.barBgB or 0, c.barBgAlpha or 0
    s.trackClass = c.barBgUseClassColor == true
    s.leftClass, s.rightClass = c.leftTextUseClassColor == true, c.rightTextUseClassColor == true
    local lc, rc = c.leftTextColor or {}, c.rightTextColor or {}
    s.leftR, s.leftG, s.leftB = lc.r or 1, lc.g or 1, lc.b or 1
    s.rightR, s.rightG, s.rightB = rc.r or 1, rc.g or 1, rc.b or 1
    s.hideNumbers = c.hideNumbers == true
    s.leftX, s.leftY = tonumber(c.leftTextOffsetX) or 0, tonumber(c.leftTextOffsetY) or 0
    s.rightX, s.rightY = tonumber(c.rightTextOffsetX) or 0, tonumber(c.rightTextOffsetY) or 0
    return s
end

-- A test bar's text in the damage meter's font, outline and shadow, the way
-- its rows set theirs (Known: EllesmereUIDamageMeters.lua:1516 SetDMFont,
-- EllesmereUI_Fonts.lua:582 ApplyModuleFont).
function E.DMFont(fs, size)
    EUI().ApplyModuleFont(fs, nil, size, "damageMeters")
end

-- Ellesmere's Header Height (Damage Meters > Header, UI units). On the
-- EllesmereUI look the header is exactly this tall, the rows start right under
-- it and the title and buttons are centred in it (Known:
-- EllesmereUIDamageMeters.lua:216, 3308, 3334, 3894). nil when not loaded.
function E.DMHeaderHeight()
    local c = DMSettings()
    return c and (tonumber(c.hdrHeight) or 22)
end

-- Ellesmere's header background colour and opacity (Damage Meters > Header;
-- default 1B1B1B at 1, Known: EllesmereUIDamageMeters.lua:151-152, 3318).
function E.DMHeaderBg()
    local c = DMSettings()
    if not c then return nil end
    local hc = c.hdrBgColor
    return hc and hc.r or 0x1B / 255, hc and hc.g or 0x1B / 255, hc and hc.b or 0x1B / 255,
        tonumber(c.hdrBgAlpha) or 1
end

-- The damage meter header's button icons, right to left as Ellesmere lays
-- them out (settings, segment, meter type, reset, new window), and their
-- tint. Ellesmere's own media files and its EllesmereUI-look glyphs (Known:
-- EllesmereUIDamageMeters.lua:24-26, 52, 3410-3691, 896-906; the stock looks
-- swap in other art). Assumed: the file names; a renamed file shows empty.
local DM_MEDIA = "Interface\\AddOns\\" .. DM_FOLDER .. "\\Media\\"
function E.DMHeaderIcons()
    local c = DMSettings()
    if not c then return nil end
    local icons = { "dm_settings.png", "dm_sheet.png", "dm_home_damage.png" }
    if c.hideResetButton ~= true then icons[#icons + 1] = "dm_undo.png" end
    icons[#icons + 1] = "dm_open.png"
    for i, f in ipairs(icons) do icons[i] = DM_MEDIA .. f end
    local r, g, b = 1, 1, 1
    if c.iconColorUseAccent == true then
        local a = EUI().ELLESMERE_GREEN
        if a then r, g, b = a.r, a.g, a.b end
    elseif type(c.iconColor) == "table" then
        r, g, b = c.iconColor.r or 1, c.iconColor.g or 1, c.iconColor.b or 1
    end
    return icons, r, g, b, 0.4      -- ICON_ALPHA, the idle look
end

-- True when the damage meter uses one of Ellesmere's stock looks (Global
-- Settings > Style), which draw their own window art (Known:
-- EllesmereUIDamageMeters.lua:93-99 useBlizzardStyle/useClassicStyle, :236-246).
function E.DMStockStyle()
    local c = DMSettings()
    return c ~= nil and (c.useBlizzardStyle == true or c.useClassicStyle == true)
end

-- Ellesmere's class colour (custom colours and darkening included; Known:
-- EllesmereUI_Colors.lua:449).
function E.ClassColor(token)
    local cc = EUI().GetClassColor(token)
    return cc.r, cc.g, cc.b
end

-- Ellesmere's number abbreviation (Known: EllesmereUI_NumberFormat.lua:132).
function E.Abbreviate(n)
    return EUI().AbbreviateNumber(n)
end

-- ---------------------------------------------------------------------------
-- Chat (Modules/Chat.lua). Only Ellesmere's saved chat settings are read
-- here; every chat frame Ellesmere draws is anonymous (Known: EllesmereUIChat
-- .lua:4465 panel, EllesmereUIChat_Tabs.lua:122 tab strip), so the module
-- places its frames by Blizzard's named ChatFrame1 and GeneralDockManager.
-- Checked against 9.4 (3926028).
-- ---------------------------------------------------------------------------

-- True when the chat uses Blizzard Style or Classic WoW UI (Chat > Style),
-- which draw Blizzard's own frame art and ignore Background Opacity (Known:
-- EllesmereUIChat.lua:193-200 ChatStyle, :230 ChatStock).
function E.ChatStockStyle()
    local c = ChatSettings()
    return c ~= nil and (c.useBlizzardStyle == true or c.useClassicStyle == true)
end

-- Height of Ellesmere's tabs (Chat > Tabs > Tab Height, UI units). Its tabs
-- stand on the bottom edge of Blizzard's tab row at this height (Known:
-- EllesmereUIChat_Tabs.lua:79 TabHeight, :729-731 ghost anchors). nil when
-- the chat addon is not loaded. The EllesmereUI style only: Classic and the
-- Forever variant use 32 and 28 (Tabs.lua:60-73).
function E.ChatTabHeight()
    local c = ChatSettings()
    return c and (tonumber(c.tabHeight) or 24)
end

-- ---------------------------------------------------------------------------
-- Party and raid frames (Modules/ClickBindings.lua). Named frames, the public
-- GetSecureMenuMacro and a read of Ellesmere's saved click-cast table; ported
-- from ClickTweak 1.1.0 (Alexander's own addon), which read the same things.
-- ---------------------------------------------------------------------------

local function AddHeaderChildren(hdr, out)
    if type(hdr) ~= "table" then return end
    local i = 1
    while hdr[i] do
        local btn = hdr[i]
        if type(btn) == "table" and btn.SetAttribute then out[#out + 1] = btn end
        i = i + 1
    end
end

-- Ellesmere's party and raid unit buttons, never its unit frames. Header and
-- button names from EUI_RaidFrames_Layout.lua:83,125 and
-- EUI_RaidFrames_Party.lua:564,616 (as read for ClickTweak). Every child is
-- pre-created by Ellesmere (5 per group, 40 flat, 5 party), so a scan out of
-- combat finds them all. Empty while EllesmereUIRaidFrames is not loaded.
function E.GroupUnitButtons()
    local out = {}
    for g = 1, 8 do AddHeaderChildren(_G["ERFGroupHeader" .. g], out) end
    AddHeaderChildren(_G.ERFFlatHeader, out)
    AddHeaderChildren(_G.ERFPartyHeader, out)
    local selfBtn = _G.ERFPartySelfButton
    if type(selfBtn) == "table" and selfBtn.SetAttribute then out[#out + 1] = selfBtn end
    return out
end

function E.RaidFramesLoaded()
    return C_AddOns.IsAddOnLoaded("EllesmereUIRaidFrames")
end

-- Alexander's own ClickTweak, which Click Bindings replaces: it writes the
-- same attributes on the same frames. Folder name from its .toc.
function E.ClickTweakLoaded()
    return C_AddOns.IsAddOnLoaded("ClickTweak")
end

-- Ellesmere's macro that opens a unit's right-click menu (public, carries its
-- fix for the pet-menu misfire), or nil when this EllesmereUI has none.
function E.SecureMenuMacro(frame)
    local eui = EUI()
    return eui.GetSecureMenuMacro and eui.GetSecureMenuMacro(frame) or nil
end

-- Ellesmere's saved click-cast (HoverCast) table, read only. Assumed layout,
-- from EUI_RaidFrames_ClickCast.lua GetClickCastDB (ns.db.sv.clickCast) and
-- EllesmereUI_Lite.lua (db.sv = EllesmereUIDB). If the layout changes, the
-- checks find nothing and Ellesmere's keys are no longer skipped.
local function ClickCastDB()
    local sv = _G.EllesmereUIDB
    local cc = type(sv) == "table" and sv.clickCast
    return type(cc) == "table" and cc or nil
end

function E.ClickCastEnabled()
    local cc = ClickCastDB()
    return cc ~= nil and cc.enabled == true
end

-- Ellesmere's spec id lookup (EUI_RaidFrames_ClickCast.lua GetCurrentSpecID).
local function CurrentSpecID()
    if not (C_SpecializationInfo and C_SpecializationInfo.GetSpecialization) then return nil end
    local idx = C_SpecializationInfo.GetSpecialization()
    local id = idx and C_SpecializationInfo.GetSpecializationInfo(idx)
    return (id and id ~= 0) and id or nil
end

-- True when Ellesmere's own click-casting binds this key ("SHIFT-BUTTON1",
-- the same format as ours) right now.
function E.ClickCastUsesKey(key)
    local cc = ClickCastDB()
    if not cc or not cc.enabled then return false end
    local function scan(list)
        if type(list) ~= "table" then return false end
        for _, eb in ipairs(list) do
            if type(eb) == "table" and eb.key == key and eb.enabled ~= false then return true end
        end
        return false
    end
    if scan(cc.globals) then return true end
    if type(cc.specs) == "table" then
        local id = CurrentSpecID()
        if id then
            if scan(cc.specs[id]) then return true end
        else
            -- No spec id (possible on this client): any spec list counts.
            for _, list in pairs(cc.specs) do
                if scan(list) then return true end
            end
        end
    end
    return false
end

-- Ellesmere's public building blocks for a page that is not made of rows (the
-- Click Bindings list), so it looks like Ellesmere's own HoverCast page. Read
-- on every call: only valid inside buildPage, and the accent follows
-- Ellesmere's theme. Fields as ClickTweak used them (EllesmereUI.lua MakeFont,
-- MakeBorder, SolidTex, BuildDropdownControl, BuildToggleControl,
-- BuildVisOptsCBDropdown, SetDeleteIcon, Show/HideWidgetTooltip, ShowInfoPopup).
function E.Kit()
    local eui = EUI()
    local accent = eui.ELLESMERE_GREEN or { r = 0.05, g = 0.82, b = 0.62 }
    return {
        pad = eui.CONTENT_PAD or 20,
        accent = { accent.r, accent.g, accent.b },
        dd = { r = eui.DD_BG_R, g = eui.DD_BG_G, b = eui.DD_BG_B, a = eui.DD_BG_A,
               ha = eui.DD_BG_HA, border = eui.DD_BRD_A, text = eui.DD_TXT_A },
        Font = function(parent, size, r, g, b, a) return eui.MakeFont(parent, size, nil, r, g, b, a) end,
        Border = function(frame, r, g, b, a) return eui.MakeBorder(frame, r, g, b, a, eui.PanelPP) end,
        Solid = function(frame, layer, r, g, b, a) return eui.SolidTex(frame, layer, r, g, b, a) end,
        Dropdown = function(...) return eui.BuildDropdownControl(...) end,
        Toggle = function(...) return eui.BuildToggleControl(...) end,
        -- nil in an EllesmereUI without it; the page says so.
        CheckDropdown = eui.BuildVisOptsCBDropdown and function(...) return eui.BuildVisOptsCBDropdown(...) end,
        DeleteIcon = function(tex) eui.SetDeleteIcon(tex) end,
        Tip = function(owner, text) eui.ShowWidgetTooltip(owner, text) end,
        HideTip = function() eui.HideWidgetTooltip() end,
        Info = function(title, text) eui:ShowInfoPopup({ title = title, content = text }) end,
    }
end
