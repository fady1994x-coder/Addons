-- WarUI_General / Core / Options.lua (from ProseccoUI)
-- Our page in Ellesmere's options panel, built with Ellesmere's own widgets
-- through the plugin API (Known: EllesmereUI/PLUGINS_API.md).
--
-- War UI 2.0: ONE sidebar row, "General", under War UI. Every module is a
-- tab (page) of that row:
--   General | <module tabs, by title> | <extra tabs> | Profiles
-- The General tab lists every module with its on/off switch, then the global
-- border. Every module tab starts with the module's own on/off toggle, drawn
-- here so all modules switch the same way.
--
-- A module can also live inside another module's tab instead of having its
-- own (`hostPage = "<host key>"`, e.g. Guide Highlight inside Quest
-- Tracker): its rows are drawn under the host's, with its own toggle.
-- Tabs that are not modules (Click Cast, with its own SavedVariables) come
-- in through ns.Options.AddPage.

local _, ns = ...

ns.Options = {}

local ROW_KEY = "General"       -- the one row under War UI

-- After a profile switch, reset or import every cached page is stale.
local function RebuildAll()
    ns.Ellesmere.RebuildPages({ ROW_KEY })
end

-- Drop the cached tabs and rebuild the visible one (one frame later, so the
-- click that changed the data finishes first). For pages whose layout
-- depends on data (lists, previews).
function ns.Options.Refresh()
    C_Timer.After(0, function()
        local eui = _G.EllesmereUI
        local key = eui and eui.GetPluginModuleKey and eui.GetPluginModuleKey("WarUI", ROW_KEY)
        if not key then return end
        eui:InvalidateModulePageCache(key)
        if eui:GetActiveModule() == key then eui:RefreshPage(true) end
    end)
end

-- ---------------------------------------------------------------------------
-- Copy / paste window for export and import (from ProseccoTools PT.ShowText).
-- Created the first time it is needed; no global name.
-- ---------------------------------------------------------------------------

local textFrame
local function ShowText(title, text, onImport)
    if not textFrame then
        local f = CreateFrame("Frame", nil, UIParent, "BasicFrameTemplateWithInset")
        f:SetSize(620, 400); f:SetPoint("CENTER")
        -- Above Ellesmere's options panel (DIALOG, level 100: at DIALOG this
        -- window opened BEHIND it, so a click into the import box landed on
        -- the panel and nothing could be typed) and one strata below its
        -- confirm popup (FULLSCREEN_DIALOG), so "Import?" opens on top of this.
        f:SetFrameStrata("FULLSCREEN")
        f:SetToplevel(true)
        f:SetClampedToScreen(true)
        f:SetMovable(true); f:EnableMouse(true); f:RegisterForDrag("LeftButton")
        f:SetScript("OnDragStart", f.StartMoving); f:SetScript("OnDragStop", f.StopMovingOrSizing)
        f.title = f:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
        f.title:SetPoint("TOP", 0, -5)
        local sf = CreateFrame("ScrollFrame", nil, f, "UIPanelScrollFrameTemplate")
        sf:SetPoint("TOPLEFT", 10, -30); sf:SetPoint("BOTTOMRIGHT", -30, 42)
        local eb = CreateFrame("EditBox", nil, sf)
        eb:SetMultiLine(true); eb:SetFontObject(ChatFontNormal); eb:SetWidth(560)
        eb:SetHeight(1500); eb:SetAutoFocus(false)
        -- No length limit: an export is several thousand characters.
        eb:SetMaxLetters(0)
        if eb.SetMaxBytes then eb:SetMaxBytes(0) end
        eb:EnableMouse(true)
        eb:SetScript("OnEscapePressed", function() f:Hide() end)
        sf:SetScrollChild(eb)
        -- A click anywhere in the text area puts the cursor in the box.
        sf:EnableMouse(true)
        sf:SetScript("OnMouseDown", function() eb:SetFocus() end)
        f.edit = eb
        local btn = CreateFrame("Button", nil, f, "UIPanelButtonTemplate")
        btn:SetSize(120, 24); btn:SetPoint("BOTTOM", 0, 12)
        btn:SetText("Import")
        btn:SetScript("OnClick", function()
            if f.onImport then f.onImport(f.edit:GetText()) end
        end)
        f.button = btn
        textFrame = f
    end
    textFrame.title:SetText(title)
    textFrame.edit:SetText(text or "")
    textFrame.onImport = onImport
    textFrame.button:SetShown(onImport ~= nil)
    textFrame:Show()
    textFrame:Raise()
    if onImport then textFrame.edit:SetFocus() else textFrame.edit:HighlightText() end
end

-- ---------------------------------------------------------------------------
-- General tab: every module's on/off switch, then the global border with a
-- preview box drawn by ns.Border.Apply.
-- ---------------------------------------------------------------------------

local preview                   -- the preview box on the newest built General page

local function RefreshPreview()
    if preview then ns.Border.Apply(preview, ns.db.global.border) end
end

local function ByTitle(a, b) return a.title < b.title end

-- The module's on/off toggle cell (General tab and the top of its own tab).
local function ToggleCell(M, text)
    return { type = "toggle", text = text or M.title,
        tooltip = (M.description or "") ..
            (M.affects and ("\n\nChanges other addons:\n- " .. table.concat(M.affects, "\n- ")) or "") ..
            (M.reload and "\n\nNeeds a reload: press Reload UI (top of the General tab) when you are done switching." or ""),
        disabled = M.locked and function() return true end or nil,
        disabledTooltip = M.locked,
        getValue = function() return ns.IsModuleEnabled(M.key) end,
        setValue = function(v)
            ns.SetModuleEnabled(M.key, v and true or false, ns.Ellesmere.RefreshPage)
        end }
end
ns.Options.ToggleCell = ToggleCell

-- War UI 2.5: one reload for every switch made since login.
local function ReloadRow(W, parent, y, always)
    local pending = ns.PendingReload()
    if #pending == 0 and not always then return y end
    local _, h = W:DualRow(parent, y,
        { type = "button", text = "Reload UI", width = 140,
          disabled = function() return #ns.PendingReload() == 0 end,
          disabledTooltip = "Nothing waiting for a reload",
          onClick = function() ns.ReloadNow() end },
        { type = "label", text = #pending > 0
            and ("|cffffd100Waiting for a reload:|r " .. table.concat(pending, ", ") .. ". Switch everything you want, then reload once.")
            or "Switch the modules you want on or off, then press Reload UI once." })
    return y - h
end
ns.Options.ReloadRow = ReloadRow

local function BuildGeneral(_, parent, y)
    local W = ns.Ellesmere.Widgets()
    local _, h
    y = ReloadRow(W, parent, y, true)

    _, h = W:SectionHeader(parent, "MODULES", y); y = y - h
    local mods = {}
    for _, M in ipairs(ns.ModuleList()) do mods[#mods + 1] = M end
    table.sort(mods, ByTitle)
    for i = 1, #mods, 2 do
        local a, b = mods[i], mods[i + 1]
        _, h = W:DualRow(parent, y, ToggleCell(a), b and ToggleCell(b) or { type = "spacer" }); y = y - h
    end
    _, h = W:DualRow(parent, y,
        { type = "label", text = "Every module has its own tab above. Click Cast is always on: it only does something once you add bindings." }); y = y - h

    _, h = W:SectionHeader(parent, "GLOBAL BORDER", y); y = y - h
    y = ns.Border.Rows(W, parent, y, function() return ns.db.global.border end, function()
        ns.Apply()
        RefreshPreview()
    end, true)
    -- No right cell: a full-width row, so the sentence is not cut off.
    _, h = W:DualRow(parent, y,
        { type = "label", text = "Modules with \"Use Global Border\" on follow these values." }); y = y - h

    if not ns.Ellesmere.IsSearchPrebuild() then
        _, h = W:SectionHeader(parent, "PREVIEW", y); y = y - h
        local box = CreateFrame("Frame", nil, parent)
        -- Anchored from the left on whole pixels. Centred on the page, its left
        -- and right edges can land on half pixels; the likely cause of the
        -- blurred sides Alexander saw (2026-10-06, Pixels 16 px; Inferred).
        ns.Ellesmere.PixelSize(box, 220, 60)
        ns.Ellesmere.PixelPoint(box, "TOPLEFT", parent, "TOPLEFT", 40, y - 16)
        local bg = box:CreateTexture(nil, "BACKGROUND")
        bg:SetAllPoints()
        bg:SetColorTexture(0.12, 0.12, 0.12, 0.9)
        preview = box
        RefreshPreview()
        y = y - 92
    end

    _, h = W:SectionHeader(parent, "RESET", y); y = y - h
    _, h = W:DualRow(parent, y,
        { type = "button", text = "Reset Global Border", width = 180,
          onClick = function()
              ns.Ellesmere.Confirm({
                  title = "Reset Global Border",
                  message = "Put the global border back to its defaults?",
                  confirmText = "Reset",
                  onConfirm = function() ns.ResetGlobal(); RebuildAll() end,
              })
          end },
        { type = "label", text = "Each tab has its own reset at the bottom." }); y = y - h
    return math.abs(y)
end


-- ---------------------------------------------------------------------------
-- Profiles
-- ---------------------------------------------------------------------------

local newName, newFrom, copyFrom = "", "__defaults", nil

local function Report(ok, msg)
    if msg then ns.Print(msg) end
    if ok then RebuildAll() end
end

local function BuildProfiles(_, parent, y)
    local W = ns.Ellesmere.Widgets()
    local _, h
    local active = ns.ActiveProfileName()
    local names = ns.ProfileNames()

    -- Which profile this character uses
    _, h = W:SectionHeader(parent, "ACTIVE PROFILE", y); y = y - h
    local values, order = {}, {}
    for i, n in ipairs(names) do values[n] = n; order[i] = n end
    _, h = W:DualRow(parent, y,
        { type = "dropdown", text = "Profile",
          tooltip = "Every War UI General setting (all modules except Click Cast), including which modules are on, belongs to this profile. Each character remembers its own choice.",
          values = values, order = order,
          getValue = function() return ns.ActiveProfileName() end,
          setValue = function(v)
              local ok, why = ns.SwitchProfile(v)
              Report(ok, ok and ("now using profile \"" .. v .. "\".") or why)
          end },
        { type = "label", text = "This character: " .. ns.CharKey() }); y = y - h

    -- New profile
    _, h = W:SectionHeader(parent, "NEW PROFILE", y); y = y - h
    local srcValues, srcOrder = { __defaults = "Installed defaults" }, { "__defaults" }
    for _, n in ipairs(names) do
        srcValues[n] = "Copy of \"" .. n .. "\""
        srcOrder[#srcOrder + 1] = n
    end
    if srcValues[newFrom] == nil then newFrom = "__defaults" end
    _, h = W:DualRow(parent, y,
        { type = "input", text = "Name", inputWidth = 160, inputStyle = "popup",
          getValue = function() return newName end,
          setValue = function(v) newName = tostring(v or "") end },
        { type = "dropdown", text = "Start from", values = srcValues, order = srcOrder,
          getValue = function() return newFrom end,
          setValue = function(v) newFrom = v end }); y = y - h
    _, h = W:DualRow(parent, y,
        { type = "label", text = "This character switches to the new profile." },
        { type = "button", text = "Create", width = 130,
          onClick = function()
              local ok, why = ns.CreateProfile(newName, newFrom ~= "__defaults" and newFrom or nil)
              if ok then newName = "" end
              Report(ok, ok and ("created profile \"" .. why .. "\" and switched to it.") or why)
          end }); y = y - h

    -- Copy another profile into this one
    _, h = W:SectionHeader(parent, "COPY INTO \"" .. active .. "\"", y); y = y - h
    local others, otherOrder = {}, {}
    for _, n in ipairs(names) do
        if n ~= active then others[n] = n; otherOrder[#otherOrder + 1] = n end
    end
    if copyFrom == nil or others[copyFrom] == nil then copyFrom = otherOrder[1] end
    local noOther = function() return #otherOrder == 0 end
    _, h = W:DualRow(parent, y,
        { type = "dropdown", text = "Copy from", values = others, order = otherOrder,
          disabled = noOther, disabledTooltip = "There is no other profile",
          getValue = function() return copyFrom end,
          setValue = function(v) copyFrom = v end },
        { type = "button", text = "Copy", width = 130,
          disabled = noOther, disabledTooltip = "There is no other profile",
          onClick = function()
              local from = copyFrom
              ns.Ellesmere.Confirm({
                  title = "Copy profile",
                  message = "Replace everything in \"" .. ns.ActiveProfileName() .. "\" with \""
                      .. tostring(from) .. "\"? The profile you copy from is left alone.",
                  confirmText = "Copy",
                  onConfirm = function()
                      local ok, why = ns.CopyProfileInto(from)
                      Report(ok, ok and ("copied \"" .. tostring(from) .. "\" in.") or why)
                  end,
              })
          end }); y = y - h

    -- Delete / reset
    _, h = W:SectionHeader(parent, "DELETE OR RESET \"" .. active .. "\"", y); y = y - h
    _, h = W:DualRow(parent, y,
        { type = "button", text = "Delete", width = 130,
          disabled = function() return #names < 2 end,
          disabledTooltip = "The only profile cannot be deleted",
          onClick = function()
              local name = ns.ActiveProfileName()
              ns.Ellesmere.Confirm({
                  title = "Delete profile",
                  message = "Delete \"" .. name .. "\"? Characters using it move to the first profile left.",
                  confirmText = "Delete",
                  onConfirm = function()
                      local ok, why = ns.DeleteProfile(name)
                      Report(ok, ok and ("deleted \"" .. name .. "\", now using \"" .. why .. "\".") or why)
                  end,
              })
          end },
        { type = "button", text = "Reset to defaults", width = 160,
          onClick = function()
              local name = ns.ActiveProfileName()
              ns.Ellesmere.Confirm({
                  title = "Reset profile",
                  message = "Put every setting in \"" .. name .. "\" back to the installed defaults? "
                      .. "Modules that are on are switched off. Export first if you want a copy.",
                  confirmText = "Reset",
                  onConfirm = function()
                      ns.ResetProfile()
                      Report(true, "\"" .. name .. "\" reset to defaults.")
                  end,
              })
          end }); y = y - h

    -- Text in and out
    _, h = W:SectionHeader(parent, "EXPORT AND IMPORT", y); y = y - h
    _, h = W:DualRow(parent, y,
        { type = "button", text = "Export", width = 130,
          onClick = function()
              ShowText("Export of \"" .. ns.ActiveProfileName() .. "\" - Ctrl+C to copy", ns.ExportProfile())
          end },
        { type = "button", text = "Import", width = 130,
          onClick = function()
              ShowText("Import into \"" .. ns.ActiveProfileName() .. "\" - Ctrl+V, then Import", "",
                  function(text)
                      ns.Ellesmere.Confirm({
                          title = "Import",
                          message = "Replace everything in \"" .. ns.ActiveProfileName()
                              .. "\" with the pasted settings? Other profiles are not touched.",
                          confirmText = "Import",
                          onConfirm = function()
                              local ok, why = ns.ImportProfile(text)
                              if ok then textFrame:Hide() end
                              Report(ok, ok and ("imported into \"" .. ns.ActiveProfileName() .. "\".")
                                  or ("import failed: " .. why))
                          end,
                      })
                  end)
          end }); y = y - h
    return math.abs(y)
end


-- ---------------------------------------------------------------------------
-- Module tabs: the on/off toggle, the module's own rows, the rows of any
-- module hosted on this tab, and a reset button.
-- ---------------------------------------------------------------------------

local extraPages = {}           -- ns.Options.AddPage specs, by page name
local extraOrder = {}

-- A tab that is not a module: spec = { page, build(parent, y, W) -> y,
-- onLeave(), onShow() }.
function ns.Options.AddPage(spec)
    if extraPages[spec.page] then return end
    extraPages[spec.page] = spec
    extraOrder[#extraOrder + 1] = spec.page
end

-- Old call from every module file (each used to be its own row); the
-- tabs are now collected in ns.Options.Finish, so nothing to do.
function ns.Options.AddModule() end

local function ResetButton(W, parent, y, M)
    local _, h = W:DualRow(parent, y,
        { type = "button", text = "Reset " .. M.title, width = 180,
          onClick = function()
              ns.Ellesmere.Confirm({
                  title = "Reset " .. M.title,
                  message = "Put every " .. M.title .. " setting back to its defaults? On/off stays as it is.",
                  confirmText = "Reset",
                  onConfirm = function()
                      ns.ResetModuleSettings(M.key, M.defaults)
                      RebuildAll()
                  end,
              })
          end },
        { type = "spacer" })
    return y - h
end

local pageModule = {}           -- page name -> module
local hosted = {}               -- host key -> { modules drawn on its tab }

local function BuildModulePage(M, pageName, parent, y, W)
    local _, h
    if pageName == M.pages[1] then
        _, h = W:DualRow(parent, y, ToggleCell(M, "Enable " .. M.title),
            { type = "label", text = M.locked or (M.reload and "Needs a reload: press Reload UI when you are done switching." or "") }); y = y - h
        y = ReloadRow(W, parent, y, false)
    end
    if M.BuildPage then y = M:BuildPage(pageName, parent, y, W) end
    for _, G in ipairs(hosted[M.key] or {}) do
        _, h = W:SectionHeader(parent, G.title:upper(), y); y = y - h
        _, h = W:DualRow(parent, y, ToggleCell(G, "Enable " .. G.title),
            { type = "label", text = G.description or "" }); y = y - h
        if G.BuildPage then y = G:BuildPage(pageName, parent, y, W) end
    end
    if pageName == M.pages[#M.pages] then
        _, h = W:SectionHeader(parent, "RESET", y); y = y - h
        y = ResetButton(W, parent, y, M)
        for _, G in ipairs(hosted[M.key] or {}) do y = ResetButton(W, parent, y, G) end
    end
    return y
end

local function BuildPage(pageName, parent, y)
    local W = ns.Ellesmere.Widgets()
    if pageName == "General" then return BuildGeneral(nil, parent, y) end
    if pageName == "Profiles" then return BuildProfiles(nil, parent, y) end
    local M = pageModule[pageName]
    if M then return math.abs(BuildModulePage(M, pageName, parent, y, W)) end
    local spec = extraPages[pageName]
    if spec then return math.abs(spec.build(parent, y, W)) end
    return math.abs(y)
end

-- ---------------------------------------------------------------------------
-- The row. Called from Register.lua, the last file in the toc, once every
-- module file has registered (WarUI hands the row to Ellesmere at
-- PLAYER_LOGIN; Ellesmere copies the page list then).
-- ---------------------------------------------------------------------------

local finished = false
function ns.Options.Finish()
    if finished then return end
    finished = true
    local pages = { "General" }
    local mods = {}
    for _, M in ipairs(ns.ModuleList()) do
        if M.hostPage then
            hosted[M.hostPage] = hosted[M.hostPage] or {}
            table.insert(hosted[M.hostPage], M)
        elseif #M.pages > 0 then
            mods[#mods + 1] = M
        end
    end
    local tabs = {}
    for _, M in ipairs(mods) do
        for _, p in ipairs(M.pages) do
            pageModule[p] = M
            tabs[#tabs + 1] = p
        end
    end
    for _, p in ipairs(extraOrder) do tabs[#tabs + 1] = p end
    table.sort(tabs)
    for _, p in ipairs(tabs) do pages[#pages + 1] = p end
    pages[#pages + 1] = "Profiles"

    WarUI.AddModule({
        key = ROW_KEY, title = "General",
        description = "All War UI modules in one place: one tab each. Switch them on or off on the General tab.",
        pages = pages,
        buildPage = BuildPage,
        onPageCacheRestore = function(pageName)
            local M = pageModule[pageName]
            if M and M.PageShown then M:PageShown(pageName) end
            local spec = extraPages[pageName]
            if spec and spec.onShow then spec.onShow() end
        end,
        -- Lists (buffs, bindings) can change while the panel is elsewhere:
        -- build every tab fresh next time.
        onModuleLeave = function()
            for _, spec in pairs(extraPages) do
                if spec.onLeave then pcall(spec.onLeave) end
            end
            local eui = _G.EllesmereUI
            local key = eui and eui.GetPluginModuleKey and eui.GetPluginModuleKey("WarUI", ROW_KEY)
            if key then eui:InvalidateModulePageCache(key) end
        end,
    })
end

-- PLAYER_LOGIN (Core.lua): nothing left to register.
function ns.Options.Register()
    ns.Log("SESSION", "options: %d module(s) as tabs under War UI > General", #ns.ModuleList())
end

-- Opens the panel on a module's tab (moduleKey nil = the General tab).
function ns.Options.Open(moduleKey)
    local page
    local M = moduleKey and ns.GetModule(moduleKey)
    if M then
        local host = M.hostPage and ns.GetModule(M.hostPage)
        page = (host or M).pages[1]
    elseif moduleKey and extraPages[moduleKey] then
        page = moduleKey
    end
    if InCombatLockdown() or not (WarUI and WarUI.Open and WarUI.Open(ROW_KEY, page)) then
        ns.Print("the settings could not be opened (in combat?). Try /warui.")
    end
end
