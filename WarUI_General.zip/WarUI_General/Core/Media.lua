-- ProseccoUI / Core / Media.lua
-- Registers the files listed in Media/Manifest.lua with LibSharedMedia, which
-- comes with EllesmereUI (Known: EllesmereUI.toc). Ellesmere lists every
-- SharedMedia font, texture, border and sound in its dropdowns and picks up
-- late registrations, so registering is all it takes for them to show up
-- there (ProseccoTools Fonts.lua did the same). No register of our own.
-- Registration is not a module: it only adds names to a list and changes
-- nothing on screen.

local ADDON, ns = ...

ns.Media = {}

local DIR = "Interface\\AddOns\\" .. ADDON .. "\\Media\\"

-- EllesmereUI is a ## Dependency and loads before us, so LibSharedMedia exists
-- when this file runs; if it does not, LibStub raises a visible error.
local LSM = LibStub("LibSharedMedia-3.0")

for mediaType, files in pairs(ns.MediaManifest) do
    for name, file in pairs(files) do
        LSM:Register(mediaType, name, DIR .. file)
    end
end

-- Path of a font by its SharedMedia name (ours or anyone's). Modules ask for
-- names, never paths.
function ns.Media.Font(name)
    return LSM:Fetch("font", name)
end

-- Every SharedMedia font, for a font dropdown: values (name -> label) and
-- order. "" stands for Ellesmere's own font, so a module can follow it.
function ns.Media.FontList()
    local values, order = { [""] = "Ellesmere's font" }, { "" }
    for _, name in ipairs(LSM:List("font")) do
        values[name] = name
        order[#order + 1] = name
    end
    return values, order
end
