-- ProseccoUI / Core / Border.lua
-- The only border code in the addon (design §9). Every module draws its
-- borders with ns.Border.Apply and builds its border menu rows with
-- ns.Border.Rows; a module with its own border code is wrong (CLAUDE.md).
--
-- A border setting has the same shape everywhere:
--   border = { useGlobal = true, style = "solid", size = 1, color = "000000", alpha = 1 }
-- The global one (ns.db.global.border) has no useGlobal. A textured style can
-- also have offsetX/offsetY (Ellesmere's Border Width/Height Offset); missing
-- means the texture's default, so no defaults or migration are needed.

local _, ns = ...

ns.Border = {}

-- Ellesmere's ApplyBorderStyle shows/hides the frame it is given (Known:
-- EllesmereUI_PixelPerfect.lua:1569-1572, size 0 hides it). So the border is
-- drawn on a child of the frame, never on the frame itself. Weak keys: the
-- holder goes away with the frame and nothing is written on the frame.
local holders = setmetatable({}, { __mode = "k" })

function ns.Border.Resolve(cfg)
    if cfg.useGlobal then return ns.db.global.border end
    return cfg
end

-- `frame` is always one of OUR frames (design §8): never a Blizzard or
-- Ellesmere frame. `cfg` is the module's border table, read at call time.
function ns.Border.Apply(frame, cfg)
    local b = ns.Border.Resolve(cfg)
    local holder = holders[frame]
    if not holder then
        holder = CreateFrame("Frame", nil, frame)
        holder:SetAllPoints(frame)
        holders[frame] = holder
    end
    holder:SetFrameLevel(frame:GetFrameLevel() + 1)
    local r, g, bl = ns.HexToRGB(b.color)
    ns.Ellesmere.Border(holder, tonumber(b.size) or 0, r, g, bl, tonumber(b.alpha) or 1, b.style,
        tonumber(b.offsetX), tonumber(b.offsetY))
end

-- The nearest whole pixel (u = one pixel). The 0.001 keeps a value just under
-- half a pixel from rounding differently between two passes, as in
-- Ellesmere's own snapping (Known: EllesmereUI_PixelPerfect.lua:178-181).
local function Snap(v, u) return math.floor(v / u + 0.5 + 0.001) * u end
ns.Border.Snap = Snap

-- Places `edge` (OUR frame: a child of `target`, or any frame with the
-- target's effective scale, since the offsets are in the target's units) on whole physical pixels
-- around a rectangle of `target`, a frame we do not own and only read: the
-- target's rect shrunk by `inset` (left, right, top, bottom, in the target's
-- units) and grown by `px` pixels on every side (0: exactly that rect; the
-- solid border's size: its lines lie just outside it). Ellesmere's border
-- lines are not snapped to the pixel grid (Known: EllesmereUI_PixelPerfect.lua
-- PP.DisablePixelSnap), so a frame whose edges fall between pixels gets
-- blurred lines (DEVNOTES "Kärnan"); another addon's frame can sit anywhere.
-- Returns false while the target has no position yet (not shown or anchored).
function ns.Border.Outside(edge, target, px, l, r, t, b)
    local left, right, top, bottom = target:GetLeft(), target:GetRight(), target:GetTop(), target:GetBottom()
    if not (left and right and top and bottom) then return false end
    local u = ns.Ellesmere.PixelUnit(target)
    local grow = (tonumber(px) or 0) * u
    edge:ClearAllPoints()
    edge:SetPoint("TOPLEFT", target, "TOPLEFT", Snap(left + l, u) - grow - left, Snap(top - t, u) + grow - top)
    edge:SetPoint("BOTTOMRIGHT", target, "BOTTOMRIGHT", Snap(right - r, u) + grow - right, Snap(bottom + b, u) - grow - bottom)
    return true
end

-- A seam: one border line across a join inside a box, as Ellesmere's "Power
-- Bar Seam" on its unit frames. `tex` is OUR texture, `anchor` OUR frame whose
-- top edge is the join and whose width is the line's. A style with seam art
-- gets that art, laid as Ellesmere lays it (its line sits in the top texels,
-- 5/32 of its thickness; Known: EUI_UnitFrames_Power.lua:105-143
-- UF_LayoutPowerSeam); solid gets a line of the border's size just above the
-- join (the header side, so it does not cover the first row). A textured style without seam art draws nothing. Coloured as the border.
-- Returns true when a line was drawn.
function ns.Border.Seam(tex, anchor, cfg)
    local b = ns.Border.Resolve(cfg)
    local px = tonumber(b.size) or 0
    tex:ClearAllPoints()
    if px <= 0 then tex:Hide() return false end
    local es = anchor:GetEffectiveScale()
    local r, g, bl = ns.HexToRGB(b.color)
    local art = ns.Ellesmere.BorderSeamArt(b.style)
    if art then
        local thick = ns.Ellesmere.BorderSeamThickness(b.style, px, es)
        if not thick or thick <= 0 then tex:Hide() return false end
        local raise = ns.Ellesmere.SnapForES(thick * 5 / 32, es)
        tex:SetTexture(art)
        tex:SetTexCoord(0, 1, 0, 1)
        tex:SetVertexColor(r, g, bl, tonumber(b.alpha) or 1)
        tex:SetPoint("TOPLEFT", anchor, "TOPLEFT", 0, raise)
        tex:SetPoint("TOPRIGHT", anchor, "TOPRIGHT", 0, raise)
        tex:SetHeight(thick)
    elseif not ns.Ellesmere.IsTexturedBorder(b.style) then
        tex:SetColorTexture(r, g, bl, tonumber(b.alpha) or 1)
        tex:SetPoint("BOTTOMLEFT", anchor, "TOPLEFT", 0, 0)
        tex:SetPoint("BOTTOMRIGHT", anchor, "TOPRIGHT", 0, 0)
        tex:SetHeight(px * ns.Ellesmere.PixelUnit(anchor))
    else
        tex:Hide()
        return false
    end
    tex:Show()
    return true
end

-- `size` is whole pixels for every style, like Ellesmere's own Border Size
-- sliders (0-32; Integrations/Ellesmere.lua turns it into what ApplyBorderStyle
-- takes). The range is the same for all styles, so a style pick needs no rebuild.
local SIZE_MAX = 32

-- The border rows of a settings page: Use Global Border (left out on the
-- global page itself), Style, Size and Color (with alpha). `getCfg` returns
-- the border table at call time (a profile switch replaces it); `onChange`
-- runs after every change. Returns the new y.
function ns.Border.Rows(W, parent, y, getCfg, onChange, isGlobal)
    local function follows() return not isGlobal and getCfg().useGlobal == true end
    local followsTip = "Follows the Global Border (General page)"
    local function set(key, v)
        getCfg()[key] = v
        onChange()
    end

    local cells = {}
    if not isGlobal then
        cells[#cells + 1] = { type = "toggle", text = "Use Global Border",
            tooltip = "Draw this border with the settings on the General page.",
            getValue = function() return getCfg().useGlobal == true end,
            setValue = function(v)
                set("useGlobal", v and true or false)
                ns.Ellesmere.RebuildPage()      -- grey the rows below in or out; the offset row follows the style in use
            end }
    end
    local values, order = ns.Ellesmere.BorderStyles()
    cells[#cells + 1] = { type = "dropdown", text = "Border Style", values = values, order = order,
        disabled = follows, disabledTooltip = followsTip,
        getValue = function() return getCfg().style end,
        setValue = function(v)
            -- A new texture starts from its own offsets, as in Ellesmere's menus
            -- (EUI_DamageMeters_Options.lua:709-710).
            getCfg().offsetX, getCfg().offsetY = nil, nil
            set("style", v)
            ns.Ellesmere.RebuildPage()      -- the offset row is there only for a textured style
        end }
    cells[#cells + 1] = { type = "slider", text = "Border Size", min = 0, max = SIZE_MAX, step = 1,
        tooltip = "Border size in pixels; for a textured style this is the size of its edge art. 0 hides the border.",
        disabled = follows, disabledTooltip = followsTip,
        getValue = function() return getCfg().size end,
        setValue = function(v) set("size", v) end }
    cells[#cells + 1] = { type = "colorpicker", text = "Border Color", hasAlpha = true,
        disabled = follows, disabledTooltip = followsTip,
        getValue = function()
            local c = getCfg()
            local r, g, b = ns.HexToRGB(c.color)
            return r, g, b, tonumber(c.alpha) or 1
        end,
        setValue = function(r, g, b, a)
            local c = getCfg()
            c.color = ns.RGBToHex(r, g, b)
            c.alpha = a or 1
            onChange()
        end }

    local _, h
    for i = 1, #cells, 2 do
        _, h = W:DualRow(parent, y, cells[i], cells[i + 1] or { type = "spacer" })
        y = y - h
    end
    -- Offsets of the border actually drawn (the global one while following it).
    local function shown() return ns.Border.Resolve(getCfg()) end
    if ns.Ellesmere.IsTexturedBorder(shown().style) then
        local left, right = ns.Ellesmere.BorderOffsetCells({
            getTex = function() return shown().style end,
            getPx = function() return tonumber(shown().size) or 0 end,
            getX = function() return shown().offsetX end,
            setX = function(v) getCfg().offsetX = v end,
            getY = function() return shown().offsetY end,
            setY = function(v) getCfg().offsetY = v end,
            apply = onChange,
            disabled = follows,
            disabledTooltip = followsTip,
        })
        _, h = W:DualRow(parent, y, left, right)
        y = y - h
    end
    return y
end
