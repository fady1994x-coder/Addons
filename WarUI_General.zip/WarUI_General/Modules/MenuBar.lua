-- WarUI_General / Modules / MenuBar.lua
-- v1.0.1: Blizzard's micro menu and bag bar as ONE flat bar, Ellesmere style.
--
--   [char][spells][talents][quests][social][lfg][map][menu][help] | [bag 34]
--
-- Every menu button is our own SecureActionButton with type "click" that
-- clicks Blizzard's micro button for us. The click runs in Blizzard's secure
-- code, so Character / Spellbook / Talents ... open in combat too, and
-- nothing of ours touches their frames. Which micro buttons exist (and are
-- shown, enabled, open or flashing) is read from Blizzard's own buttons, so
-- the bar follows whatever the WoW Forever client has.
--
-- The bag button replaces backpack + bag slots + keyring:
--   left-click   all bags (Ellesmere Bags / Bagnon / Blizzard: ToggleAllBags)
--   right-click  keyring (or shift-click, setting)
--   drop an item on it: into the backpack
-- with the free slots as a number. Optional: the four bag slots beside it.
--
-- Blizzard's MicroMenuContainer and BagsBar are hidden through Ellesmere's
-- own Action Bars setting (Visibility "Hidden") and given back when the
-- module goes off. Moves with Ellesmere's Unlock Mode ("Menu Bar").

local ns = WarUIGeneral

local M = ns.RegisterModule("menuBar", {
    title       = "Menu Bar",
    description = "Micro menu and bags in one flat bar: one bag button (right-click = keyring) with the free slots. Moves in Ellesmere's Unlock Mode.",
    pages       = { "Menu Bar" },
    affects     = { "Hides Blizzard's micro menu and bag bar (War UI draws one bar with both). They come back when Menu Bar is off." },
    defaults    = {
        enabled      = true,
        size         = 26,       -- button size
        spacing      = 2,
        padding      = 3,        -- bar background around the buttons
        perRow       = 0,        -- 0 = everything on one line
        vertical     = false,
        bagsFirst    = false,
        separator    = true,     -- a gap and a thin line between menu and bags
        iconStyle    = "ellesmere", -- "ellesmere" (EllesmereUI's micro menu icons) | "flat" (War UI) | "blizzard"
        iconColor    = "white",  -- "white" | "class" | "accent" | "custom"
        iconHex      = "FFFFFF",
        iconScale    = 0.62,     -- icon size inside the button
        hoverAccent  = true,     -- icon in Ellesmere's accent on hover
        btnColor     = "1A1D21", btnAlpha = 0.9,
        bgColor      = "080B0D", bgAlpha = 0.75,
        border       = { useGlobal = true, style = "solid", size = 1, color = "000000", alpha = 1 },
        buttonBorder = { useGlobal = false, style = "solid", size = 1, color = "000000", alpha = 1 },
        showFree     = true,     -- free bag slots on the bag button
        freeSize     = 10,
        keyringClick = "right",  -- "right" | "shift"
        bagSlots     = false,    -- the four bag slots beside the bag button
        mouseover    = false,
        fadeAlpha    = 0,
        hideInCombat = false,
        hidden       = {},       -- [micro button name] = true: left out of the bar
        -- pos (Unlock Mode) / autoPos (where Blizzard's bars were): { point, relPoint, x, y }
    },
})

local function DB() return ns.db.modules.menuBar end

local MEDIA = "Interface\\AddOns\\WarUI_General\\Media\\MenuBar\\"
local DEFAULT_POS = { point = "BOTTOMRIGHT", relPoint = "BOTTOMRIGHT", x = -4, y = 4 }

-- Blizzard micro button -> our icon / a name when it has no tooltip text.
local ICONS = {
    CharacterMicroButton = "character", SpellbookMicroButton = "spellbook",
    PlayerSpellsMicroButton = "spellbook", TalentMicroButton = "talents",
    ProfessionMicroButton = "professions", AchievementMicroButton = "achievement",
    QuestLogMicroButton = "quest", SocialsMicroButton = "social", GuildMicroButton = "guild",
    LFDMicroButton = "lfg", LFGMicroButton = "lfg", PVPMicroButton = "pvp",
    CollectionsMicroButton = "collections", EJMicroButton = "journal",
    WorldMapMicroButton = "map", StoreMicroButton = "store", MainMenuMicroButton = "menu",
    HelpMicroButton = "help", HousingMicroButton = "housing",
}
local LABELS = {
    CharacterMicroButton = "Character", SpellbookMicroButton = "Spellbook",
    PlayerSpellsMicroButton = "Spells & Talents", TalentMicroButton = "Talents",
    ProfessionMicroButton = "Professions", AchievementMicroButton = "Achievements",
    QuestLogMicroButton = "Quest Log", SocialsMicroButton = "Social", GuildMicroButton = "Guild",
    LFDMicroButton = "Group Finder", LFGMicroButton = "Group Finder", PVPMicroButton = "Player vs. Player",
    CollectionsMicroButton = "Collections", EJMicroButton = "Adventure Guide",
    WorldMapMicroButton = "World Map", StoreMicroButton = "Shop", MainMenuMicroButton = "Game Menu",
    HelpMicroButton = "Help", HousingMicroButton = "Housing",
}
local function Label(name) return LABELS[name] or (name:gsub("MicroButton$", "")) end

-- EllesmereUI's own micro menu icons (its "EllesmereUI" Micro Menu Skin),
-- read from its folder; a button it has no icon for uses ours.
local EUI_MEDIA = "Interface\\AddOns\\EllesmereUI\\media\\micromenu\\"
local EUI_ICONS = {
    character = "menu-character", spellbook = "menu-spellbook", professions = "menu-professions",
    achievement = "menu-achievements", quest = "menu-quests", social = "menu-friends",
    guild = "menu-guild", lfg = "menu-group", pvp = "menu-pvp", collections = "menu-collections",
    journal = "menu-adventure", map = "menu-map", store = "menu-shop", menu = "menu-options",
    help = "menu-cs", housing = "menu-housing", bag = "menu-bags",
}

-- The texture for one of our icon keys in the chosen style (".png" is
-- required: without it the client only looks for .blp/.tga, and v1.0 drew nothing).
local function IconPath(key)
    if DB().iconStyle ~= "flat" and EUI_ICONS[key] and C_AddOns.IsAddOnLoaded("EllesmereUI") then
        return EUI_MEDIA .. EUI_ICONS[key] .. ".png"
    end
    return MEDIA .. key .. ".png"
end

-- ---------------------------------------------------------------------------
-- Helpers
-- ---------------------------------------------------------------------------

local function Font(fs, size)
    local ok, path, flags = pcall(ns.Ellesmere.Font)
    if not (ok and path and fs:SetFont(path, size, flags or "")) then
        fs:SetFont(STANDARD_TEXT_FONT or "Fonts\\FRIZQT__.TTF", size, "OUTLINE")
    end
end

local function Accent()
    local c = EllesmereUI and EllesmereUI.ELLESMERE_GREEN
    if c and c.r then return c.r, c.g, c.b end
    return 12 / 255, 210 / 255, 157 / 255
end

local function IconRGB()
    local mode = DB().iconColor
    if mode == "accent" then return Accent() end
    if mode == "custom" then return ns.HexToRGB(DB().iconHex) end
    if mode == "class" then
        local _, token = UnitClass("player")
        local ok, r, g, b = pcall(ns.Ellesmere.ClassColor, token)
        if ok and r then return r, g, b end
        local c = RAID_CLASS_COLORS and RAID_CLASS_COLORS[token]
        if c then return c.r, c.g, c.b end
    end
    return 1, 1, 1
end

local function HoverRGB()
    if DB().hoverAccent and DB().iconColor ~= "accent" then return Accent() end
    return 1, 1, 1
end

local function KeyringID()
    local id = Enum and Enum.BagIndex and Enum.BagIndex.Keyring
    if id then return id end
    return KEYRING_CONTAINER
end

local function HasKeyring()
    if ToggleKeyRing then return true end
    local id = KeyringID()
    if not id then return false end
    local ok, n = pcall(C_Container.GetContainerNumSlots, id)
    return ok and (tonumber(n) or 0) > 0
end

local function OpenKeyring()
    if ToggleKeyRing then ToggleKeyRing() return end
    local id = KeyringID()
    if id then ToggleBag(id) end
end

-- Free and total slots in the backpack and the four bags (normal bags only:
-- a quiver or ammo pouch would make the number lie).
local function BagCounts()
    local free, total = 0, 0
    for bag = 0, (NUM_BAG_SLOTS or 4) do
        local n = C_Container.GetContainerNumSlots(bag) or 0
        local f, family = C_Container.GetContainerNumFreeSlots(bag)
        if n > 0 and (family == nil or family == 0) then
            total = total + n
            free = free + (f or 0)
        end
    end
    return free, total
end

local function KeyCount()
    local id = KeyringID()
    if not id then return nil end
    local ok, n = pcall(C_Container.GetContainerNumSlots, id)
    if not ok or not n or n == 0 then return nil end
    local ok2, f = pcall(C_Container.GetContainerNumFreeSlots, id)
    return n - ((ok2 and f) or 0), n
end

local function BagInvID(i)
    if C_Container.ContainerIDToInventoryID then
        local ok, id = pcall(C_Container.ContainerIDToInventoryID, i)
        if ok and id then return id end
    end
    return (CONTAINER_BAG_OFFSET or 19) + i
end

-- ---------------------------------------------------------------------------
-- Blizzard's micro buttons
-- ---------------------------------------------------------------------------

-- In Blizzard's order. MICRO_BUTTONS (the client's own list) when there is
-- one, else MicroMenu's children by layoutIndex.
local function SourceButtons()
    local out, seen = {}, {}
    local function add(b)
        if b and not seen[b] and b.GetName and b:GetName() and b.Click then
            seen[b] = true
            out[#out + 1] = b
        end
    end
    if type(MICRO_BUTTONS) == "table" then
        for _, name in ipairs(MICRO_BUTTONS) do add(_G[name]) end
    end
    if #out == 0 and MicroMenu and MicroMenu.GetChildren then
        local kids = { MicroMenu:GetChildren() }
        table.sort(kids, function(a, b) return (a.layoutIndex or 0) < (b.layoutIndex or 0) end)
        for _, b in ipairs(kids) do
            if b:IsObjectType("Button") and (b:GetName() or ""):find("MicroButton$") then add(b) end
        end
    end
    if #out == 0 then
        for name in pairs(ICONS) do add(_G[name]) end
        table.sort(out, function(a, b) return a:GetName() < b:GetName() end)
    end
    return out
end

-- Names of the micro buttons found (for the settings page).
M.found = {}

-- ---------------------------------------------------------------------------
-- The bar
-- ---------------------------------------------------------------------------

local bar
local micro = {}            -- our menu buttons, in Blizzard's order
local bagBtn
local slotBtns = {}
local sep
local unlockActive = false
local pending = false       -- a layout waits for the end of combat

local function SavedPos()
    if not ns.db then return DEFAULT_POS end
    local p = DB().pos
    if type(p) == "table" and p.point then return p end
    p = DB().autoPos
    if type(p) == "table" and p.point then return p end
    return DEFAULT_POS
end

local function TooltipAnchor(self)
    local _, cy = self:GetCenter()
    local h = UIParent:GetHeight()
    if cy and h and cy * self:GetEffectiveScale() / UIParent:GetEffectiveScale() > h / 2 then
        GameTooltip:SetOwner(self, "ANCHOR_BOTTOM", 0, -4)
    else
        GameTooltip:SetOwner(self, "ANCHOR_TOP", 0, 4)
    end
end

local function SetHover(b, on)
    b.hover = on
    if on then b.icon:SetVertexColor(HoverRGB()) else M.PaintIcon(b) end
end

-- Our art on a button: background tile, icon, active line, alert dot.
local function Dress(b)
    b.bg = b:CreateTexture(nil, "BACKGROUND")
    b.bg:SetAllPoints()
    b.icon = b:CreateTexture(nil, "ARTWORK")
    b.icon:SetPoint("CENTER")
    b.hl = b:CreateTexture(nil, "HIGHLIGHT")
    b.hl:SetAllPoints()
    b.hl:SetColorTexture(1, 1, 1, 0.06)
    b.activeBar = b:CreateTexture(nil, "OVERLAY")
    b.activeBar:SetPoint("BOTTOMLEFT", 1, 1)
    b.activeBar:SetPoint("BOTTOMRIGHT", -1, 1)
    b.activeBar:SetHeight(2)
    b.activeBar:Hide()
    b.alert = b:CreateTexture(nil, "OVERLAY")
    b.alert:SetSize(6, 6)
    b.alert:SetPoint("TOPRIGHT", -2, -2)
    b.alert:SetColorTexture(1, 0.82, 0, 1)
    b.alert:Hide()
end

function M.PaintIcon(b)
    if not b or not b.icon then return end
    local enabled = b.srcEnabled ~= false
    if b.useBlizzardArt then
        b.icon:SetVertexColor(1, 1, 1)
    else
        b.icon:SetVertexColor(IconRGB())
    end
    b.icon:SetDesaturated(not enabled)
    b.icon:SetAlpha(enabled and 1 or 0.35)
end

-- Blizzard's own art for a micro button (the "Blizzard" icon style, and any
-- button we have no icon for).
local function CopyBlizzardArt(b)
    local src = b.src
    local nt = src and src.GetNormalTexture and src:GetNormalTexture()
    if not nt then return false end
    local atlas = nt.GetAtlas and nt:GetAtlas()
    if atlas and atlas ~= "" then
        b.icon:SetAtlas(atlas)
        b.icon:SetTexCoord(0, 1, 0, 1)
        return true
    end
    local tex = nt:GetTexture()
    if tex then
        b.icon:SetTexture(tex)
        b.icon:SetTexCoord(nt:GetTexCoord())
        return true
    end
    return false
end

local function MicroIcon(b)
    local key = ICONS[b.srcName]
    b.useBlizzardArt = false
    if DB().iconStyle == "blizzard" or not key then
        if CopyBlizzardArt(b) then b.useBlizzardArt = true return end
        key = key or "generic"
    end
    b.icon:SetTexture(IconPath(key))
    b.icon:SetTexCoord(0, 1, 0, 1)
end

local function MicroTooltip(self)
    local src = self.src
    TooltipAnchor(self)
    local title = (type(src.tooltipText) == "string" and src.tooltipText ~= "" and src.tooltipText) or Label(self.srcName)
    GameTooltip:SetText(title, 1, 1, 1)
    if type(src.newbieText) == "string" and src.newbieText ~= "" then
        GameTooltip:AddLine(src.newbieText, 1, 0.82, 0, true)
    end
    if not src:IsEnabled() then
        local why = src.disabledTooltip
        if type(why) == "function" then
            local ok, v = pcall(why, src)
            why = ok and v or nil
        end
        if type(why) == "string" and why ~= "" then GameTooltip:AddLine(why, 1, 0.3, 0.3, true) end
    end
    if self.srcName == "MainMenuMicroButton" then
        local _, _, home, world = GetNetStats()
        GameTooltip:AddLine(" ")
        GameTooltip:AddDoubleLine("FPS", ("%.0f"):format(GetFramerate() or 0), 0.7, 0.7, 0.7, 1, 1, 1)
        GameTooltip:AddDoubleLine("Latency (home / world)", ("%d / %d ms"):format(home or 0, world or 0), 0.7, 0.7, 0.7, 1, 1, 1)
    end
    GameTooltip:Show()
end

-- Blizzard's Game Menu button opens the menu on its own mouse-down/up (with
-- an IsMouseOver check), not in OnClick, so a secure "click" does nothing
-- (FIELD RESULT v1.0.1). That one real button is laid over our tile instead,
-- invisible (alpha 0), so the mouse reaches it and Blizzard opens the menu
-- itself. Given back when Menu Bar goes off.
local EMBED = { MainMenuMicroButton = true }
local embedded = {}         -- Blizzard button -> { parent = old parent, tile = our button }

local function Embed(b)
    local src = b.src
    if InCombatLockdown() or not EMBED[b.srcName] then return end
    local e = embedded[src]
    if not e then
        e = { parent = src:GetParent() }
        embedded[src] = e
        src:HookScript("OnEnter", function() local t = embedded[src] and embedded[src].tile; if t then SetHover(t, true) end end)
        src:HookScript("OnLeave", function() local t = embedded[src] and embedded[src].tile; if t then SetHover(t, false) end end)
        -- Blizzard re-anchors micro buttons now and then; keep it on our tile.
        hooksecurefunc(src, "SetPoint", function(self)
            local t = embedded[self] and embedded[self].tile
            if t and not e.placing and not InCombatLockdown() then
                e.placing = true
                self:ClearAllPoints()
                self:SetAllPoints(t)
                e.placing = false
            end
        end)
        hooksecurefunc(src, "SetAlpha", function(self, a)
            if embedded[self] and embedded[self].tile and a ~= 0 then self:SetAlpha(0) end
        end)
    end
    e.tile = b
    e.placing = true
    src:SetParent(b)
    src:ClearAllPoints()
    src:SetAllPoints(b)
    e.placing = false
    src:SetFrameLevel(b:GetFrameLevel() + 5)
    src:SetAlpha(0)
end

local function Unembed()
    if InCombatLockdown() then return false end
    for src, e in pairs(embedded) do
        if e.tile then
            e.tile = nil
            src:SetParent(e.parent or MicroMenu or UIParent)
            src:SetAlpha(1)
        end
    end
    if MicroMenu and MicroMenu.Layout then pcall(MicroMenu.Layout, MicroMenu) end
    return true
end

local function MakeMicro(i, src)
    local b = CreateFrame("Button", "WarUIMenuBarButton" .. i, bar, "SecureActionButtonTemplate")
    -- Both: the secure template acts on the one that matches ActionButtonUseKeyDown.
    b:RegisterForClicks("AnyUp", "AnyDown")
    b:SetAttribute("type", "click")
    b:SetAttribute("clickbutton", src)
    b.src, b.srcName = src, src:GetName()
    Dress(b)
    b:SetScript("OnEnter", function(self) SetHover(self, true); MicroTooltip(self) end)
    b:SetScript("OnLeave", function(self) SetHover(self, false); GameTooltip:Hide() end)
    Embed(b)
    return b
end

-- The bag button ------------------------------------------------------------

local function BagTooltip(self)
    TooltipAnchor(self)
    local free, total = BagCounts()
    GameTooltip:SetText(BAGSLOTTEXT or "Bags", 1, 1, 1)
    GameTooltip:AddDoubleLine("Free slots", ("%d / %d"):format(free, total), 0.7, 0.7, 0.7, 1, 1, 1)
    local keys, keySlots = KeyCount()
    if keys then GameTooltip:AddDoubleLine("Keys", ("%d / %d"):format(keys, keySlots), 0.7, 0.7, 0.7, 1, 1, 1) end
    GameTooltip:AddLine(" ")
    GameTooltip:AddLine("|cffffffffLeft-click:|r open bags", 0.7, 0.7, 0.7)
    if HasKeyring() then
        GameTooltip:AddLine(DB().keyringClick == "shift" and "|cffffffffShift-click:|r keyring"
            or "|cffffffffRight-click:|r keyring", 0.7, 0.7, 0.7)
    end
    GameTooltip:AddLine("|cffffffffDrop an item:|r into the backpack", 0.7, 0.7, 0.7)
    GameTooltip:Show()
end

local function MakeBag()
    local b = CreateFrame("Button", "WarUIMenuBarBags", bar)
    b:RegisterForClicks("LeftButtonUp", "RightButtonUp")
    Dress(b)
    b.count = b:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    b.count:SetPoint("BOTTOMRIGHT", -1, 1)
    b.count:SetJustifyH("RIGHT")
    b:SetScript("OnClick", function(_, button)
        if CursorHasItem and CursorHasItem() then PutItemInBackpack() return end
        local keyring = (DB().keyringClick == "shift" and IsShiftKeyDown())
            or (DB().keyringClick ~= "shift" and button == "RightButton")
        if keyring and HasKeyring() then OpenKeyring() else ToggleAllBags() end
    end)
    b:SetScript("OnReceiveDrag", function() if CursorHasItem() then PutItemInBackpack() end end)
    b:SetScript("OnEnter", function(self) SetHover(self, true); BagTooltip(self) end)
    b:SetScript("OnLeave", function(self) SetHover(self, false); GameTooltip:Hide() end)
    return b
end

-- The four bag slots (optional): click/drag a bag in or out.
local function MakeSlot(i)
    local b = CreateFrame("Button", "WarUIMenuBarBagSlot" .. i, bar)
    b:RegisterForClicks("LeftButtonUp", "RightButtonUp")
    b:RegisterForDrag("LeftButton")
    Dress(b)
    b.bagIndex = i
    b.inv = BagInvID(i)
    b:SetScript("OnClick", function(self, button)
        if CursorHasItem() then PutItemInBag(self.inv)
        elseif button == "RightButton" then ToggleBag(self.bagIndex)
        else PickupBagFromSlot(self.inv) end
    end)
    b:SetScript("OnDragStart", function(self) PickupBagFromSlot(self.inv) end)
    b:SetScript("OnReceiveDrag", function(self) PutItemInBag(self.inv) end)
    b:SetScript("OnEnter", function(self)
        b.hover = true
        TooltipAnchor(self)
        if not GameTooltip:SetInventoryItem("player", self.inv) then
            GameTooltip:SetText(EQUIP_CONTAINER or "Equip Container", 1, 1, 1)
        end
        GameTooltip:Show()
    end)
    b:SetScript("OnLeave", function() b.hover = false; GameTooltip:Hide() end)
    return b
end

local function UpdateSlots()
    for _, b in ipairs(slotBtns) do
        local tex = GetInventoryItemTexture("player", b.inv)
        if tex then
            b.icon:SetTexture(tex)
            b.icon:SetTexCoord(0.08, 0.92, 0.08, 0.92)
            b.icon:SetAlpha(1)
        else
            b.icon:SetTexture(IconPath("bag"))
            b.icon:SetTexCoord(0, 1, 0, 1)
            b.icon:SetAlpha(0.2)
        end
        b.icon:SetVertexColor(1, 1, 1)
    end
end

local function UpdateCount()
    if not bagBtn then return end
    local free = BagCounts()
    bagBtn.count:SetText(DB().showFree and tostring(free) or "")
    if free == 0 then bagBtn.count:SetTextColor(1, 0.3, 0.3)
    elseif free <= 4 then bagBtn.count:SetTextColor(1, 0.75, 0.2)
    else bagBtn.count:SetTextColor(1, 1, 1) end
end

-- ---------------------------------------------------------------------------
-- Layout (out of combat only: the menu buttons are secure)
-- ---------------------------------------------------------------------------

local function Build()
    if bar then return end
    bar = CreateFrame("Frame", "WarUIMenuBar", UIParent)
    bar:SetFrameStrata("MEDIUM")
    bar:SetFrameLevel(10)
    bar:SetClampedToScreen(true)
    bar.bg = bar:CreateTexture(nil, "BACKGROUND", nil, -8)
    bar.bg:SetAllPoints()
    bar:EnableMouse(false)
    sep = bar:CreateTexture(nil, "ARTWORK")
    sep:SetColorTexture(1, 1, 1, 0.18)

    wipe(M.found)
    for i, src in ipairs(SourceButtons()) do
        micro[#micro + 1] = MakeMicro(i, src)
        M.found[#M.found + 1] = src:GetName()
    end
    bagBtn = MakeBag()
    for i = 1, (NUM_BAG_SLOTS or 4) do slotBtns[i] = MakeSlot(i) end
end

-- Which menu buttons go in the bar now (Blizzard shows/hides some, e.g. the
-- Shop or Guild/Social, and the user can leave any out).
local function Wanted(b)
    return b.src:IsShown() and not DB().hidden[b.srcName]
end

local function Signature()
    local s = {}
    for i, b in ipairs(micro) do s[i] = Wanted(b) and "1" or "0" end
    return table.concat(s)
end

local function PlaceBar()
    local p = SavedPos()
    bar:ClearAllPoints()
    bar:SetPoint(p.point, UIParent, p.relPoint or p.point, tonumber(p.x) or 0, tonumber(p.y) or 0)
end

function M.Layout()
    if not bar then return end
    if InCombatLockdown() then pending = true return end
    pending = false
    local db = DB()
    local size = math.floor(tonumber(db.size) or 26)
    local gap = tonumber(db.spacing) or 2
    local pad = tonumber(db.padding) or 3
    local perRow = math.floor(tonumber(db.perRow) or 0)

    local menuItems, bagItems = {}, {}
    for _, b in ipairs(micro) do
        if Wanted(b) then menuItems[#menuItems + 1] = b; b:Show() else b:Hide() end
    end
    for _, b in ipairs(slotBtns) do
        if db.bagSlots then bagItems[#bagItems + 1] = b; b:Show() else b:Hide() end
    end
    bagItems[#bagItems + 1] = bagBtn
    bagBtn:Show()

    local first, second = menuItems, bagItems
    if db.bagsFirst then first, second = bagItems, menuItems end
    local items = {}
    for _, b in ipairs(first) do items[#items + 1] = b end
    local splitAt = #items          -- the separator goes after this many
    for _, b in ipairs(second) do items[#items + 1] = b end

    local n = #items
    local oneLine = perRow <= 0 or perRow >= n
    if oneLine then perRow = n end
    local sepGap = (oneLine and db.separator and splitAt > 0 and splitAt < n) and (gap + 6) or 0

    local maxMain, maxCross = 0, 0
    for i, b in ipairs(items) do
        local main = (i - 1) % perRow
        local cross = math.floor((i - 1) / perRow)
        local offMain = pad + main * (size + gap) + ((sepGap > 0 and i > splitAt) and sepGap or 0)
        local offCross = pad + cross * (size + gap)
        b:SetSize(size, size)
        b:ClearAllPoints()
        if db.vertical then
            b:SetPoint("TOPLEFT", bar, "TOPLEFT", offCross, -offMain)
        else
            b:SetPoint("TOPLEFT", bar, "TOPLEFT", offMain, -offCross)
        end
        maxMain = math.max(maxMain, offMain + size)
        maxCross = math.max(maxCross, offCross + size)
    end
    maxMain, maxCross = maxMain + pad, maxCross + pad
    if db.vertical then bar:SetSize(maxCross, maxMain) else bar:SetSize(maxMain, maxCross) end

    sep:ClearAllPoints()
    if sepGap > 0 then
        local at = pad + splitAt * (size + gap) - gap + (gap + sepGap) / 2
        if db.vertical then
            sep:SetPoint("TOPLEFT", bar, "TOPLEFT", pad + 2, -math.floor(at))
            sep:SetSize(size - 4, 1)
        else
            sep:SetPoint("TOPLEFT", bar, "TOPLEFT", math.floor(at), -(pad + 2))
            sep:SetSize(1, size - 4)
        end
        sep:Show()
    else
        sep:Hide()
    end
    M.sig = Signature()
    PlaceBar()
end

-- Colours, icons, borders: no secure restrictions, any time.
function M.Skin()
    if not bar then return end
    local db = DB()
    local r, g, b = ns.HexToRGB(db.bgColor)
    bar.bg:SetColorTexture(r, g, b, tonumber(db.bgAlpha) or 0.75)
    ns.Border.Apply(bar, db.border)
    local br, bg, bb = ns.HexToRGB(db.btnColor)
    local ar, ag, ab = Accent()
    local iconPx = math.floor((tonumber(db.size) or 26) * (tonumber(db.iconScale) or 0.62) + 0.5)
    local function skin(btn, iconSize)
        btn.bg:SetColorTexture(br, bg, bb, tonumber(db.btnAlpha) or 0.9)
        btn.activeBar:SetColorTexture(ar, ag, ab, 1)
        btn.icon:SetSize(iconSize, iconSize)
        ns.Border.Apply(btn, db.buttonBorder)
    end
    for _, btn in ipairs(micro) do
        skin(btn, iconPx)
        MicroIcon(btn)
        if btn.useBlizzardArt then
            -- Blizzard's art is drawn for a taller button: use the whole tile.
            btn.icon:SetSize((tonumber(db.size) or 26) - 2, (tonumber(db.size) or 26) - 2)
        end
        M.PaintIcon(btn)
    end
    skin(bagBtn, iconPx)
    bagBtn.icon:SetTexture(IconPath("bag"))
    bagBtn.icon:SetTexCoord(0, 1, 0, 1)
    M.PaintIcon(bagBtn)
    Font(bagBtn.count, tonumber(db.freeSize) or 10)
    local slotPx = (tonumber(db.size) or 26) - 4
    for _, s in ipairs(slotBtns) do skin(s, slotPx) end
    UpdateSlots()
    UpdateCount()
end

-- ---------------------------------------------------------------------------
-- State: enabled / open / flashing, mirrored from Blizzard's buttons
-- ---------------------------------------------------------------------------

local function Tick()
    if not (bar and M.active) then return end
    for _, b in ipairs(micro) do
        local src = b.src
        local en = src:IsEnabled() and true or false
        if en ~= b.srcEnabled then
            b.srcEnabled = en
            if not b.hover then M.PaintIcon(b) end
        end
        local pushed = src:GetButtonState() == "PUSHED"
        b.activeBar:SetShown(pushed)
        local fb, fl = src.FlashBorder, src.Flash
        local flash = (type(fb) == "table" and fb.IsShown and fb:IsShown())
            or (type(fl) == "table" and fl.IsShown and fl:IsShown())
        b.alert:SetShown(flash and true or false)
        if b.useBlizzardArt and DB().iconStyle == "blizzard" then CopyBlizzardArt(b) end
    end
    if Signature() ~= M.sig then M.Layout() end
end

-- Mouseover fade: alpha only, which is allowed in combat on secure frames.
local function SetupFader()
    if M.fader then return end
    local f = CreateFrame("Frame")
    local t = 0
    f:SetScript("OnUpdate", function(self, elapsed)
        t = t + elapsed
        if t < 0.05 then return end
        local dt = t; t = 0
        if not (bar and M.active) then return end
        local db = DB()
        local target = 1
        if db.mouseover and not unlockActive then
            local over = bar:IsMouseOver(4, -4, -4, 4)
            target = over and 1 or (tonumber(db.fadeAlpha) or 0)
        end
        local a = self.alpha or 1
        if a ~= target then
            local step = dt / 0.2
            if a < target then a = math.min(target, a + step) else a = math.max(target, a - step) end
            self.alpha = a
            bar:SetAlpha(a)
        end
    end)
    M.fader = f
end

-- ---------------------------------------------------------------------------
-- Blizzard's bars
-- ---------------------------------------------------------------------------

local BLIZZ = { "MicroMenuContainer", "BagsBar", "MicroButtonAndBagsBar" }

-- Where Blizzard's micro menu and bags sat, once, as the default place.
local function CaptureDefault()
    if not ns.db or DB().pos or DB().autoPos then return end
    local l, r, t, b
    local uiS = UIParent:GetEffectiveScale()
    for _, name in ipairs(BLIZZ) do
        local f = _G[name]
        if f and f:IsVisible() and f:GetRight() then
            local s = f:GetEffectiveScale() / uiS
            local fl, fr, ft, fb = f:GetLeft() * s, f:GetRight() * s, f:GetTop() * s, f:GetBottom() * s
            l = l and math.min(l, fl) or fl
            r = r and math.max(r, fr) or fr
            t = t and math.max(t, ft) or ft
            b = b and math.min(b, fb) or fb
        end
    end
    -- Just above where they were: Ellesmere keeps showing its "Bags" and
    -- "Micro Menu" movers there in Unlock Mode, and ours must not hide under them.
    if r and t then
        DB().autoPos = { point = "BOTTOMRIGHT", relPoint = "BOTTOMLEFT",
            x = math.floor(r + 0.5), y = math.floor(t + 4.5) }
    end
end

-- v1.0.1: Blizzard's MicroMenuContainer and BagsBar are Edit Mode systems
-- (protected on WoW Forever). v1.0.0 moved them into a hidden frame of ours,
-- which broke Edit Mode and the movers around them. Now they are hidden the
-- way Ellesmere hides them itself: its Action Bars "Micro Menu Bar" and "Bag
-- Bar" set to Visibility "Hidden" (what you'd pick in its options), the old
-- values kept in WarUIGeneralDB.owned.menuBar and given back when Menu Bar
-- goes off. Without Ellesmere Action Bars: a plain Hide()/Show(), out of combat.
local EUI_KEYS = { MicroBar = "MicroMenuContainer", BagBar = "BagsBar" }

local function EAB()
    local mns = EllesmereUI and EllesmereUI._ModuleNS and EllesmereUI._ModuleNS.EllesmereUIActionBars
    local eab = mns and mns.EAB
    if eab and eab.db and eab.db.profile and type(eab.db.profile.bars) == "table"
        and eab.VisibilityCompat and eab.VisibilityCompat.ApplyMode then
        return eab
    end
end

local hiddenByUs = {}       -- frames we Hide()'d ourselves (no Ellesmere Action Bars)

local function TakeBlizzard()
    if InCombatLockdown() then M.takePending = true return end
    M.takePending = false
    CaptureDefault()
    local eab = EAB()
    local store = ns.OwnedStore("menuBar")
    if eab then
        if type(store.vis) ~= "table" then store.vis = {} end
        local changed = false
        for key in pairs(EUI_KEYS) do
            local s = eab.db.profile.bars[key]
            if s then
                local cur = s.barVisibility or (s.alwaysHidden and "never") or "always"
                if cur ~= "never" then
                    if store.vis[key] == nil then store.vis[key] = cur end
                    eab.VisibilityCompat.ApplyMode(s, "never")
                    changed = true
                end
            end
        end
        if changed and eab.RefreshRuntimeVisibility then
            local ok, err = pcall(eab.RefreshRuntimeVisibility, eab)
            if not ok then ns.Log("MENUBAR", "Ellesmere refresh failed: %s", tostring(err)) end
        end
    else
        for _, name in ipairs(BLIZZ) do
            local f = _G[name]
            if f and f:IsShown() then
                hiddenByUs[f] = true
                pcall(f.Hide, f)
            end
        end
    end
    -- A keyring button outside those bars (classic-era layout).
    local kr = _G.KeyRingButton
    if kr and kr:IsVisible() then
        hiddenByUs[kr] = true
        pcall(kr.Hide, kr)
    end
    if ns.db then PlaceBar() end
end

local function GiveBackBlizzard()
    if InCombatLockdown() then M.givePending = true return end
    M.givePending = false
    local eab = EAB()
    local store = ns.OwnedStore("menuBar")
    if eab and type(store.vis) == "table" then
        for key, mode in pairs(store.vis) do
            local s = eab.db.profile.bars[key]
            if s then eab.VisibilityCompat.ApplyMode(s, mode) end
        end
        store.vis = nil
        if eab.RefreshRuntimeVisibility then pcall(eab.RefreshRuntimeVisibility, eab) end
    end
    for f in pairs(hiddenByUs) do
        pcall(f.Show, f)
        hiddenByUs[f] = nil
    end
end

-- ---------------------------------------------------------------------------
-- Events
-- ---------------------------------------------------------------------------

local events = CreateFrame("Frame")
events:SetScript("OnEvent", function(_, event)
    if not M.active then return end
    if event == "PLAYER_REGEN_ENABLED" then
        if M.takePending then TakeBlizzard() end
        if pending then M.Layout() end
    elseif event == "BAG_UPDATE_DELAYED" or event == "BAG_UPDATE" then
        UpdateCount()
    elseif event == "BAG_CONTAINER_UPDATE" or event == "PLAYER_EQUIPMENT_CHANGED" then
        UpdateSlots(); UpdateCount()
    elseif event == "UNIT_PORTRAIT_UPDATE" or event == "PORTRAITS_UPDATED" then
        Tick()
    end
end)
local EVENTS = { "PLAYER_REGEN_ENABLED", "BAG_UPDATE_DELAYED", "BAG_CONTAINER_UPDATE",
                 "PLAYER_EQUIPMENT_CHANGED" }

local function ApplyVisibility()
    if InCombatLockdown() then pending = true return end
    UnregisterStateDriver(bar, "visibility")
    if DB().hideInCombat then
        RegisterStateDriver(bar, "visibility", "[combat] hide; show")
    else
        bar:Show()
    end
end

-- ---------------------------------------------------------------------------
-- EllesmereUI Unlock Mode
-- ---------------------------------------------------------------------------

local unlockRegistered = false
local function RegisterUnlock()
    if unlockRegistered or not (EllesmereUI and EllesmereUI.RegisterUnlockElements) then return end
    unlockRegistered = true
    EllesmereUI:RegisterUnlockElements({
        {
            key = "WarUI_MenuBar", label = "Menu Bar",
            getFrame = function() return bar end,
            getSize = function()
                if not bar then return 300, 32 end
                return bar:GetWidth(), bar:GetHeight()
            end,
            isHidden = function() return not bar or not ns.db or not ns.IsModuleEnabled("menuBar") end,
            savePosition = function(_, point, relPoint, x, y)
                if ns.db then DB().pos = { point = point, relPoint = relPoint or point, x = x, y = y } end
            end,
            loadPosition = function()
                if not ns.db then return nil end
                local p = DB().pos
                if type(p) == "table" and p.point then return p end
                return nil
            end,
            clearPosition = function() if ns.db then DB().pos = nil end end,
            applyPosition = function()
                if bar and ns.db and not InCombatLockdown() then PlaceBar() end
            end,
        },
    }, "WarUI_General")
    if EllesmereUI.RegisterUnlockModeListener then
        EllesmereUI:RegisterUnlockModeListener("WarUI_MenuBar", function(active)
            unlockActive = active and true or false
            if bar and unlockActive then bar:SetAlpha(1); if M.fader then M.fader.alpha = 1 end end
        end)
    end
end

function M.OpenUnlock()
    if InCombatLockdown() then ns.Print("Menu Bar: not in combat.") return end
    if EllesmereUI and EllesmereUI.OpenUnlockMode then
        pcall(EllesmereUI.OpenUnlockMode, EllesmereUI)
    end
end

-- ---------------------------------------------------------------------------
-- Module
-- ---------------------------------------------------------------------------

function M:Enable()
    if type(DB().hidden) ~= "table" then DB().hidden = {} end
    -- v1.0.1: the default place moved above Blizzard's bars (see CaptureDefault).
    if (tonumber(DB().posVersion) or 0) < 2 then
        DB().autoPos, DB().posVersion = nil, 2
    end
    -- v1.0.2: Ellesmere's icons by default (v1.0 had "flat", which drew nothing).
    if (tonumber(DB().iconVersion) or 0) < 2 then
        if DB().iconStyle == "flat" or DB().iconStyle == nil then DB().iconStyle = "ellesmere" end
        DB().iconVersion = 2
    end
    if InCombatLockdown() and not bar then
        -- Secure buttons can't be made in combat (a /reload mid-fight).
        M.active = true
        M.buildPending = true
        return
    end
    Build()
    bar:Show()
    bar:SetAlpha(1)
    if M.fader then M.fader.alpha = 1 end
    RegisterUnlock()
    SetupFader()
    for _, e in ipairs(EVENTS) do pcall(events.RegisterEvent, events, e) end
    pcall(events.RegisterUnitEvent, events, "UNIT_PORTRAIT_UPDATE", "player")
    M.active = true
    if not M.ticker then M.ticker = C_Timer.NewTicker(0.25, Tick) end
    -- Blizzard's bars once Edit Mode has put them in place (their spot is
    -- the bar's default position).
    C_Timer.After(1, function() if M.active then TakeBlizzard() end end)
end

function M:Apply()
    if M.buildPending then
        if InCombatLockdown() then return end
        M.buildPending = false
        M:Enable()
    end
    if not bar then return end
    for _, b in ipairs(micro) do
        local e = embedded[b.src]
        if EMBED[b.srcName] and not (e and e.tile) then Embed(b) end
    end
    M.Skin()
    M.Layout()
    ApplyVisibility()
    Tick()
end

function M:Disable()
    M.active = false
    events:UnregisterAllEvents()
    if bar and not InCombatLockdown() then
        UnregisterStateDriver(bar, "visibility")
        bar:Hide()
    elseif bar then
        bar:SetAlpha(0)             -- hidden for real after combat (below)
        M.hidePending = true
    end
    GiveBackBlizzard()
    if not Unembed() then M.unembedPending = true end
end

-- Late events (a Disable in combat gives Blizzard's bars back afterwards).
local late = CreateFrame("Frame")
late:RegisterEvent("PLAYER_REGEN_ENABLED")
late:SetScript("OnEvent", function()
    if M.givePending and not M.active then GiveBackBlizzard() end
    if M.unembedPending and not M.active then M.unembedPending = not Unembed() end
    if M.hidePending and not M.active and bar then
        M.hidePending = false
        UnregisterStateDriver(bar, "visibility")
        bar:Hide()
    end
    if M.buildPending and M.active then M:Apply() end
end)

-- ---------------------------------------------------------------------------
-- Settings page
-- ---------------------------------------------------------------------------

function M:BuildPage(_, parent, y, W)
    local _, h
    local function changed() ns.Apply() end
    local off = function() return not ns.IsModuleEnabled("menuBar") end
    local offTip = "Turn Menu Bar on first"
    local function Toggle(text, key, tip)
        return { type = "toggle", text = text, tooltip = tip,
            getValue = function() return DB()[key] == true end,
            setValue = function(v) DB()[key] = v and true or false; changed(); ns.Ellesmere.RefreshPage() end }
    end
    local function Slider(text, key, minV, maxV, step, tip)
        return { type = "slider", text = text, min = minV, max = maxV, step = step, tooltip = tip,
            getValue = function() return tonumber(DB()[key]) or minV end,
            setValue = function(v) DB()[key] = v; changed() end }
    end
    local function Color(text, colorKey, alphaKey)
        return { type = "colorpicker", text = text, hasAlpha = alphaKey ~= nil,
            getValue = function()
                local r, g, b = ns.HexToRGB(DB()[colorKey])
                return r, g, b, alphaKey and (tonumber(DB()[alphaKey]) or 1) or 1
            end,
            setValue = function(r, g, b, a)
                DB()[colorKey] = ns.RGBToHex(r, g, b)
                if alphaKey then DB()[alphaKey] = a or 1 end
                changed()
            end }
    end

    _, h = W:DualRow(parent, y,
        { type = "button", text = "Move (Unlock Mode)", width = 170,
          disabled = off, disabledTooltip = offTip,
          onClick = function() M.OpenUnlock() end },
        { type = "button", text = "Reset Position", width = 130,
          onClick = function() DB().pos = nil; changed() end }); y = y - h

    _, h = W:SectionHeader(parent, "LAYOUT", y); y = y - h
    _, h = W:DualRow(parent, y,
        Slider("Button Size", "size", 16, 48, 1),
        Slider("Spacing", "spacing", 0, 12, 1)); y = y - h
    _, h = W:DualRow(parent, y,
        Slider("Padding", "padding", 0, 12, 1, "Bar background around the buttons."),
        Slider("Buttons Per Row", "perRow", 0, 20, 1, "0 = everything on one line.")); y = y - h
    _, h = W:DualRow(parent, y,
        Toggle("Vertical", "vertical", "A column instead of a row."),
        Toggle("Bags First", "bagsFirst", "The bag button before the menu buttons instead of after.")); y = y - h
    _, h = W:DualRow(parent, y,
        Toggle("Separator", "separator", "A gap and a thin line between the menu and the bags (one-line layouts)."),
        { type = "spacer" }); y = y - h

    _, h = W:SectionHeader(parent, "LOOK", y); y = y - h
    _, h = W:DualRow(parent, y,
        { type = "dropdown", text = "Icon Style",
          tooltip = "EllesmereUI's micro menu icons, War UI's flat icons, or Blizzard's own micro menu art.",
          values = { ellesmere = "EllesmereUI", flat = "War UI (flat)", blizzard = "Blizzard" },
          order = { "ellesmere", "flat", "blizzard" },
          getValue = function() return DB().iconStyle or "ellesmere" end,
          setValue = function(v) DB().iconStyle = v; changed() end },
        Slider("Icon Size (%)", "iconScale", 0.4, 0.9, 0.02)); y = y - h
    _, h = W:DualRow(parent, y,
        { type = "dropdown", text = "Icon Color",
          values = { white = "White", class = "Class Color", accent = "Ellesmere Accent", custom = "Custom" },
          order = { "white", "class", "accent", "custom" },
          getValue = function() return DB().iconColor or "white" end,
          setValue = function(v) DB().iconColor = v; changed(); ns.Ellesmere.RefreshPage() end },
        { type = "colorpicker", text = "Custom Icon Color",
          disabled = function() return DB().iconColor ~= "custom" end,
          disabledTooltip = "Icon Color: Custom",
          getValue = function() return ns.HexToRGB(DB().iconHex) end,
          setValue = function(r, g, b) DB().iconHex = ns.RGBToHex(r, g, b); changed() end }); y = y - h
    _, h = W:DualRow(parent, y,
        Toggle("Accent On Hover", "hoverAccent", "The icon under the mouse turns Ellesmere's accent colour."),
        Color("Button Background", "btnColor", "btnAlpha")); y = y - h
    _, h = W:DualRow(parent, y,
        Color("Bar Background", "bgColor", "bgAlpha"),
        { type = "spacer" }); y = y - h
    _, h = W:SectionHeader(parent, "BAR BORDER", y); y = y - h
    y = ns.Border.Rows(W, parent, y, function() return DB().border end, changed)
    _, h = W:SectionHeader(parent, "BUTTON BORDER", y); y = y - h
    y = ns.Border.Rows(W, parent, y, function() return DB().buttonBorder end, changed)

    _, h = W:SectionHeader(parent, "BAGS", y); y = y - h
    _, h = W:DualRow(parent, y,
        Toggle("Show Free Slots", "showFree", "The number of free bag slots on the bag button (orange at 4 or less, red when full)."),
        Slider("Free Slots Text Size", "freeSize", 8, 16, 1)); y = y - h
    _, h = W:DualRow(parent, y,
        { type = "dropdown", text = "Keyring",
          tooltip = "How the bag button opens the keyring. Left-click always opens your bags.",
          values = { right = "Right-click", shift = "Shift-click" }, order = { "right", "shift" },
          getValue = function() return DB().keyringClick or "right" end,
          setValue = function(v) DB().keyringClick = v; changed() end },
        Toggle("Show Bag Slots", "bagSlots", "Your four equipped bags beside the bag button: drag a bag in or out, right-click to open one.")); y = y - h

    _, h = W:SectionHeader(parent, "VISIBILITY", y); y = y - h
    _, h = W:DualRow(parent, y,
        Toggle("Show On Mouseover", "mouseover", "The bar fades out until the mouse is over it."),
        Slider("Faded Opacity", "fadeAlpha", 0, 1, 0.05)); y = y - h
    _, h = W:DualRow(parent, y,
        Toggle("Hide In Combat", "hideInCombat"),
        { type = "spacer" }); y = y - h

    _, h = W:SectionHeader(parent, "MENU BUTTONS", y); y = y - h
    if #M.found == 0 then
        _, h = W:DualRow(parent, y,
            { type = "label", text = "The menu buttons are listed here once Menu Bar is on." }); y = y - h
    else
        local function Cell(name)
            return { type = "toggle", text = Label(name),
                getValue = function() return not DB().hidden[name] end,
                setValue = function(v) DB().hidden[name] = (not v) or nil; changed() end }
        end
        for i = 1, #M.found, 2 do
            local a, b = M.found[i], M.found[i + 1]
            _, h = W:DualRow(parent, y, Cell(a), b and Cell(b) or { type = "spacer" }); y = y - h
        end
        _, h = W:DualRow(parent, y,
            { type = "label", text = "Buttons Blizzard hides itself (e.g. Shop) stay out of the bar either way." }); y = y - h
    end

    if off() then
        _, h = W:DualRow(parent, y,
            { type = "label", text = "Menu Bar is off: turn it on at the top of this page." }); y = y - h
    end
    return y
end

SLASH_WARUIMENUBAR1 = "/waruimenu"
SlashCmdList.WARUIMENUBAR = function(msg)
    msg = tostring(msg or ""):lower()
    if msg == "reset" then DB().pos = nil; ns.Apply()
    elseif msg == "move" or msg == "unlock" then M.OpenUnlock()
    elseif msg == "debug" then
        local p = SavedPos()
        ns.Print(("Menu Bar: on=%s bar=%s shown=%s size=%dx%d at %s %s %d,%d; %d menu buttons; Ellesmere Action Bars=%s"):format(
            tostring(ns.IsModuleEnabled("menuBar")), tostring(bar ~= nil), tostring(bar and bar:IsShown()),
            bar and bar:GetWidth() or 0, bar and bar:GetHeight() or 0,
            p.point, p.relPoint or p.point, tonumber(p.x) or 0, tonumber(p.y) or 0, #micro, tostring(EAB() ~= nil)))
        ns.Print("menu buttons: " .. (#M.found > 0 and table.concat(M.found, ", ") or "none found"))
    else ns.Options.Open("menuBar") end
end

ns.Options.AddModule("menuBar")
