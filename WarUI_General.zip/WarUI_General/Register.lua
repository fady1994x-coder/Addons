-- WarUI_General / Register.lua - the last file in the toc.
-- Every module file has registered now: hand the one "General" row, with a
-- tab per module, to the War UI hub (which gives it to Ellesmere at
-- PLAYER_LOGIN).
local _, ns = ...

ns.Options.Finish()

-- War UI 2.0 folded these addons into WarUI_General. If one of the old
-- folders still loads, everything it does would run twice.
local OLD = { "WarUI_Campfire", "WarUI_Chat", "WarUI_QuestTracker", "WarUI_RXPTheme",
              "WarUI_GuideHighlight", "WarUI_ClickTweak" }
local f = CreateFrame("Frame")
f:RegisterEvent("PLAYER_LOGIN")
f:SetScript("OnEvent", function(self)
    self:UnregisterAllEvents()
    local found = {}
    for _, name in ipairs(OLD) do
        if C_AddOns.IsAddOnLoaded(name) then found[#found + 1] = name end
    end
    if #found > 0 then
        ns.Print("these old addons are now part of War UI - General and should be deleted from your AddOns folder: "
            .. table.concat(found, ", ") .. ". Disable them and /reload.")
    end
end)

-- War UI 2.2: Campfire and Raid Mana % were removed. Raid Mana % had set
-- Ellesmere Raid Frames' Power Text to "Percent" and kept the old value in
-- WarUIGeneralDB.owned.raidMana: give it back once, then forget it.
local cleanup = CreateFrame("Frame")
cleanup:RegisterEvent("PLAYER_LOGIN")
cleanup:SetScript("OnEvent", function(self)
    self:UnregisterAllEvents()
    local owned = type(WarUIGeneralDB) == "table" and WarUIGeneralDB.owned
    local store = owned and owned.raidMana
    if type(store) == "table" and store.saved then
        local eui = _G.EllesmereUI
        local rf = eui and eui._ModuleNS and eui._ModuleNS.EllesmereUIRaidFrames
        local p = rf and rf.db and rf.db.profile
        if p then
            p.powerTextMode = store.old and store.old.powerTextMode
            p.party_powerTextMode = store.old and store.old.party_powerTextMode
            if not InCombatLockdown() then
                if rf.ReloadFrames then pcall(rf.ReloadFrames) end
                if rf.ReloadPartyFrames then pcall(rf.ReloadPartyFrames) end
            end
            ns.Print("Raid Mana % was removed: Ellesmere's raid frame Power Text is back to how it was.")
        end
    end
    if owned then owned.raidMana = nil end
    -- Old module settings left in the profiles (harmless, just tidied).
    for _, prof in pairs(type(WarUIGeneralDB) == "table" and WarUIGeneralDB.profiles or {}) do
        if type(prof) == "table" and type(prof.modules) == "table" then
            prof.modules.campfire = nil
            prof.modules.raidMana = nil
        end
    end
end)
