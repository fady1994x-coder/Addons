-------------------------------------------------------------------------------
--  ClickTweak / Core.lua
--  Click-cast and hover keybindings for EllesmereUI's party and raid frames
--  only. Unit frames (player, target, focus) are never touched.
--
--  A binding is { key, type, action }. `key` uses WoW's binding format, the
--  same one Ellesmere's click-cast uses: "SHIFT-BUTTON1", "CTRL-R",
--  "ALT-MOUSEWHEELUP". Two routes, both out of combat:
--
--  Mouse buttons 1-5 (click attributes on the unit button):
--    unit button   "<mod>type<N>"      = "macro"
--                  "<mod>macrotext<N>" = "/click ClickTweakProxyK ctI"
--  Keyboard keys and the mouse wheel (override bindings while hovered):
--    a secure OnEnter wrapper on the unit button runs
--      SetBindingClick(true, key, "ClickTweakProxyK", "ctI")
--    and OnLeave clears them, so the key keeps its normal action elsewhere.
--  Both end on a proxy, a hidden SecureActionButton child of the unit
--  button: "*type-ctI" = target / focus / assist / spell / item / macro,
--  "useparent-unit" = true, so it acts on the frame's own unit.
--  Per-binding options: Only Cast Out of Combat (attribute driver on the
--  proxy's type), Active In (bindings outside the current context are not
--  applied at all), Dynamic Rez (rez a dead player, otherwise the spell).
--
--  Why the proxy: on this engine a SecureUnitButton drops raw "target" and
--  "togglemenu" actions for every click except plain left/right (see
--  EllesmereUI_Kick.lua:89-110 and :203-209). SecureActionButtons are not
--  gated, so Ellesmere routes through one; ClickTweak does the same. Menu
--  uses Ellesmere's own public menu route (EllesmereUI.GetSecureMenuMacro),
--  which carries its fix for the pet-menu misfire.
--
--  Coexisting with Ellesmere's click-casting (HoverCast):
--    * While it is enabled, plain left/right click belong to it (it rewrites
--      type1/type2 on every apply: NeutralizeDefaultClicks). Turned off,
--      ClickTweak may bind them too.
--    * A key Ellesmere already binds is skipped and flagged in the options;
--      whichever addon wrote last would otherwise win.
--    * Ellesmere only clears the attribute keys of its own bindings, so ours
--      survive its re-applies. We clear an attribute only while it still
--      holds the value we wrote.
-------------------------------------------------------------------------------
local ADDON, ns = ...

local ipairs, pairs, type, tostring = ipairs, pairs, type, tostring
local format = string.format
local InCombatLockdown = InCombatLockdown

-------------------------------------------------------------------------------
--  Constants
-------------------------------------------------------------------------------
ns.TYPE_LABEL = {
    general = "General",
    spell   = "Spell",
    macro   = "Macro",
    item    = "Item",
    custom  = "Custom Macro",
}

ns.GENERAL_ORDER = { "target", "focus", "assist", "menu" }
ns.GENERAL_LABEL = {
    target = "Target",
    focus  = "Focus",
    assist = "Assist",
    menu   = "Menu",
    rez    = "Dynamic Rez",
}

-- Icons: target/menu/macro are the ones Ellesmere's click-cast uses
-- (EUI_RaidFrames_ClickCast.lua ACTION_ICONS); focus/assist are classic
-- icons that exist on every client.
ns.GENERAL_ICON = {
    target = 132212,
    focus  = "Interface\\Icons\\Ability_TownWatch",
    assist = "Interface\\Icons\\Ability_Warrior_BattleShout",
    menu   = 5341597,
}
ns.MACRO_ICON = 134400

-- Equipped slots offered under Item (used by slot number, so swapping the
-- trinket keeps the binding).
ns.ITEM_SLOTS = {
    { slot = 13, label = "Trinket 1" },
    { slot = 14, label = "Trinket 2" },
    { slot = 10, label = "Hands" },
    { slot = 6,  label = "Waist" },
    { slot = 9,  label = "Wrist" },
    { slot = 2,  label = "Neck" },
    { slot = 15, label = "Back" },
    { slot = 1,  label = "Head" },
    { slot = 16, label = "Main Hand" },
    { slot = 17, label = "Off Hand" },
}

-- Content contexts for "Active In" (same set and test as Ellesmere's
-- click-cast: CC_CTX_ORDER / CurrentCtx).
ns.CTX_ORDER = { "solo", "party", "raid", "pvp" }

function ns.CurrentCtx()
    local _, instType = IsInInstance()
    if instType == "pvp" or instType == "arena" then return "pvp" end
    if IsInRaid() then return "raid" end
    if IsInGroup() then return "party" end
    return "solo"
end

-- b.ctx is nil (all contexts) or a set { solo = true, ... }.
function ns.ActiveHere(b)
    return not b.ctx or b.ctx[ns.CurrentCtx()] == true
end

-- Resurrection spells on WoW Forever, every rank, rank 1 first: the table
-- Ellesmere's click-cast uses there (EUI_RaidFrames_ClickCast.lua, the
-- IS_FOREVER REZ_BY_CLASS). Only the druid has a combat rez.
local REZ_BY_CLASS = {
    PRIEST  = { single = { 2006, 2010, 10880, 10881, 20770 } },
    PALADIN = { single = { 7328, 10322, 10324, 20772, 20773 } },
    SHAMAN  = { single = { 2008, 20609, 20610, 20776, 20777 } },
    DRUID   = { battle = { 20484, 20739, 20742, 20747, 20748 } },
}

-- The first rank found in the spellbook answers: every rank shares the name,
-- and /cast by name casts the highest rank known.
local function KnownName(ids)
    if not ids then return nil end
    local bank = Enum.SpellBookSpellBank and Enum.SpellBookSpellBank.Player
    for _, sid in ipairs(ids) do
        local known = true
        if C_SpellBook.IsSpellInSpellBook and bank then
            known = C_SpellBook.IsSpellInSpellBook(sid, bank, true)
        end
        if known then
            local name = C_Spell.GetSpellName(sid)
            if name then return name end
        end
    end
    return nil
end

-- Returns battleName, singleName (either may be nil) for this character.
function ns.RezSpells()
    local _, class = UnitClass("player")
    local kit = REZ_BY_CLASS[class]
    if not kit then return nil, nil end
    return KnownName(kit.battle), KnownName(kit.single)
end

-- True when the class has a rez at all (whether learned yet or not).
function ns.ClassHasRez()
    local _, class = UnitClass("player")
    return REZ_BY_CLASS[class] ~= nil
end

function ns.RezIcon()
    local _, class = UnitClass("player")
    local kit = REZ_BY_CLASS[class]
    local id = kit and (kit.battle or kit.single)[1]
    return id and C_Spell.GetSpellTexture(id) or "Interface\\Icons\\Spell_Holy_Resurrection"
end

-- Macro lines that resurrect the dead player under the mouse, then stop the
-- macro on a dead target so the rest (Dynamic Rez on a spell) never runs.
local function RezLines()
    local battle, single = ns.RezSpells()
    local lines = {}
    if battle then
        lines[#lines + 1] = "/cast [@mouseover,help,dead] " .. battle
    end
    if single then
        lines[#lines + 1] = "/cast [@mouseover,help,dead,nocombat] " .. single
    end
    if #lines == 0 then return nil end
    return lines
end

local DEFAULT_BINDINGS = {
    { key = "CTRL-BUTTON1", type = "general", action = "target" },
    { key = "CTRL-BUTTON2", type = "general", action = "menu" },
}

-------------------------------------------------------------------------------
--  Keys
-------------------------------------------------------------------------------
local MOUSE_BUTTON_MAP = {
    LeftButton = "BUTTON1", RightButton = "BUTTON2", MiddleButton = "BUTTON3",
    Button4 = "BUTTON4", Button5 = "BUTTON5",
}
ns.MOUSE_BUTTON_MAP = MOUSE_BUTTON_MAP

ns.MODIFIER_KEYS = {
    LSHIFT = true, RSHIFT = true, LCTRL = true, RCTRL = true,
    LALT = true, RALT = true, LMETA = true, RMETA = true,
}

-- WoW matches modifiers in ALT-CTRL-SHIFT order only; any other order never
-- fires (same note in Ellesmere's click-cast).
function ns.ModifierPrefix()
    local p = ""
    if IsAltKeyDown() then p = p .. "ALT-" end
    if IsControlKeyDown() then p = p .. "CTRL-" end
    if IsShiftKeyDown() then p = p .. "SHIFT-" end
    return p
end

-- Splits "ALT-SHIFT-R" into modifiers and key. Modifiers are peeled from the
-- front, never split on "-", because the key itself can be "-" (minus).
function ns.ParseKey(key)
    if type(key) ~= "string" or key == "" then return nil end
    local rest, mods = key, ""
    while true do
        local pre = (rest:sub(1, 4) == "ALT-" and "ALT-")
                 or (rest:sub(1, 5) == "CTRL-" and "CTRL-")
                 or (rest:sub(1, 6) == "SHIFT-" and "SHIFT-")
        if pre and #rest > #pre then
            mods = mods .. pre
            rest = rest:sub(#pre + 1)
        else
            break
        end
    end
    local btn = tonumber(rest:match("^BUTTON(%d)$") or "")
    return {
        mods = mods,
        key = rest,
        button = (btn and btn >= 1 and btn <= 5) and btn or nil,  -- click route
    }
end

local KEY_LABEL = {
    BUTTON1 = "Left Click", BUTTON2 = "Right Click", BUTTON3 = "Middle Click",
    BUTTON4 = "Button 4", BUTTON5 = "Button 5",
    MOUSEWHEELUP = "Wheel Up", MOUSEWHEELDOWN = "Wheel Down",
}

function ns.FormatKey(key)
    local k = ns.ParseKey(key)
    if not k then return "Not Bound" end
    local parts = {}
    for m in k.mods:gmatch("(%u+)%-") do
        parts[#parts + 1] = (m == "SHIFT" and "Shift") or (m == "CTRL" and "Ctrl") or (m == "ALT" and "Alt") or m
    end
    parts[#parts + 1] = KEY_LABEL[k.key] or (GetBindingText and GetBindingText(k.key)) or k.key
    return table.concat(parts, " + ")
end

-------------------------------------------------------------------------------
--  SavedVariables
--    ClickTweakProfilesDB (account):   { version, profiles = { [name] = { bindings } } }
--    ClickTweakDB         (character): { version, profile = name }
-------------------------------------------------------------------------------
local DEFAULT_PROFILE = "Default"
local DB_VERSION = 2

local function CopyBinding(b)
    local ctx
    if type(b.ctx) == "table" then
        ctx = {}
        for k, v in pairs(b.ctx) do ctx[k] = v end
    end
    return { key = b.key, type = b.type, action = b.action,
             oocOnly = b.oocOnly or nil, smartRez = b.smartRez or nil, ctx = ctx }
end

local function CopyBindings(list)
    local out = {}
    for i, b in ipairs(list) do out[i] = CopyBinding(b) end
    return out
end

-- "Trigger keybinds on key down" (account-wide; on unless turned off).
function ns.KeyDown()
    return not (ClickTweakProfilesDB and ClickTweakProfilesDB.keyUp)
end

function ns.SetKeyDown(on)
    ClickTweakProfilesDB.keyUp = (not on) or nil
    ns.Apply()
end

local function Profiles()
    return ClickTweakProfilesDB.profiles
end

local function EnsureProfile(name)
    local p = Profiles()
    if not p[name] then p[name] = { bindings = CopyBindings(DEFAULT_BINDINGS) } end
    return p[name]
end

-- 1.0 stored a binding as { mod = "CTRL-" | "NONE", button = 1-5 }.
local function OldToKey(mod, button)
    return ((mod == "NONE" or not mod) and "" or mod) .. "BUTTON" .. tostring(button)
end

-- Runs once at ADDON_LOADED, before the first Apply.
local function InitDB()
    if type(ClickTweakProfilesDB) ~= "table" then ClickTweakProfilesDB = {} end
    local acc = ClickTweakProfilesDB
    if type(acc.profiles) ~= "table" then acc.profiles = {} end

    -- Migration 1 -> 2, every profile on the account: mod + button become
    -- one key string. Idempotent (only touches entries that still have
    -- `button`), runs before any Apply.
    if (acc.version or 1) < 2 then
        for _, prof in pairs(acc.profiles) do
            if type(prof) == "table" and type(prof.bindings) == "table" then
                for _, b in ipairs(prof.bindings) do
                    if b.button and not b.key then
                        b.key = OldToKey(b.mod, b.button)
                    end
                    b.mod, b.button = nil, nil
                end
            end
        end
        acc.version = DB_VERSION
    end

    if type(ClickTweakDB) ~= "table" then ClickTweakDB = {} end
    local char = ClickTweakDB
    char.version = char.version or 1

    if type(char.profile) ~= "string" or not acc.profiles[char.profile] then
        char.profile = DEFAULT_PROFILE
    end
    EnsureProfile(char.profile)
end

-- Read on every call: never cache the table (profile switches replace it).
function ns.Bindings()
    if not (ClickTweakDB and ClickTweakProfilesDB) then return {} end
    local prof = Profiles()[ClickTweakDB.profile]
    return prof and prof.bindings or {}
end

-------------------------------------------------------------------------------
--  Profiles
-------------------------------------------------------------------------------
function ns.ActiveProfile()
    return ClickTweakDB and ClickTweakDB.profile or DEFAULT_PROFILE
end

function ns.ProfileNames()
    local out = {}
    for name in pairs(Profiles()) do out[#out + 1] = name end
    table.sort(out)
    return out
end

function ns.ProfileExists(name)
    return Profiles()[name] ~= nil
end

-- Returns a cleaned name, or nil and the reason.
function ns.CheckProfileName(name)
    name = (name or ""):gsub("^%s+", ""):gsub("%s+$", "")
    if name == "" then return nil, "The name is empty." end
    if #name > 32 then return nil, "The name is longer than 32 characters." end
    if name:find("[|%c]") then return nil, "The name contains characters that are not allowed." end
    if Profiles()[name] then return nil, "A profile with that name already exists." end
    return name
end

function ns.SetProfile(name)
    if not Profiles()[name] then return end
    ClickTweakDB.profile = name
    ns.Apply()
end

-- New profile with the default bindings; this character switches to it.
function ns.NewProfile(name)
    EnsureProfile(name)
    ns.SetProfile(name)
end

-- Replaces the active profile's bindings with a copy of another profile's.
function ns.CopyProfileInto(from)
    local src = Profiles()[from]
    if not src or from == ns.ActiveProfile() then return end
    Profiles()[ns.ActiveProfile()].bindings = CopyBindings(src.bindings)
    ns.Apply()
end

-- The active profile cannot be deleted. Other characters that used a deleted
-- profile fall back to "Default" at their next login (InitDB).
function ns.DeleteProfile(name)
    if name == ns.ActiveProfile() or not Profiles()[name] then return end
    Profiles()[name] = nil
end

function ns.ResetProfile()
    Profiles()[ns.ActiveProfile()].bindings = CopyBindings(DEFAULT_BINDINGS)
    ns.Apply()
end

-------------------------------------------------------------------------------
--  Export / import
--  Format 2: ClickTweak:2:<name>:<key>,<type>,<action>;...
--  Format 1 (ClickTweak 1.0): ClickTweak:1:<name>:<mod>,<button>,<type>,<action>;...
--  Every field is percent-encoded, so ":" "," ";" "|", spaces and line breaks
--  in a name or Custom macro text survive (and "|" never reaches WoW's escape
--  codes).
-------------------------------------------------------------------------------
local function Enc(s)
    -- Whitespace too: the import strips it, since pasting often adds some.
    return (tostring(s or ""):gsub("[%%:;,|%s]", function(c) return format("%%%02X", c:byte()) end))
end
local function Dec(s)
    return (s:gsub("%%(%x%x)", function(h) return string.char(tonumber(h, 16)) end))
end

-- Options as one short field: "o" out of combat only, "r" Dynamic Rez,
-- "x" followed by the Active In contexts (s solo, p party, r raid, v pvp).
local CTX_LETTER = { solo = "s", party = "p", raid = "r", pvp = "v" }
local LETTER_CTX = { s = "solo", p = "party", r = "raid", v = "pvp" }

local function FlagsOf(b)
    local f = (b.oocOnly and "o" or "") .. (b.smartRez and "r" or "")
    if b.ctx then
        f = f .. "x"
        for _, c in ipairs(ns.CTX_ORDER) do
            if b.ctx[c] then f = f .. CTX_LETTER[c] end
        end
    end
    return f
end

local function ApplyFlags(b, f)
    local head, ctx = f:match("^([or]*)x?([sprv]*)$")
    if not head then return false end
    b.oocOnly = head:find("o", 1, true) and true or nil
    b.smartRez = head:find("r", 1, true) and true or nil
    if f:find("x", 1, true) then
        b.ctx = {}
        for ch in ctx:gmatch(".") do b.ctx[LETTER_CTX[ch]] = true end
    end
    return true
end

function ns.Export(name)
    local prof = Profiles()[name]
    if not prof then return "" end
    local parts = {}
    for _, b in ipairs(prof.bindings) do
        parts[#parts + 1] = table.concat({ Enc(b.key), Enc(b.type), Enc(b.action), Enc(FlagsOf(b)) }, ",")
    end
    return "ClickTweak:2:" .. Enc(name) .. ":" .. table.concat(parts, ";")
end

local OLD_MODS = { NONE = true, ["SHIFT-"] = true, ["CTRL-"] = true, ["ALT-"] = true,
                   ["CTRL-SHIFT-"] = true, ["ALT-SHIFT-"] = true, ["ALT-CTRL-"] = true }

-- Returns { name = suggested name, bindings = list } or nil and the reason.
-- Every field is checked, so a damaged or hand-edited string cannot put
-- unknown values into the profile.
function ns.ParseImport(str)
    str = (str or ""):gsub("%s+", "")
    local ver, name, body = str:match("^ClickTweak:(%d+):([^:]*):(.*)$")
    if not ver then return nil, "This is not a ClickTweak export string." end
    if ver ~= "1" and ver ~= "2" then return nil, "This string is from a newer ClickTweak version." end
    local list = {}
    for entry in body:gmatch("[^;]+") do
        local bad = "The string is damaged (binding " .. (#list + 1) .. ")."
        local key, t, a
        local flagStr = ""
        if ver == "1" then
            local m, btn
            m, btn, t, a = entry:match("^([^,]*),([^,]*),([^,]*),([^,]*)$")
            if not m then return nil, bad end
            m, btn = Dec(m), tonumber(Dec(btn))
            if not OLD_MODS[m] or not btn or btn < 1 or btn > 5 then return nil, bad end
            key = OldToKey(m, btn)
        else
            local flags
            key, t, a, flags = entry:match("^([^,]*),([^,]*),([^,]*),?([^,]*)$")
            if not key then return nil, bad end
            key = Dec(key)
            if key == "" then key = nil elseif not ns.ParseKey(key) then return nil, bad end
            flagStr = Dec(flags)
        end
        t, a = Dec(t), Dec(a)
        if not ns.TYPE_LABEL[t] then return nil, bad end
        local b = { key = key, type = t, action = (a ~= "") and a or nil }
        if not ApplyFlags(b, flagStr) then return nil, bad end
        list[#list + 1] = b
    end
    return { name = Dec(name), bindings = list }
end

-- Creates the imported profile under a free name and switches to it.
function ns.ImportAs(parsed, name)
    Profiles()[name] = { bindings = CopyBindings(parsed.bindings) }
    ns.SetProfile(name)
end

-------------------------------------------------------------------------------
--  Ellesmere's click-casting (read only)
--  Reads Ellesmere's saved click-cast table. Assumed layout, from
--  EUI_RaidFrames_ClickCast.lua GetClickCastDB (ns.db.sv.clickCast) and
--  EllesmereUI_Lite.lua (db.sv = EllesmereUIDB). If the layout changes, the
--  checks find nothing and the in-game test shows it.
-------------------------------------------------------------------------------
local function EllesmereCC()
    local sv = EllesmereUIDB
    local cc = type(sv) == "table" and sv.clickCast
    return type(cc) == "table" and cc or nil
end

function ns.EllesmereCCEnabled()
    local cc = EllesmereCC()
    return cc ~= nil and cc.enabled == true
end

-- Ellesmere's spec id lookup (EUI_RaidFrames_ClickCast.lua GetCurrentSpecID).
local function CurrentSpecID()
    if not (C_SpecializationInfo and C_SpecializationInfo.GetSpecialization) then return nil end
    local idx = C_SpecializationInfo.GetSpecialization()
    local id = idx and C_SpecializationInfo.GetSpecializationInfo(idx)
    return (id and id ~= 0) and id or nil
end

-- True when Ellesmere's own click-casting binds this key right now.
function ns.EllesmereUsesKey(key)
    local cc = EllesmereCC()
    if not cc or not cc.enabled then return false end
    local function scan(list)
        if type(list) ~= "table" then return false end
        for _, eb in ipairs(list) do
            if type(eb) == "table" and eb.key == key and eb.enabled ~= false then
                return true
            end
        end
        return false
    end
    if scan(cc.globals) then return true end
    if type(cc.specs) == "table" then
        local id = CurrentSpecID()
        if id then
            if scan(cc.specs[id]) then return true end
        else
            -- No spec id (possible on this client): any spec list counts.
            for _, list in pairs(cc.specs) do
                if scan(list) then return true end
            end
        end
    end
    return false
end

-------------------------------------------------------------------------------
--  Status
-------------------------------------------------------------------------------
-- "ok", "unbound", "incomplete", "reserved", "duplicate" or "ellesmere".
function ns.Status(index)
    local list = ns.Bindings()
    local b = list[index]
    if not b then return "incomplete" end
    if not b.action or b.action == "" then return "incomplete" end
    if b.type == "general" and b.action == "rez" and not RezLines() then return "norez" end
    local k = ns.ParseKey(b.key)
    if not k then return "unbound" end
    if not ns.ActiveHere(b) then return "inactive" end
    if k.mods == "" and (k.button == 1 or k.button == 2) and ns.EllesmereCCEnabled() then
        return "reserved"
    end
    -- Only bindings active right now compete for a key: one key can be
    -- Renew in a party and something else in a raid.
    for i = 1, index - 1 do
        if list[i].key == b.key and ns.ActiveHere(list[i]) then return "duplicate" end
    end
    if ns.EllesmereUsesKey(b.key) then return "ellesmere" end
    return "ok"
end

ns.STATUS_TEXT = {
    unbound    = "Not bound yet: set a keybind.",
    incomplete = "Write the macro text.",
    reserved   = "Plain left/right click belongs to Ellesmere's click-casting while it is on. " ..
                 "Add a modifier, or turn off Enable Click Casting in Raid Frames > HoverCast.",
    ellesmere  = "Ellesmere's click-casting already uses this key. Not applied.",
    duplicate  = "Another binding above already uses this key. Not applied.",
    inactive   = "Not active here (see Active In). The key keeps its normal action.",
    norez      = "Your character has no resurrection spell yet.",
}

-------------------------------------------------------------------------------
--  Frames: Ellesmere's party/raid buttons only
-------------------------------------------------------------------------------
-- Header and button names from EUI_RaidFrames_Layout.lua:83,125 and
-- EUI_RaidFrames_Party.lua:564,616. Every child is pre-created by Ellesmere
-- (5 per group, 40 flat, 5 party), so a scan out of combat finds them all.
local function AddHeaderChildren(hdr, out)
    if type(hdr) ~= "table" then return end
    local i = 1
    while hdr[i] do
        local btn = hdr[i]
        if type(btn) == "table" and btn.SetAttribute then out[#out + 1] = btn end
        i = i + 1
    end
end

local function CollectFrames()
    local out = {}
    for g = 1, 8 do AddHeaderChildren(_G["ERFGroupHeader" .. g], out) end
    AddHeaderChildren(_G.ERFFlatHeader, out)
    AddHeaderChildren(_G.ERFPartyHeader, out)
    local selfBtn = _G.ERFPartySelfButton
    if type(selfBtn) == "table" and selfBtn.SetAttribute then out[#out + 1] = selfBtn end
    return out
end

-------------------------------------------------------------------------------
--  Proxies
--  Two per unit button, both hidden SecureActionButton children acting on
--  the button's own unit ("useparent-unit"):
--    click proxy - reached by "/click" from the unit button's macro. /click
--                  sends an up-click, so it acts on the up-click regardless of
--                  the key-down CVar (as Ellesmere's proxies do,
--                  EllesmereUI_Kick.lua:197).
--    key proxy   - reached by the hover key bindings; acts on key down or key
--                  up as "Trigger Keybinds on Down" says.
-------------------------------------------------------------------------------
local clickProxies = setmetatable({}, { __mode = "k" })  -- unit button -> proxy
local keyProxies   = setmetatable({}, { __mode = "k" })
local proxySlots   = setmetatable({}, { __mode = "k" })  -- proxy -> highest slot written
local proxyCount   = 0

local PROXY_ATTRS = { "type", "spell", "item", "macro", "macrotext" }
local KEY_PROXY_ATTR = "clicktweak-keyproxy"   -- unit button -> key proxy's name

local function NewProxy(frame, prefix)
    proxyCount = proxyCount + 1
    -- Named on purpose: "/click" and SetBindingClick find it by name.
    local p = CreateFrame("Button", prefix .. proxyCount, frame, "SecureActionButtonTemplate")
    p:SetSize(1, 1)
    p:SetAlpha(0)
    p:EnableMouse(false)          -- reached through /click and key bindings only
    p:SetAttribute("useparent-unit", true)
    return p
end

local function ClickProxy(frame)
    local p = clickProxies[frame]
    if not p then
        p = NewProxy(frame, "ClickTweakProxy")
        p:RegisterForClicks("AnyUp")
        p:SetAttribute("useOnKeyDown", false)
        clickProxies[frame] = p
    end
    return p
end

local function KeyProxy(frame)
    local p = keyProxies[frame]
    if not p then
        p = NewProxy(frame, "ClickTweakKeyProxy")
        p:RegisterForClicks("AnyDown", "AnyUp")
        keyProxies[frame] = p
        -- Read by the hover snippet, which runs in the restricted environment
        -- and can reach the proxy only by name.
        frame:SetAttribute(KEY_PROXY_ATTR, p:GetName())
    end
    return p
end

local function SetIfChanged(frame, attr, value)
    if frame:GetAttribute(attr) ~= value then frame:SetAttribute(attr, value) end
end

-- The action type, gated for "Only Cast Out of Combat" by an attribute driver:
-- the real type out of combat, inert "none" in combat (Ellesmere's
-- SetGatedType does the same). The driver works in combat; only setting it
-- up needs to happen out of combat.
local function SetType(p, attr, value, oocOnly)
    UnregisterAttributeDriver(p, attr)
    if oocOnly then
        RegisterAttributeDriver(p, attr, "[combat] none; " .. value)
    else
        SetIfChanged(p, attr, value)
    end
end

-- Macro text for a spell with Dynamic Rez: rez a dead player, otherwise the
-- spell. Macros only reach the unit through @mouseover; on a party/raid frame
-- that is the frame being clicked or hovered.
local function SmartRezText(spell)
    local lines = RezLines()
    if not lines then return nil end
    lines[#lines + 1] = "/stopmacro [@mouseover,dead]"
    lines[#lines + 1] = "/cast [@mouseover] " .. spell
    return table.concat(lines, "\n")
end

-- Writes one binding's action onto proxy `p` as virtual button "ct<slot>".
-- Returns true when the proxy can run it.
local function ProxyAction(p, b, slot)
    local sfx = "-ct" .. slot
    local t, a, ooc = b.type, b.action, b.oocOnly
    if t == "general" and a == "rez" then
        local lines = RezLines()
        if not lines then return false end
        SetType(p, "*type" .. sfx, "macro", ooc)
        SetIfChanged(p, "*macrotext" .. sfx, table.concat(lines, "\n"))
    elseif t == "general" and a == "menu" then
        -- Keys, or clicks without Ellesmere's menu route (see ApplyFrame).
        SetType(p, "*type" .. sfx, "togglemenu", ooc)
    elseif t == "general" then
        SetType(p, "*type" .. sfx, a, ooc)              -- target / focus / assist
    elseif t == "spell" and b.smartRez and SmartRezText(a) then
        SetType(p, "*type" .. sfx, "macro", ooc)
        SetIfChanged(p, "*macrotext" .. sfx, SmartRezText(a))
    elseif t == "spell" then
        SetType(p, "*type" .. sfx, "spell", ooc)
        SetIfChanged(p, "*spell" .. sfx, a)              -- by name: highest known rank
    elseif t == "item" then
        local slotNum = a:match("^slot:(%d+)$")
        local name = a:match("^item:(.+)$")
        SetType(p, "*type" .. sfx, "item", ooc)
        SetIfChanged(p, "*item" .. sfx, slotNum or name)
    elseif t == "macro" then
        SetType(p, "*type" .. sfx, "macro", ooc)
        SetIfChanged(p, "*macro" .. sfx, a)
    elseif t == "custom" then
        SetType(p, "*type" .. sfx, "macro", ooc)
        SetIfChanged(p, "*macrotext" .. sfx, a)
    else
        return false
    end
    if (proxySlots[p] or 0) < slot then proxySlots[p] = slot end
    return true
end

local function ClearProxy(p)
    if not p then return end
    local n = proxySlots[p]
    if not n then return end
    for s = 1, n do
        UnregisterAttributeDriver(p, "*type-ct" .. s)
        for _, attr in ipairs(PROXY_ATTRS) do
            p:SetAttribute("*" .. attr .. "-ct" .. s, nil)
        end
    end
    proxySlots[p] = nil
end

-------------------------------------------------------------------------------
--  Hover keybindings (keyboard keys and the mouse wheel)
--  One secure header owns the override bindings. Each unit button gets an
--  OnEnter/OnLeave wrapper (once) that runs the header's current snippet:
--  enter sets every key binding to this button's key proxy, leave clears
--  them. The snippet is rewritten on every Apply, so the wrappers never
--  change. A state driver clears them too when nothing is under the mouse
--  any more (a frame hidden while hovered gets no OnLeave).
-------------------------------------------------------------------------------
local header
local wrapped = setmetatable({}, { __mode = "k" })

local ENTER_BODY = [[control:RunFor(self, control:GetAttribute("ct_enter"))]]
local LEAVE_BODY = [[control:ClearBindings()]]

local function EnsureHeader()
    if header then return header end
    header = CreateFrame("Frame", "ClickTweakHeader", UIParent, "SecureHandlerStateTemplate")
    header:SetAttribute("ct_enter", "")
    header:SetAttribute("_onstate-ctmouse", [[
        if newstate == "off" then self:ClearBindings() end
    ]])
    RegisterStateDriver(header, "ctmouse", "[@mouseover,exists] on; off")
    return header
end

local function WrapFrame(frame)
    if wrapped[frame] then return end
    wrapped[frame] = true
    local h = EnsureHeader()
    h:WrapScript(frame, "OnEnter", ENTER_BODY)
    h:WrapScript(frame, "OnLeave", LEAVE_BODY)
end

-- Body run with self = the hovered unit button, control = the header.
local function BuildEnterSnippet(keyBindings)
    if #keyBindings == 0 then return "" end
    local lines = {
        [[local p = self:GetAttribute("]] .. KEY_PROXY_ATTR .. [[")]],
        [[if not p then return end]],
    }
    for _, kb in ipairs(keyBindings) do
        lines[#lines + 1] = format([[control:SetBindingClick(true, %q, p, %q)]], kb.key, "ct" .. kb.slot)
    end
    return table.concat(lines, "\n")
end

-------------------------------------------------------------------------------
--  Apply
-------------------------------------------------------------------------------
-- frame -> { [attr] = value we wrote }, so a later apply removes only ours.
local written = setmetatable({}, { __mode = "k" })

local function ApplyFrame(frame, clicks, keys, keyDown)
    local prev = written[frame]
    local now = {}

    -- Stale proxy slots go first; the active ones are rewritten below.
    ClearProxy(clickProxies[frame])
    ClearProxy(keyProxies[frame])

    for _, entry in ipairs(clicks) do
        local b, slot, k = entry.b, entry.slot, entry.k
        local text
        if b.type == "general" and b.action == "menu" and EllesmereUI.GetSecureMenuMacro then
            -- Ellesmere's menu route; it never reaches our proxy, so the
            -- out-of-combat gate goes in the macro.
            text = EllesmereUI.GetSecureMenuMacro(frame)
            if b.oocOnly then text = "/stopmacro [combat]\n" .. text end
        else
            local p = ClickProxy(frame)
            if ProxyAction(p, b, slot) then text = format("/click %s ct%d", p:GetName(), slot) end
        end
        if text then
            local prefix = k.mods:lower()
            now[prefix .. "type" .. k.button] = "macro"
            now[prefix .. "macrotext" .. k.button] = text
        end
    end

    if #keys > 0 then
        local p = KeyProxy(frame)
        SetIfChanged(p, "useOnKeyDown", keyDown)
        for _, entry in ipairs(keys) do ProxyAction(p, entry.b, entry.slot) end
        WrapFrame(frame)
    end

    -- Remove what we wrote last time and no longer want. Skip attributes that
    -- someone else (Ellesmere) has since overwritten.
    if prev then
        for attr, val in pairs(prev) do
            if now[attr] == nil and frame:GetAttribute(attr) == val then
                frame:SetAttribute(attr, nil)
            end
        end
    end
    for attr, val in pairs(now) do
        SetIfChanged(frame, attr, val)
    end
    written[frame] = now
end

local events = CreateFrame("Frame")
local pendingCombat = false

-- Secure attributes can only change out of combat; a change made in combat
-- is applied on PLAYER_REGEN_ENABLED and reads the settings at that moment.
function ns.Apply()
    if not (ClickTweakDB and ClickTweakProfilesDB) then return end
    if InCombatLockdown() then
        pendingCombat = true
        events:RegisterEvent("PLAYER_REGEN_ENABLED")
        return
    end

    local clicks, keys = {}, {}
    for i, b in ipairs(ns.Bindings()) do
        if ns.Status(i) == "ok" then
            local k = ns.ParseKey(b.key)
            local entry = { b = b, slot = i, k = k, key = b.key }
            if k.button then clicks[#clicks + 1] = entry else keys[#keys + 1] = entry end
        end
    end

    -- Old overrides first: they may point at slots rewritten below.
    if header then
        header:Execute([[self:ClearBindings()]])
        header:SetAttribute("ct_enter", "")
    end
    local keyDown = ns.KeyDown()
    for _, frame in ipairs(CollectFrames()) do
        ApplyFrame(frame, clicks, keys, keyDown)
    end
    if #keys > 0 then
        EnsureHeader():SetAttribute("ct_enter", BuildEnterSnippet(keys))
    end
end

-- One pending timer at a time: roster events come in bursts.
local scheduled = false
local function ScheduleApply(delay)
    if scheduled then return end
    scheduled = true
    C_Timer.After(delay, function()
        scheduled = false
        ns.Apply()
    end)
end
ns.ScheduleApply = ScheduleApply

-------------------------------------------------------------------------------
--  Names and icons for the options page
-------------------------------------------------------------------------------
local function SlotLabel(slot)
    for _, s in ipairs(ns.ITEM_SLOTS) do
        if s.slot == slot then return s.label end
    end
    return "Slot " .. slot
end

function ns.NameOf(b)
    local t, a = b.type, b.action
    if t == "general" then return ns.GENERAL_LABEL[a] or a or "" end
    if t == "custom" then return "Custom Macro" end
    if t == "item" and a then
        local slot = tonumber(a:match("^slot:(%d+)$") or "")
        if slot then return SlotLabel(slot) end
        return a:match("^item:(.+)$") or a
    end
    return a or ""
end

function ns.IconOf(b)
    local t, a = b.type, b.action
    if t == "general" and a == "rez" then return ns.RezIcon() end
    if t == "general" then return ns.GENERAL_ICON[a] or ns.MACRO_ICON end
    if t == "spell" and a then
        return (C_Spell.GetSpellTexture and C_Spell.GetSpellTexture(a)) or ns.MACRO_ICON
    end
    if t == "macro" and a then
        local idx = GetMacroIndexByName(a)
        local icon = idx and idx > 0 and select(2, GetMacroInfo(idx))
        return icon or ns.MACRO_ICON
    end
    if t == "item" and a then
        local slot = tonumber(a:match("^slot:(%d+)$") or "")
        if slot then
            return GetInventoryItemTexture("player", slot) or "Interface\\PaperDoll\\UI-Backpack-EmptySlot"
        end
        local icon = select(10, C_Item.GetItemInfo(a:match("^item:(.+)$") or a))
        return icon or ns.MACRO_ICON
    end
    return ns.MACRO_ICON
end

-------------------------------------------------------------------------------
--  Lists for the Add Binding popup: { action, name, icon }
-------------------------------------------------------------------------------
-- Spellbook enumeration, same API path Ellesmere uses on this client
-- (EUI_RaidFrames_ClickCast.lua CC_GetClassSpells): class/spec tabs only,
-- no passives, one entry per name.
function ns.GetSpells()
    local out, seen = {}, {}
    local bank = Enum.SpellBookSpellBank and Enum.SpellBookSpellBank.Player
    if not (C_SpellBook and bank and C_SpellBook.GetNumSpellBookSkillLines) then return out end
    for tab = 1, C_SpellBook.GetNumSpellBookSkillLines() do
        local info = C_SpellBook.GetSpellBookSkillLineInfo(tab)
        local tabName = info and info.name or ""
        local isGeneral = (tabName == "General" or tabName == GENERAL or tabName == "")
        local offSpec = info and info.offSpecID and info.offSpecID ~= 0
        if info and not isGeneral and not offSpec and not info.shouldHide then
            local first = (info.itemIndexOffset or 0) + 1
            local last = (info.itemIndexOffset or 0) + (info.numSpellBookItems or 0)
            for si = first, last do
                local kind, actionId, spellId = C_SpellBook.GetSpellBookItemType(si, bank)
                if kind == Enum.SpellBookItemType.Spell then
                    local sid = spellId or actionId
                    local passive = sid and C_Spell.IsSpellPassive and C_Spell.IsSpellPassive(sid)
                    local name = sid and not passive and C_Spell.GetSpellName(sid)
                    if name and not seen[name] then
                        seen[name] = true
                        out[#out + 1] = { action = name, name = name, icon = C_Spell.GetSpellTexture(sid) }
                    end
                end
            end
        end
    end
    table.sort(out, function(x, y) return x.name < y.name end)
    return out
end

-- Account macros, then character macros.
function ns.GetMacros()
    local out = {}
    local numGlobal, numChar = GetNumMacros()
    local base = MAX_ACCOUNT_MACROS or 120
    local function add(i)
        local name, icon = GetMacroInfo(i)
        if name then out[#out + 1] = { action = name, name = name, icon = icon } end
    end
    for i = 1, numGlobal or 0 do add(i) end
    for i = base + 1, base + (numChar or 0) do add(i) end
    return out
end

-- Equipped slots (always listed) plus on-use items in the bags, by name.
function ns.GetItems()
    local out = {}
    for _, s in ipairs(ns.ITEM_SLOTS) do
        local b = { type = "item", action = "slot:" .. s.slot }
        out[#out + 1] = { action = b.action, name = s.label, icon = ns.IconOf(b) }
    end
    if C_Container then
        local seen = {}
        for bag = 0, 4 do
            for slot = 1, C_Container.GetContainerNumSlots(bag) or 0 do
                local info = C_Container.GetContainerItemInfo(bag, slot)
                local itemID = info and info.itemID
                if itemID and not seen[itemID] and C_Item.GetItemSpell(itemID) then
                    seen[itemID] = true
                    local name = C_Item.GetItemInfo(itemID)
                    if name then
                        out[#out + 1] = { action = "item:" .. name, name = name, icon = info.iconFileID }
                    end
                end
            end
        end
    end
    return out
end

-------------------------------------------------------------------------------
--  Events
-------------------------------------------------------------------------------
events:RegisterEvent("ADDON_LOADED")
events:RegisterEvent("PLAYER_ENTERING_WORLD")
events:RegisterEvent("GROUP_ROSTER_UPDATE")
events:SetScript("OnEvent", function(self, event, arg1)
    if event == "ADDON_LOADED" then
        if arg1 == ADDON then InitDB() end
    elseif event == "PLAYER_ENTERING_WORLD" then
        -- Ellesmere builds its headers in its own OnEnable; give it a moment.
        ScheduleApply(1)
    elseif event == "GROUP_ROSTER_UPDATE" then
        -- Picks up a header set Ellesmere built later (Merge Groups switch)
        -- and repairs a key Ellesmere cleared after both addons bound it.
        ScheduleApply(0.5)
    elseif event == "PLAYER_REGEN_ENABLED" then
        self:UnregisterEvent("PLAYER_REGEN_ENABLED")
        if pendingCombat then
            pendingCombat = false
            ns.Apply()
        end
    end
end)
