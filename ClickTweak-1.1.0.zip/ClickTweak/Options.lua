-------------------------------------------------------------------------------
--  ClickTweak / Options.lua
--  Settings pages in the EllesmereUI panel through the public plugin API
--  (EllesmereUI/PLUGINS_API.md). The Bindings page follows the layout of
--  Ellesmere's own HoverCast page: a list of binding tiles on the left, the
--  selected binding's options on the right, and an icon grid to add one.
--  Built only from EllesmereUI's public helpers (MakeFont, SolidTex,
--  MakeBorder, BuildDropdownControl, Widgets, popups, tooltips); Ellesmere's
--  own page code is private to its addon.
-------------------------------------------------------------------------------
local ADDON, ns = ...

local PLUGIN_ID  = "ClickTweak"
local MODULE_KEY = "Bindings"

local TILE_H   = 56
local ICON_SZ  = 36
local ROW_H    = 50

-- Rebuild the visible page so it shows the current data.
-- Deferred one frame so the click handler that changed the data finishes first.
local function Refresh()
    C_Timer.After(0, function()
        local key = EllesmereUI.GetPluginModuleKey(PLUGIN_ID, MODULE_KEY)
        if not key then return end
        EllesmereUI:InvalidateModulePageCache(key)
        if EllesmereUI:GetActiveModule() == key then
            EllesmereUI:RefreshPage(true)
        end
    end)
end

local function Changed()
    ns.Apply()
    Refresh()
end

-------------------------------------------------------------------------------
--  Small helpers
-------------------------------------------------------------------------------
local function Accent()
    local c = EllesmereUI.ELLESMERE_GREEN or { r = 0.05, g = 0.82, b = 0.62 }
    return c.r, c.g, c.b
end

local function Border(frame, a)
    return EllesmereUI.MakeBorder(frame, 1, 1, 1, a, EllesmereUI.PanelPP)
end

-- Ellesmere's own font (public EllesmereUI.MakeFont, EllesmereUI.lua:1066/2360),
-- so the page matches the rest of the panel.
local function Label(parent, text, size, r, g, b, a)
    local fs = EllesmereUI.MakeFont(parent, size or 12, nil, r or 1, g or 1, b or 1, a or 1)
    fs:SetJustifyH("LEFT")
    fs:SetText(text)
    return fs
end

local function Pad() return EllesmereUI.CONTENT_PAD or 20 end

-- A wrapped paragraph across the page; returns the new y.
local function Paragraph(parent, text, y, alpha, r, g, b)
    local w = parent:GetWidth() - Pad() * 2
    local fs = Label(parent, text, 12, r or 1, g or 1, b or 1, alpha or 0.7)
    fs:SetWidth(w - 20)
    fs:SetSpacing(4)
    fs:SetPoint("TOPLEFT", parent, "TOPLEFT", Pad() + 10, y - 6)
    return y - (fs:GetStringHeight() or 40) - 16
end

-- Icon with the thin dark frame Ellesmere puts on its tile icons.
local function IconBox(parent, size, texture)
    local f = CreateFrame("Frame", nil, parent)
    f:SetSize(size, size)
    local t = f:CreateTexture(nil, "ARTWORK")
    t:SetAllPoints()
    t:SetTexCoord(0.08, 0.92, 0.08, 0.92)
    t:SetTexture(texture)
    EllesmereUI.MakeBorder(f, 0, 0, 0, 0.6, EllesmereUI.PanelPP)
    return f, t
end

-- Filled accent button, like Ellesmere's "Add Global Binding".
local function AccentButton(parent, w, h, text, onClick)
    local r, g, b = Accent()
    local btn = CreateFrame("Button", nil, parent)
    btn:SetSize(w, h)
    btn:SetFrameLevel(parent:GetFrameLevel() + 2)
    local bg = btn:CreateTexture(nil, "BACKGROUND")
    bg:SetAllPoints()
    bg:SetColorTexture(r, g, b, 0.8)
    local lbl = Label(btn, text, 12, 1, 1, 1, 1)
    lbl:SetPoint("CENTER")
    btn:SetScript("OnEnter", function() bg:SetColorTexture(r, g, b, 1) end)
    btn:SetScript("OnLeave", function() bg:SetColorTexture(r, g, b, 0.8) end)
    btn:SetScript("OnClick", onClick)
    return btn
end

-- Dropdown values for profile names (data: never translated).
local function ProfileValues(excludeActive)
    local values, order = { _noLoc = true }, {}
    for _, name in ipairs(ns.ProfileNames()) do
        if not (excludeActive and name == ns.ActiveProfile()) then
            values[name] = name
            order[#order + 1] = name
        end
    end
    if #order == 0 then
        values[""] = "(no other profiles)"
        order[1] = ""
    end
    values.__none = "Choose..."
    return values, order
end

local function Info(title, text)
    EllesmereUI:ShowInfoPopup({ title = title, content = text })
end

-- Multi-line text box with mouse-wheel scrolling inside `parent`, `w` wide.
-- Returns the holder frame and the EditBox.
local function TextArea(parent, w, h)
    local holder = CreateFrame("Frame", nil, parent)
    holder:SetSize(w, h)
    local bg = holder:CreateTexture(nil, "BACKGROUND")
    bg:SetAllPoints()
    bg:SetColorTexture(0, 0, 0, 0.5)
    Border(holder, 0.15)

    local sf = CreateFrame("ScrollFrame", nil, holder)
    sf:SetPoint("TOPLEFT", 10, -8)
    sf:SetPoint("BOTTOMRIGHT", -10, 8)
    local eb = CreateFrame("EditBox", nil, sf)
    eb:SetMultiLine(true)
    eb:SetAutoFocus(false)
    eb:SetMaxLetters(0)
    eb:SetFontObject("ChatFontNormal")    -- needs a font object before SetFont
    eb:SetFont(EllesmereUI.EXPRESSWAY, 12, "")
    eb:SetWidth(w - 20)
    sf:SetScrollChild(eb)
    sf:EnableMouseWheel(true)
    sf:SetScript("OnMouseWheel", function(self, delta)
        local v = self:GetVerticalScroll() - delta * 30
        v = math.max(0, math.min(v, self:GetVerticalScrollRange()))
        self:SetVerticalScroll(v)
    end)
    eb:SetScript("OnEscapePressed", eb.ClearFocus)
    holder:EnableMouse(true)
    holder:SetScript("OnMouseDown", function() eb:SetFocus() end)
    return holder, eb
end

-- Full-width text box on a page at `y`; returns the EditBox.
local function MultiBox(parent, y, h)
    local holder, eb = TextArea(parent, parent:GetWidth() - Pad() * 2, h)
    holder:SetPoint("TOPLEFT", parent, "TOPLEFT", Pad(), y)
    return eb
end

-------------------------------------------------------------------------------
--  What a binding does, in words
-------------------------------------------------------------------------------
local GENERAL_DESC = {
    rez    = "Resurrects the player if dead (out of combat; Rebirth also in combat).",
    target = "Targets the player.",
    focus  = "Sets the player as your focus.",
    assist = "Targets whatever the player is targeting.",
    menu   = "Opens the right-click menu for the player.",
}

-- Returns text, isWarning.
local function Describe(b)
    local a, what = b.action, ""
    if b.type == "general" then
        what = GENERAL_DESC[a] or ""
    elseif b.type == "spell" and b.smartRez then
        what = "Casts " .. a .. " on the player, or resurrects them if dead."
    elseif b.type == "spell" then
        what = "Casts " .. a .. " on the player."
    elseif b.type == "item" then
        what = "Uses the item. If it needs a target, it goes on the player."
    elseif b.type == "macro" or b.type == "custom" then
        local body = a
        if b.type == "macro" then
            local idx = GetMacroIndexByName(a)
            body = (idx and idx > 0) and GetMacroBody(idx) or ""
        end
        if not (body or ""):lower():find("mouseover", 1, true) then
            return "No [@mouseover] in this macro: it acts on your current target, not the frame.", true
        end
        what = "Runs the macro on the player under the mouse."
    end
    if b.oocOnly then what = what .. " Out of combat only." end
    local k = ns.ParseKey(b.key)
    if k and k.button then
        return "Click a party or raid frame: " .. what
    end
    return "Press the key while the mouse is over a party or raid frame: " .. what
end

-------------------------------------------------------------------------------
--  Keybind capture button (same behaviour as Ellesmere's HoverCast one,
--  EUI_RaidFrames_ClickCast.lua BuildKeybindButton): left-click starts
--  listening, then a key, a click or the wheel becomes the binding; Escape
--  cancels; right-click clears.
-------------------------------------------------------------------------------
local function KeybindButton(parent, w, getKey, onSet, onClear)
    local E = EllesmereUI
    local btn = CreateFrame("Button", nil, parent)
    btn:SetSize(w, 30)
    btn:SetFrameLevel(parent:GetFrameLevel() + 2)
    btn:RegisterForClicks("AnyUp")
    local bg = E.SolidTex(btn, "BACKGROUND", E.DD_BG_R, E.DD_BG_G, E.DD_BG_B, E.DD_BG_A)
    bg:SetAllPoints()
    local brd = Border(btn, E.DD_BRD_A)
    local lbl = E.MakeFont(btn, 13, nil, 1, 1, 1)
    lbl:SetAlpha(E.DD_TXT_A)
    lbl:SetPoint("CENTER")

    local listening = false
    local function RefreshLabel()
        local key = getKey()
        lbl:SetText(key and ns.FormatKey(key) or "Not Bound")
    end
    RefreshLabel()

    local function Stop()
        listening = false
        btn:EnableKeyboard(false)
        btn:EnableMouseWheel(false)
        RefreshLabel()
    end

    btn:SetScript("OnClick", function(self, button)
        if not listening then
            if button == "LeftButton" then
                listening = true
                lbl:SetText("Press a key, click, or scroll...")
                btn:EnableKeyboard(true)
                btn:EnableMouseWheel(true)
            elseif button == "RightButton" then
                onClear()
            end
            return
        end
        -- While listening, any click is the binding (bare left-click too).
        local key = ns.MOUSE_BUTTON_MAP[button] or ("BUTTON" .. (button:match("%d+") or "1"))
        Stop()
        onSet(ns.ModifierPrefix() .. key)
    end)
    btn:SetScript("OnKeyDown", function(self, key)
        if not listening or ns.MODIFIER_KEYS[key] then
            self:SetPropagateKeyboardInput(true)
            return
        end
        self:SetPropagateKeyboardInput(false)
        if key == "ESCAPE" then Stop() return end
        Stop()
        onSet(ns.ModifierPrefix() .. key:upper())
    end)
    btn:SetScript("OnMouseWheel", function(self, delta)
        if not listening then return end
        Stop()
        onSet(ns.ModifierPrefix() .. (delta > 0 and "MOUSEWHEELUP" or "MOUSEWHEELDOWN"))
    end)
    btn:SetScript("OnEnter", function(self)
        bg:SetColorTexture(E.DD_BG_R, E.DD_BG_G, E.DD_BG_B, E.DD_BG_HA)
        if brd and brd.SetColor then brd:SetColor(1, 1, 1, 0.3) end
        E.ShowWidgetTooltip(self, "Left-click to set keybind.\nRight-click to clear.")
    end)
    btn:SetScript("OnLeave", function()
        bg:SetColorTexture(E.DD_BG_R, E.DD_BG_G, E.DD_BG_B, E.DD_BG_A)
        if brd and brd.SetColor then brd:SetColor(1, 1, 1, E.DD_BRD_A) end
        E.HideWidgetTooltip()
    end)
    btn:HookScript("OnHide", function() if listening then Stop() end end)
    return btn
end

-------------------------------------------------------------------------------
--  Add Binding popup: tabs + icon grid (like Ellesmere's "Add New")
-------------------------------------------------------------------------------
local selected     -- index in ns.Bindings() shown on the right
local popup        -- the open Add Binding popup, if any

local function ClosePopup()
    if popup then popup:Hide(); popup = nil end
end

local function GeneralEntries()
    local out = {}
    for _, a in ipairs(ns.GENERAL_ORDER) do
        out[#out + 1] = { type = "general", action = a, name = ns.GENERAL_LABEL[a], icon = ns.GENERAL_ICON[a] }
    end
    if ns.ClassHasRez() then
        out[#out + 1] = { type = "general", action = "rez", name = "Dynamic Rez", icon = ns.RezIcon() }
    end
    out[#out + 1] = { type = "custom", action = nil, name = "Custom Macro", icon = ns.MACRO_ICON }
    return out
end

local function TypedEntries(list, t)
    for _, e in ipairs(list) do e.type = t end
    return list
end

local TABS = {
    { label = "General", get = GeneralEntries },
    { label = "Spells",  get = function() return TypedEntries(ns.GetSpells(), "spell") end },
    { label = "Macros",  get = function() return TypedEntries(ns.GetMacros(), "macro") end },
    { label = "Items",   get = function() return TypedEntries(ns.GetItems(), "item") end },
}

local function OpenAddPopup(anchor)
    if popup then ClosePopup() return end
    local INSET, COLS, CELL, GAP = 15, 5, 56, 6
    local W = INSET * 2 + COLS * CELL + (COLS - 1) * GAP
    local H = 420

    local p = CreateFrame("Frame", nil, UIParent)
    p:SetSize(W, H)
    p:SetFrameStrata("FULLSCREEN_DIALOG")
    p:SetFrameLevel(200)
    p:SetPoint("TOPLEFT", anchor, "TOPRIGHT", 0, 0)
    p:SetClampedToScreen(true)
    p:EnableMouse(true)
    local bg = p:CreateTexture(nil, "BACKGROUND")
    bg:SetAllPoints()
    bg:SetColorTexture(0.067, 0.067, 0.067, 0.95)
    Border(p, 0.2)
    popup = p

    local tabW = (W - INSET * 2 - (#TABS - 1) * 4) / #TABS
    local tabBgs = {}
    local sf = CreateFrame("ScrollFrame", nil, p)
    sf:SetPoint("TOPLEFT", p, "TOPLEFT", INSET, -(INSET + 36))
    sf:SetPoint("BOTTOMRIGHT", p, "BOTTOMRIGHT", -INSET, INSET)
    sf:EnableMouseWheel(true)
    sf:SetScript("OnMouseWheel", function(self, delta)
        local v = self:GetVerticalScroll() - delta * 40
        v = math.max(0, math.min(v, self:GetVerticalScrollRange()))
        self:SetVerticalScroll(v)
    end)
    local child

    local function Show(tabIndex)
        local r, g, b = Accent()
        for i, t in ipairs(tabBgs) do
            if i == tabIndex then t:SetColorTexture(r, g, b, 0.25) else t:SetColorTexture(1, 1, 1, 0.05) end
        end
        if child then child:Hide() end
        child = CreateFrame("Frame", nil, sf)
        child:SetSize(W - INSET * 2, 10)
        sf:SetScrollChild(child)
        sf:SetVerticalScroll(0)

        local entries = TABS[tabIndex].get()
        if #entries == 0 then
            local fs = Label(child, "Nothing to show here.", 12, 1, 1, 1, 0.5)
            fs:SetPoint("TOPLEFT", 4, -6)
            return
        end
        for i, e in ipairs(entries) do
            local col, row = (i - 1) % COLS, math.floor((i - 1) / COLS)
            local cell = CreateFrame("Button", nil, child)
            cell:SetSize(CELL, CELL + 16)
            cell:SetPoint("TOPLEFT", child, "TOPLEFT", col * (CELL + GAP), -row * (CELL + 22))
            local hl = cell:CreateTexture(nil, "BACKGROUND")
            hl:SetAllPoints()
            hl:SetColorTexture(1, 1, 1, 0)
            local icon = IconBox(cell, 40, e.icon or ns.MACRO_ICON)
            icon:SetPoint("TOP", cell, "TOP", 0, -2)
            local name = Label(cell, e.name, 10, 1, 1, 1, 0.8)
            name:SetPoint("TOP", icon, "BOTTOM", 0, -3)
            name:SetWidth(CELL)
            name:SetJustifyH("CENTER")
            name:SetWordWrap(false)
            cell:SetScript("OnEnter", function(self)
                hl:SetColorTexture(1, 1, 1, 0.08)
                EllesmereUI.ShowWidgetTooltip(self, e.name)
            end)
            cell:SetScript("OnLeave", function()
                hl:SetColorTexture(1, 1, 1, 0)
                EllesmereUI.HideWidgetTooltip()
            end)
            cell:SetScript("OnClick", function()
                local list = ns.Bindings()
                list[#list + 1] = { key = nil, type = e.type, action = e.action }
                selected = #list
                ClosePopup()
                Changed()
            end)
        end
        local rows = math.ceil(#entries / COLS)
        child:SetHeight(rows * (CELL + 22))
    end

    for i, t in ipairs(TABS) do
        local tb = CreateFrame("Button", nil, p)
        tb:SetSize(tabW, 26)
        tb:SetPoint("TOPLEFT", p, "TOPLEFT", INSET + (i - 1) * (tabW + 4), -INSET)
        local tbg = tb:CreateTexture(nil, "BACKGROUND")
        tbg:SetAllPoints()
        tabBgs[i] = tbg
        local hl = tb:CreateTexture(nil, "HIGHLIGHT")
        hl:SetAllPoints()
        hl:SetColorTexture(1, 1, 1, 0.1)
        local lbl = Label(tb, t.label, 12, 1, 1, 1, 0.9)
        lbl:SetPoint("CENTER")
        tb:SetScript("OnClick", function() Show(i) end)
    end
    Show(1)
end

-------------------------------------------------------------------------------
--  Page: Bindings
-------------------------------------------------------------------------------
-- One tile in the list (Ellesmere's sidebar tile: icon, name, key, delete).
local function BuildTile(parent, y, w, index, b, isSel)
    local tile = CreateFrame("Button", nil, parent)
    tile:SetSize(w, TILE_H)
    tile:SetPoint("TOPLEFT", parent, "TOPLEFT", 0, y)
    tile:SetFrameLevel(parent:GetFrameLevel() + 1)
    local bg = tile:CreateTexture(nil, "BACKGROUND")
    bg:SetAllPoints()
    bg:SetColorTexture(1, 1, 1, isSel and 0.06 or 0)
    if isSel then
        local r, g, bl = Accent()
        local bar = tile:CreateTexture(nil, "ARTWORK", nil, 2)
        bar:SetSize(2, TILE_H)
        bar:SetPoint("TOPLEFT")
        bar:SetColorTexture(r, g, bl, 1)
    end

    local icon = IconBox(tile, ICON_SZ, ns.IconOf(b))
    icon:SetPoint("LEFT", tile, "LEFT", 8, 0)

    local title = Label(tile, ns.NameOf(b), 13, 1, 1, 1, 1)
    title:SetPoint("TOPLEFT", tile, "TOPLEFT", 8 + ICON_SZ + 8, -10)
    title:SetPoint("RIGHT", tile, "RIGHT", -30, 0)
    title:SetWordWrap(false)

    local status = ns.Status(index)
    local problem = status ~= "ok" and status ~= "unbound" and status ~= "inactive"
    local sub = Label(tile, b.key and ns.FormatKey(b.key) or "Not Bound", 11,
        problem and 1 or 0.75, problem and 0.45 or 0.75, problem and 0.35 or 0.75, problem and 0.9 or 0.65)
    sub:SetPoint("TOPLEFT", title, "BOTTOMLEFT", 0, -3)
    sub:SetPoint("RIGHT", tile, "RIGHT", -30, 0)
    sub:SetWordWrap(false)

    local del = CreateFrame("Button", nil, tile)
    del:SetSize(16, 16)
    del:SetPoint("TOPRIGHT", tile, "TOPRIGHT", -8, -8)
    del:SetFrameLevel(tile:GetFrameLevel() + 2)
    local dt = del:CreateTexture(nil, "ARTWORK")
    dt:SetAllPoints()
    EllesmereUI.SetDeleteIcon(dt)
    dt:SetDesaturated(true)
    dt:SetVertexColor(0.75, 0.75, 0.75)
    dt:SetAlpha(0.5)
    del:SetScript("OnEnter", function() dt:SetAlpha(0.9) end)
    del:SetScript("OnLeave", function() dt:SetAlpha(0.5) end)
    del:SetScript("OnClick", function()
        table.remove(ns.Bindings(), index)
        if selected == index then selected = nil
        elseif selected and selected > index then selected = selected - 1 end
        Changed()
    end)

    local sep = tile:CreateTexture(nil, "ARTWORK")
    sep:SetHeight(1)
    sep:SetPoint("BOTTOMLEFT")
    sep:SetPoint("BOTTOMRIGHT")
    sep:SetColorTexture(1, 1, 1, 0.04)

    tile:SetScript("OnEnter", function() if not isSel then bg:SetColorTexture(1, 1, 1, 0.04) end end)
    tile:SetScript("OnLeave", function() if not isSel then bg:SetColorTexture(1, 1, 1, 0) end end)
    tile:SetScript("OnClick", function()
        if selected ~= index then selected = index; Refresh() end
    end)
end

-- One option row in the detail panel: label left, control right.
local function DetailRow(parent, y, w, text, shade)
    local row = CreateFrame("Frame", nil, parent)
    row:SetSize(w, ROW_H)
    row:SetPoint("TOPLEFT", parent, "TOPLEFT", 0, y)
    local bg = row:CreateTexture(nil, "BACKGROUND")
    bg:SetAllPoints()
    bg:SetColorTexture(1, 1, 1, shade and 0.03 or 0.015)
    local lbl = Label(row, text, 14, 1, 1, 1, 1)
    lbl:SetPoint("LEFT", row, "LEFT", 20, 0)
    return row
end

-- The selected binding's options. Returns the height used.
local function BuildDetail(parent, w, index)
    local b = index and ns.Bindings()[index]
    if not b then
        local fs = Label(parent, "Select a binding on the left, or add one with Add Binding.", 13, 1, 1, 1, 0.5)
        fs:SetPoint("TOP", parent, "TOP", 0, -40)
        return 100
    end
    local y = -16

    -- Header: icon, type, name (as Ellesmere's "Spell / Bloodrage").
    local head = CreateFrame("Frame", nil, parent)
    head:SetSize(w, 44)
    head:SetPoint("TOPLEFT", parent, "TOPLEFT", 0, y)
    local icon = IconBox(head, 36, ns.IconOf(b))
    local kind = Label(head, ns.TYPE_LABEL[b.type] or "", 11, 1, 1, 1, 0.5)
    local name = Label(head, ns.NameOf(b), 16, 1, 1, 1, 1)
    local textW = math.max(kind:GetStringWidth(), name:GetStringWidth())
    local total = 36 + 10 + textW
    icon:SetPoint("LEFT", head, "CENTER", -total / 2, 0)
    kind:SetPoint("TOPLEFT", icon, "TOPRIGHT", 10, 0)
    name:SetPoint("BOTTOMLEFT", icon, "BOTTOMRIGHT", 10, 0)
    y = y - 44 - 16

    local cap = Label(parent, "BINDING OPTIONS", 11, 1, 1, 1, 0.45)
    cap:SetPoint("TOPLEFT", parent, "TOPLEFT", 0, y)
    y = y - 22

    local row = DetailRow(parent, y, w, "Keybind", true)
    local kb = KeybindButton(row, 210,
        function() return b.key end,
        function(key) b.key = key; Changed() end,
        function() b.key = nil; Changed() end)
    kb:SetPoint("RIGHT", row, "RIGHT", -20, 0)
    y = y - ROW_H

    local shade = false
    local function ToggleRow(text, get, set, tip)
        local r = DetailRow(parent, y, w, text, shade)
        shade = not shade
        local tg = EllesmereUI.BuildToggleControl(r, r:GetFrameLevel() + 2, get, set)
        tg:SetPoint("RIGHT", r, "RIGHT", -20, 0)
        if tip then
            r:EnableMouse(true)
            r:SetScript("OnEnter", function(self) EllesmereUI.ShowWidgetTooltip(self, tip) end)
            r:SetScript("OnLeave", function() EllesmereUI.HideWidgetTooltip() end)
        end
        y = y - ROW_H
    end

    if b.type == "spell" and ns.ClassHasRez() then
        ToggleRow("Enable Dynamic Rez",
            function() return b.smartRez == true end,
            function(v) b.smartRez = v or nil; Changed() end,
            "On a dead player this binding resurrects instead (out of combat; Rebirth also in combat).")
    end

    ToggleRow("Only Cast Out of Combat",
        function() return b.oocOnly == true end,
        function(v) b.oocOnly = v or nil; Changed() end)

    -- Active In: Ellesmere's own checkbox dropdown (public builder, the call
    -- Ellesmere's HoverCast page makes). ctx stays nil while every context
    -- is ticked, so untouched bindings store nothing.
    do
        local r = DetailRow(parent, y, w, "Active In", shade)
        shade = not shade
        local items = {
            { key = "solo",  label = "Solo",  tooltip = "Active while you are not in a group." },
            { key = "party", label = "Party", tooltip = "Active in a party." },
            { key = "raid",  label = "Raid",  tooltip = "Active in a raid." },
            { key = "pvp",   label = "PvP",   tooltip = "Active in battlegrounds and arenas." },
        }
        local build = EllesmereUI.BuildVisOptsCBDropdown
        local dd = build and build(r, 160, r:GetFrameLevel() + 2, items,
            function(key) return not b.ctx or b.ctx[key] == true end,
            function(key, v)
                if not b.ctx then
                    b.ctx = {}
                    for _, c in ipairs(ns.CTX_ORDER) do b.ctx[c] = true end
                end
                b.ctx[key] = v and true or false
                local n = 0
                for _, c in ipairs(ns.CTX_ORDER) do if b.ctx[c] then n = n + 1 end end
                if n == #ns.CTX_ORDER then b.ctx = nil end
                ns.Apply()
            end,
            nil, #ns.CTX_ORDER)
        if dd then
            dd:SetPoint("RIGHT", r, "RIGHT", -20, 0)
        else
            -- Builder missing in this EllesmereUI build: say so instead of
            -- breaking the page.
            local fs = Label(r, "Needs a newer EllesmereUI", 12, 1, 1, 1, 0.4)
            fs:SetPoint("RIGHT", r, "RIGHT", -20, 0)
        end
        y = y - ROW_H
    end

    if b.type == "custom" then
        local mrow = DetailRow(parent, y, w, "Macro text", false)
        local hint = Label(mrow, "Click outside the box to save", 11, 1, 1, 1, 0.4)
        hint:SetPoint("RIGHT", mrow, "RIGHT", -20, 0)
        y = y - ROW_H
        local holder, eb = TextArea(parent, w, 96)
        holder:SetPoint("TOPLEFT", parent, "TOPLEFT", 0, y - 4)
        eb:SetText(b.action or "")
        eb:SetScript("OnEditFocusLost", function(self)
            local text = self:GetText() or ""
            if text ~= (b.action or "") then
                b.action = text
                Changed()
            end
        end)
        y = y - 96 - 10
    end

    -- What it does, or why it is not applied.
    local status = ns.Status(index)
    local text, warn
    if status == "ok" then
        text, warn = Describe(b)
    else
        text, warn = ns.STATUS_TEXT[status] or status, status ~= "unbound" and status ~= "inactive"
    end
    local r, g, bl, a = 1, 1, 1, 0.55
    if warn and status == "ok" then r, g, bl, a = 1, 0.82, 0.3, 0.95      -- works, but check it
    elseif warn then r, g, bl, a = 1, 0.45, 0.35, 0.95 end                -- not applied
    local fs = Label(parent, text, 12, r, g, bl, a)
    fs:SetWidth(w - 20)
    fs:SetSpacing(3)
    fs:SetPoint("TOPLEFT", parent, "TOPLEFT", 10, y - 12)
    y = y - 12 - (fs:GetStringHeight() or 16) - 12

    return -y
end

local function BuildBindingsPage(parent, yOffset)
    local W = EllesmereUI.Widgets
    local y = yOffset
    local _, h

    -- The search pre-build pass only records labels; skip the real layout.
    if EllesmereUI.IsSearchPrebuild() then
        _, h = W:SectionHeader(parent, "BINDINGS", y); y = y - h
        return math.abs(y)
    end

    ClosePopup()
    -- Ellesmere may have changed its own bindings since the last apply.
    ns.Apply()

    local pad = Pad()
    local areaW = parent:GetWidth() - pad * 2

    local values, order = ProfileValues(false)
    _, h = W:Dropdown(parent, "Profile", y, values,
        function() return ns.ActiveProfile() end,
        function(v)
            if v == "" or v == "__none" then return end
            selected = nil
            ns.SetProfile(v)
            Refresh()
        end, order,
        "Profiles are shared by every character on the account. Manage them on the Profiles tab."); y = y - h
    _, h = W:Toggle(parent, "Trigger Keybinds on Down", y,
        function() return ns.KeyDown() end,
        function(v) ns.SetKeyDown(v) end,
        "Keyboard and mouse-wheel bindings fire when the key is pressed instead of when it is released. " ..
        "Mouse clicks follow the frames' own setting (Ellesmere's Trigger Bindings on Down)."); y = y - h

    if ns.EllesmereCCEnabled() then
        y = Paragraph(parent,
            "Ellesmere's click-casting is on, so plain left/right click stay with it. To let ClickTweak handle " ..
            "everything, turn off Enable Click Casting in Raid Frames > HoverCast.", y, 0.95, 1, 0.82, 0.3)
    end
    y = y - 8

    local list = ns.Bindings()
    if selected and not list[selected] then selected = nil end
    if not selected and #list > 0 then selected = 1 end

    -- Two columns: tiles on the left, the selected binding on the right.
    local area = CreateFrame("Frame", nil, parent)
    area:SetPoint("TOPLEFT", parent, "TOPLEFT", pad, y)
    area:HookScript("OnHide", ClosePopup)

    local leftW = math.floor(math.min(280, areaW * 0.32))
    local left = CreateFrame("Frame", nil, area)
    left:SetPoint("TOPLEFT")
    left:SetWidth(leftW)
    local lbg = left:CreateTexture(nil, "BACKGROUND")
    lbg:SetAllPoints()
    lbg:SetColorTexture(1, 1, 1, 0.02)

    local title = Label(left, "Bindings", 14, 1, 1, 1, 1)
    title:SetPoint("TOP", left, "TOP", 0, -12)
    local ly = -36
    for i, b in ipairs(list) do
        BuildTile(left, ly, leftW, i, b, i == selected)
        ly = ly - TILE_H
    end
    local add = AccentButton(left, math.floor(leftW * 0.8), 30, "Add Binding", function() OpenAddPopup(left) end)
    add:SetPoint("TOP", left, "TOP", 0, ly - 12)
    local leftH = -ly + 12 + 30 + 16

    local rightW = areaW - leftW - 16
    local right = CreateFrame("Frame", nil, area)
    right:SetPoint("TOPLEFT", left, "TOPRIGHT", 16, 0)
    right:SetWidth(rightW)
    local rightH = BuildDetail(right, rightW, selected)

    local areaH = math.max(leftH, rightH, 320)
    area:SetSize(areaW, areaH)
    left:SetHeight(areaH)
    right:SetHeight(areaH)
    y = y - areaH - 16

    _, h = W:SectionHeader(parent, "HOW IT WORKS", y); y = y - h
    y = Paragraph(parent,
        "Bindings work on EllesmereUI party and raid frames only, never on unit frames.\n" ..
        "Mouse clicks act on the frame you click. Keyboard keys and the mouse wheel work while the mouse is " ..
        "over a party or raid frame; elsewhere the key keeps its normal action.\n" ..
        "Macro and Custom Macro need [@mouseover] to act on that player, for example: " ..
        "/cast [@mouseover,help,nodead] Power Word: Shield\n" ..
        "Changes made in combat apply when combat ends.", y)

    return math.abs(y)
end

-------------------------------------------------------------------------------
--  Page: Profiles
-------------------------------------------------------------------------------
local function BuildProfilesPage(parent, yOffset)
    local W = EllesmereUI.Widgets
    local y = yOffset
    local _, h

    _, h = W:SectionHeader(parent, "PROFILE", y); y = y - h
    local allValues, allOrder = ProfileValues(false)
    _, h = W:Dropdown(parent, "Profile for this character", y, allValues,
        function() return ns.ActiveProfile() end,
        function(v)
            if v == "" or v == "__none" then return end
            ns.SetProfile(v)
            Refresh()
        end, allOrder,
        "Profiles are shared by every character on the account. Each character remembers its own choice."); y = y - h

    _, h = W:SectionHeader(parent, "MANAGE", y); y = y - h
    _, h = W:WideButton(parent, "New Profile", y, function()
        EllesmereUI:ShowInputPopup({
            title       = "New Profile",
            message     = "The new profile starts with the default bindings and becomes active for this character.",
            placeholder = "Profile name",
            confirmText = "Create",
            maxLetters  = 32,
            onConfirm   = function(text)
                local name, err = ns.CheckProfileName(text)
                if not name then Info("New Profile", err) return end
                ns.NewProfile(name)
                Refresh()
            end,
        })
    end, 300); y = y - h

    local otherValues, otherOrder = ProfileValues(true)
    _, h = W:Dropdown(parent, "Copy bindings from", y, otherValues,
        function() return "__none" end,
        function(v)
            if v == "" or v == "__none" then return end
            EllesmereUI:ShowConfirmPopup({
                title       = "Copy Profile",
                message     = "Replace the bindings in \"" .. ns.ActiveProfile() .. "\" with a copy of \"" .. v .. "\"?",
                confirmText = "Copy",
                onConfirm   = function() ns.CopyProfileInto(v); Refresh() end,
            })
        end, otherOrder,
        "Overwrites the bindings of the profile this character uses."); y = y - h

    local delValues, delOrder = ProfileValues(true)
    _, h = W:Dropdown(parent, "Delete profile", y, delValues,
        function() return "__none" end,
        function(v)
            if v == "" or v == "__none" then return end
            EllesmereUI:ShowConfirmPopup({
                title       = "Delete Profile",
                message     = "Delete the profile \"" .. v .. "\"? This cannot be undone.",
                confirmText = "Delete",
                onConfirm   = function() ns.DeleteProfile(v); Refresh() end,
            })
        end, delOrder,
        "The active profile cannot be deleted. Characters that used a deleted profile switch to Default."); y = y - h

    _, h = W:WideButton(parent, "Reset Current Profile", y, function()
        EllesmereUI:ShowConfirmPopup({
            title       = "Reset Profile",
            message     = "Reset \"" .. ns.ActiveProfile() .. "\" to the default bindings?",
            confirmText = "Reset",
            onConfirm   = function() ns.ResetProfile(); Refresh() end,
        })
    end, 300); y = y - h

    return math.abs(y)
end

-------------------------------------------------------------------------------
--  Page: Import/Export
-------------------------------------------------------------------------------
local exportName      -- profile shown in the export box (page state only)
local importMessage   -- result of the last import, shown after the rebuild

local function BuildImportExportPage(parent, yOffset)
    local W = EllesmereUI.Widgets
    local y = yOffset
    local _, h

    _, h = W:SectionHeader(parent, "EXPORT", y); y = y - h
    if not (exportName and ClickTweakProfilesDB.profiles[exportName]) then
        exportName = ns.ActiveProfile()
    end
    local values, order = ProfileValues(false)
    _, h = W:Dropdown(parent, "Profile to export", y, values,
        function() return exportName end,
        function(v)
            if v == "" or v == "__none" then return end
            exportName = v
            Refresh()
        end, order); y = y - h

    if EllesmereUI.IsSearchPrebuild() then
        _, h = W:SectionHeader(parent, "IMPORT", y); y = y - h
        _, h = W:WideButton(parent, "Import and Use", y, function() end); y = y - h
        return math.abs(y)
    end

    local exportText = ns.Export(exportName)
    local out = MultiBox(parent, y - 6, 90)
    out:SetText(exportText)
    -- Read-only: typing puts the string back; focus selects it all for Ctrl+C.
    out:SetScript("OnTextChanged", function(self, user)
        if user then self:SetText(exportText); self:HighlightText() end
    end)
    out:SetScript("OnEditFocusGained", function(self) self:HighlightText() end)
    y = y - 96
    y = Paragraph(parent, "Click the box and press Ctrl+C to copy.", y, 0.5)

    _, h = W:SectionHeader(parent, "IMPORT", y); y = y - h
    local inBox = MultiBox(parent, y - 6, 90)
    y = y - 96
    y = Paragraph(parent, "Paste a ClickTweak string (Ctrl+V), then press Import and Use. " ..
        "It is saved as a new profile and becomes active for this character.", y, 0.5)

    _, h = W:WideButton(parent, "Import and Use", y, function()
        local parsed, err = ns.ParseImport(inBox:GetText())
        if not parsed then Info("Import", err) return end
        -- Suggest the exported name, made free if it is taken.
        local base = (parsed.name ~= "" and parsed.name) or "Imported"
        local suggest, n = base, 2
        while ClickTweakProfilesDB.profiles[suggest] do
            suggest = base .. " (" .. n .. ")"
            n = n + 1
        end
        EllesmereUI:ShowInputPopup({
            title       = "Import Profile",
            message     = #parsed.bindings .. " binding(s). Name for the new profile:",
            initialText = suggest,
            confirmText = "Import",
            maxLetters  = 32,
            onConfirm   = function(text)
                local name, nerr = ns.CheckProfileName(text)
                if not name then Info("Import", nerr) return end
                ns.ImportAs(parsed, name)
                importMessage = "Imported \"" .. name .. "\" and switched to it."
                Refresh()
            end,
        })
    end, 300); y = y - h

    if importMessage then
        local fs = Label(parent, importMessage, 12, 0.5, 1, 0.6, 0.9)
        fs:SetPoint("TOPLEFT", parent, "TOPLEFT", Pad() + 10, y - 4)
        y = y - 24
        importMessage = nil
    end

    return math.abs(y)
end


-------------------------------------------------------------------------------
--  Registration
-------------------------------------------------------------------------------
local function BuildPage(pageName, parent, yOffset)
    if pageName == "Profiles" then return BuildProfilesPage(parent, yOffset) end
    if pageName == "Import/Export" then return BuildImportExportPage(parent, yOffset) end
    return BuildBindingsPage(parent, yOffset)
end

EllesmereUI.RegisterPlugin(PLUGIN_ID, {
    label   = "ClickTweak",
    modules = {
        {
            key         = MODULE_KEY,
            title       = "Click Bindings",
            description = "Click-cast and hover keybindings for EllesmereUI party and raid frames.",
            pages       = { "Bindings", "Profiles", "Import/Export" },
            buildPage   = BuildPage,
            -- Spell, macro and item lists can change while the page is away:
            -- drop the cached pages so the next visit builds fresh lists.
            onModuleLeave = function()
                ClosePopup()
                local key = EllesmereUI.GetPluginModuleKey(PLUGIN_ID, MODULE_KEY)
                if key then EllesmereUI:InvalidateModulePageCache(key) end
            end,
            onReset     = function()
                selected = nil
                ns.ResetProfile()
                Refresh()
            end,
        },
    },
})

SLASH_CLICKTWEAK1 = "/clicktweak"
SlashCmdList.CLICKTWEAK = function()
    EllesmereUI.OpenPlugin(PLUGIN_ID)
end
